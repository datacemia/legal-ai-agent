import json
import re
from typing import Any

from openai import OpenAI

from app.config import OPENAI_API_KEY
from app.services.contract_agent.risk_engine import analyze_risk
from app.services.contract_agent.risk_explainer import (
    build_risk_explanation,
)
from app.services.contract_agent.clause_title_extractor import extract_clause_title
from app.services.contract_agent.timeline_extractor import (
    extract_contract_timeline,
)
from app.services.contract_agent.clause_dependency_graph import (
    build_clause_dependency_graph,
)
from app.services.contract_agent.legal_relation_graph import (
    build_legal_relation_graph,
)
from app.services.contract_agent.clause_grouping_engine import (
    build_clause_groups,
)
from app.services.contract_agent.contradiction_detector import (
    detect_contract_contradictions,
)
from app.services.contract_agent.executive_summary import (
    build_executive_summary,
)
from app.services.contract_agent.executive_risk_narrative import (
    build_executive_risk_narrative,
)
from app.services.contract_agent.executive_report_builder import (
    build_executive_report,
)
from app.services.contract_agent.semantic_negotiation import (
    get_semantic_negotiation,
)
from app.services.contract_agent.legal_reasoning_templates import (
    get_reasoning_for_text,
)
from app.services.contract_agent.negotiation_intelligence import (
    detect_negotiation_inconsistency,
    should_check_wording_fidelity,
    extract_numbers_with_units,
    acceptable_compromise_introduces_denied_right,
    source_vs_fallback_exclusive_remedy_mismatch,
    find_all_numeric_deltas_for_display,
    normalize_clause_type,
    generated_text_caps_excepted_category,
    fallback_wording_contains_inherited_denied_right,
    classify_numeric_term_role,
    numeric_role_direction_guidance,
    generated_text_introduces_unaddressed_usage_right,
    compare_liability_states,
    detect_material_obligation_changes,
    generate_remedies_specific_content,
    generate_governing_law_specific_content,
    generate_warranty_specific_content,
    generate_mechanism_driven_acceptable_compromise,
    generate_mechanism_driven_negotiation_boundary,
    fallback_wording_removes_termination_limitation,
    validate_semantic_object_sanity,
    fallback_wording_changes_renewal_mechanism,
    fallback_wording_changes_right_polarity,
    compromise_introduces_notice_requirement,
)
from app.services.contract_agent.contract_taxonomy import (
    detect_clause_type_from_taxonomy,
    has_clause_type_signal,
    score_clause_type,
    get_clause_type_description,
)
from app.services.contract_agent.jurisdiction_profiles import (
    detect_jurisdiction,
)
from app.services.contract_agent.party_role_detector import (
    get_display_roles,
    apply_display_roles,
    normalize_ai_role_words,
)
from app.services.contract_agent.clause_splitter import (
    split_into_clause_objects,
)
from app.utils.prompt_loader import load_prompt

client = OpenAI(api_key=OPENAI_API_KEY)


ENABLE_DEPENDENCY_GRAPH = True
ENABLE_LEGAL_RELATION_GRAPH = True

SUPPORTED_LANGUAGES = {"en", "fr", "ar"}

ANONYMIZED_PLACEHOLDER_PATTERN = re.compile(
    r"\[(CLIENT|CUSTOMER|SERVICE_PROVIDER|PROVIDER|SUPPLIER|VENDOR|BUYER|SELLER|"
    r"EMPLOYER|EMPLOYEE|PARTY_1|PARTY_2|PARTY_3|PARTY_A|PARTY_B|PERSON|"
    r"ORGANIZATION|COMPANY|ADDRESS|EMAIL|PHONE|ID|DATE|AMOUNT|ACCOUNT|"
    r"CONTROLLER|PROCESSOR|LESSOR|LESSEE|LANDLORD|TENANT|LENDER|BORROWER|"
    r"LICENSOR|LICENSEE|FRANCHISOR|FRANCHISEE|PRINCIPAL|AGENT|DISTRIBUTOR|"
    r"RESELLER|MANUFACTURER|INSURER|INSURED)\]",
    re.IGNORECASE,
)

EMAIL_PATTERN = re.compile(
    r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b",
    re.IGNORECASE,
)

PHONE_PATTERN = re.compile(
    r"(?<!\w)(?:\+?\d[\d\s().-]{7,}\d)(?!\w)"
)

LONG_ID_PATTERN = re.compile(
    r"\b(?:[A-Z]{1,4}[-/]?)?\d{6,}[A-Z0-9/-]*\b",
    re.IGNORECASE,
)

ADDRESS_HINT_PATTERN = re.compile(
    r"\b\d{1,6}\s+[A-ZÀ-ÿ][A-ZÀ-ÿ0-9'’.\-\s]{2,80}\s+"
    r"(street|st\.|road|rd\.|avenue|ave\.|boulevard|blvd\.|lane|ln\.|drive|dr\.|"
    r"rue|avenue|boulevard|immeuble|résidence|شارع|زنقة|حي|عمارة)\b",
    re.IGNORECASE,
)


def normalize_language(language: str) -> str:
    language = str(language or "en").lower().strip()
    return language if language in SUPPORTED_LANGUAGES else "en"


def contains_anonymized_placeholders(value: str) -> bool:
    return bool(ANONYMIZED_PLACEHOLDER_PATTERN.search(str(value or "")))


def anonymize_personal_data_for_ai(text: str) -> str:
    value = str(text or "")

    if not value:
        return ""

    value = EMAIL_PATTERN.sub("[EMAIL]", value)
    value = PHONE_PATTERN.sub("[PHONE]", value)
    value = ADDRESS_HINT_PATTERN.sub("[ADDRESS]", value)
    value = LONG_ID_PATTERN.sub("[ID]", value)

    return value


def anonymize_party_label_for_ai(value: str, fallback: str) -> str:
    label = str(value or "").strip()

    if not label:
        return fallback

    if contains_anonymized_placeholders(label):
        return label

    allowed_generic = {
        "party a": "[PARTY_1]",
        "party b": "[PARTY_2]",
        "party 1": "[PARTY_1]",
        "party 2": "[PARTY_2]",
        "contracting party a": "[PARTY_1]",
        "contracting party b": "[PARTY_2]",
        "client": "[CLIENT]",
        "customer": "[CLIENT]",
        "service provider": "[SERVICE_PROVIDER]",
        "provider": "[SERVICE_PROVIDER]",
        "supplier": "[SUPPLIER]",
        "vendor": "[VENDOR]",
        "buyer": "[BUYER]",
        "seller": "[SELLER]",
        "employer": "[EMPLOYER]",
        "employee": "[EMPLOYEE]",
        "processor": "[PROCESSOR]",
        "controller": "[CONTROLLER]",
        "lessor": "[LESSOR]",
        "lessee": "[LESSEE]",
        "landlord": "[LANDLORD]",
        "tenant": "[TENANT]",
        "lender": "[LENDER]",
        "borrower": "[BORROWER]",
        "licensor": "[LICENSOR]",
        "licensee": "[LICENSEE]",
    }

    return allowed_generic.get(label.lower(), fallback)


def anonymize_party_roles_for_ai(party_roles: dict | None) -> dict | None:
    if not isinstance(party_roles, dict):
        return None

    party_a = anonymize_party_label_for_ai(
        party_roles.get("party_a"),
        "[PARTY_1]",
    )
    party_b = anonymize_party_label_for_ai(
        party_roles.get("party_b"),
        "[PARTY_2]",
    )

    return {
        "party_a": party_a,
        "party_b": party_b,
        "family": str(party_roles.get("family", "") or ""),
        "anonymized": True,
    }


def should_apply_display_roles_to_output(text_value: str, party_roles: dict | None) -> bool:
    if not isinstance(party_roles, dict):
        return False

    if party_roles.get("anonymized") is True:
        return True

    return contains_anonymized_placeholders(text_value)


def safe_apply_display_roles(value, party_roles: dict | None, language: str = "en"):
    if isinstance(value, list):
        return [
            safe_apply_display_roles(item, party_roles, language)
            for item in value
        ]

    if isinstance(value, dict):
        return {
            key: safe_apply_display_roles(item, party_roles, language)
            for key, item in value.items()
        }

    if not isinstance(value, str):
        return value

    if not should_apply_display_roles_to_output(value, party_roles):
        return value

    try:
        return apply_display_roles(value, party_roles or {}, language)
    except Exception:
        return value


def strip_debug_prints_enabled() -> bool:
    return False


def remove_repeated_sample_policy_disclaimer(text: str) -> str:
    if not text:
        return ""

    lines = text.splitlines()
    cleaned = []

    skip_phrases = [
        "Disclaimer: This Sample Policy is not intended",
        "It is provided with the understanding",
        "Readers should consult competent counsel",
        "professional services of their own choosing",
    ]

    for line in lines:
        if any(p in line for p in skip_phrases):
            continue

        cleaned.append(line)

    return "\n".join(cleaned).strip()


AR_TITLE_FIXES = {
    "القرض مبلغ - 1 المادة": "مبلغ القرض",
    "والدفع الرسوم": "الرسوم والدفع",
    "الخدمة مستوى": "مستوى الخدمة",
    "المكافأة الأجر": "الأجر والمكافأة",
    "التجاري المحل - 1 المادة": "المحل التجاري",
    "الأداء عدم": "عدم الأداء",
}


def normalize_final_clause_title(
    title: str,
) -> str:
    title = extract_clause_title(title)

    title = AR_TITLE_FIXES.get(
        title.strip(),
        title,
    )

    prefixes = [
        "Contracting Party A ",
        "Contracting Party B ",
        "Contracting Party C ",
        "Party A ",
        "Party B ",
        "Party C ",
        "Employer ",
        "Employee ",
        "Company ",
        "Contractor ",
        "Vendor ",
        "Client ",

        "Partie contractante A ",
        "Partie contractante B ",
        "Partie contractante C ",
        "Employeur ",
        "Employé ",
        "Société ",
        "Prestataire ",
        "Client ",

        "الطرف المتعاقد أ ",
        "الطرف المتعاقد ب ",
        "الطرف المتعاقد ج ",
        "صاحب العمل ",
        "الموظف ",
        "الشركة ",
        "المقاول ",
        "المورد ",
        "العميل ",
    ]

    for prefix in prefixes:
        if title.startswith(prefix):
            title = title[len(prefix):].strip()
    if title == "[ADDRESS]":
        return "Contact Information"

    return title


ALLOWED_CLAUSE_TYPES = {
    "payment",
    "pricing",
    "invoice",
    "tax",
    "late_payment",
    "refund",
    "expense_reimbursement",
    "fees",
    "commission",
    "bonus",
    "royalties",

    "term",
    "duration",
    "renewal",
    "automatic_renewal",
    "termination",
    "termination_for_cause",
    "termination_for_convenience",
    "notice",
    "default",
    "cure_period",

    "liability",
    "limitation_of_liability",
    "limitation_of_liability_exceptions",
    "indemnity",
    "insurance",
    "warranty",
    "disclaimer",
    "penalty",
    "liquidated_damages",
    "force_majeure",

    "intellectual_property",
    "ip_assignment",
    "ownership",
    "license",
    "invention_assignment",
    "work_product",
    "moral_rights",

    "confidentiality",
    "data_protection",
    "privacy",
    "data_processing",
    "security",
    "cybersecurity",
    "audit_rights",

    "employment",
    "compensation",
    "benefits",
    "vacation",
    "non_compete",
    "non_solicitation",
    "exclusivity",
    "conflict_of_interest",
    "post_termination_obligations",

    "services",
    "service_level",
    "support",
    "maintenance",
    "delivery",
    "acceptance",
    "performance",
    "change_request",

    "assignment",
    "change_of_control",
    "compliance",
    "anti_bribery",
    "sanctions",
    "governance",
    "subcontracting",

    "lease",
    "rent",
    "deposit",
    "property_use",
    "repairs",
    "utilities",

    "loan",
    "interest",
    "security_interest",
    "collateral",
    "guarantee",
    "repayment",
    "acceleration",

    "governing_law",
    "jurisdiction",
    "venue",
    "arbitration",
    "mediation",
    "dispute_resolution",

    "amendment",
    "waiver",
    "severability",
    "entire_agreement",
    "counterparts",
    "notices",
    "definitions",

    "other",
    "financing",

}

CLAUSE_GROUPS = {
    "commercial_finance": {
        "types": {
            "payment", "pricing", "invoice", "tax", "late_payment",
            "refund", "expense_reimbursement", "fees", "commission",
            "bonus", "royalties",
        },
        "labels": {
            "en": "Commercial & Finance",
            "fr": "Commercial et finance",
            "ar": "الشروط التجارية والمالية",
        },
    },
    "contract_lifecycle": {
        "types": {
            "term", "duration", "renewal", "automatic_renewal",
            "termination", "termination_for_cause",
            "termination_for_convenience", "notice", "default",
            "cure_period",
        },
        "labels": {
            "en": "Contract Lifecycle",
            "fr": "Cycle de vie du contrat",
            "ar": "دورة حياة العقد",
        },
    },
    "liability_risk": {
        "types": {
            "liability", "limitation_of_liability", "indemnity",
            "insurance", "warranty", "disclaimer", "penalty",
            "liquidated_damages", "force_majeure",
        },
        "labels": {
            "en": "Liability & Risk",
            "fr": "Responsabilité et risques",
            "ar": "المسؤولية والمخاطر",
        },
    },
    "ip_licensing": {
        "types": {
            "intellectual_property", "ip_assignment", "ownership",
            "license", "invention_assignment", "work_product",
            "moral_rights",
        },
        "labels": {
            "en": "IP & Licensing",
            "fr": "Propriété intellectuelle et licences",
            "ar": "الملكية الفكرية والتراخيص",
        },
    },
    "data_confidentiality": {
        "types": {
            "confidentiality", "data_protection", "privacy",
            "data_processing", "security", "cybersecurity",
            "audit_rights",
        },
        "labels": {
            "en": "Data & Confidentiality",
            "fr": "Données et confidentialité",
            "ar": "البيانات والسرية",
        },
    },
    "employment_hr": {
        "types": {
            "employment", "compensation", "benefits", "vacation",
        },
        "labels": {
            "en": "Employment & HR",
            "fr": "Emploi et ressources humaines",
            "ar": "العمل والموارد البشرية",
        },
    },
    "restrictive_covenants": {
        "types": {
            "non_compete", "non_solicitation", "conflict_of_interest",
            "post_termination_obligations", "exclusivity",
        },
        "labels": {
            "en": "Restrictive Covenants",
            "fr": "Engagements restrictifs",
            "ar": "التعهدات التقييدية",
        },
    },
    "services_operations": {
        "types": {
            "services", "service_level", "support", "maintenance",
            "delivery", "acceptance", "performance", "change_request",
        },
        "labels": {
            "en": "Services & Operations",
            "fr": "Services et opérations",
            "ar": "الخدمات والعمليات",
        },
    },
    "governance_compliance": {
        "types": {
            "assignment", "change_of_control", "compliance",
            "anti_bribery", "sanctions", "governance",
            "subcontracting",
        },
        "labels": {
            "en": "Governance & Compliance",
            "fr": "Gouvernance et conformité",
            "ar": "الحوكمة والامتثال",
        },
    },
    "real_estate": {
        "types": {
            "lease", "rent", "deposit", "property_use",
            "repairs", "utilities",
        },
        "labels": {
            "en": "Real Estate",
            "fr": "Immobilier",
            "ar": "العقارات",
        },
    },
    "finance_lending": {
        "types": {
            "loan", "interest", "security_interest", "collateral",
            "guarantee", "repayment", "acceleration",
        },
        "labels": {
            "en": "Finance & Lending",
            "fr": "Financement et crédit",
            "ar": "التمويل والإقراض",
        },
    },
    "dispute_resolution": {
        "types": {
            "governing_law", "jurisdiction", "venue",
            "arbitration", "mediation", "dispute_resolution",
        },
        "labels": {
            "en": "Dispute Resolution",
            "fr": "Règlement des litiges",
            "ar": "تسوية النزاعات",
        },
    },
    "general_provisions": {
        "types": {
            "amendment", "waiver", "severability",
            "entire_agreement", "counterparts", "notices",
            "definitions", "other",
        },
        "labels": {
            "en": "General Provisions",
            "fr": "Dispositions générales",
            "ar": "أحكام عامة",
        },
    },
}

ALLOWED_RISK_LEVELS = {"low", "medium", "high", "elevated", "critical"}
ALLOWED_FAVOURS = {
    "party_a", "party_b",

    "provider", "client", "customer", "supplier", "vendor",
    "buyer", "seller", "employer", "employee", "contractor",
    "consultant", "licensor", "licensee", "processor",
    "controller", "landlord", "tenant", "franchisee",
    "franchisor", "lender", "borrower", "insurer",
    "insured", "principal", "agent", "distributor",
    "reseller", "manufacturer", "service_provider",
    "recipient", "owner", "operator", "partner",
    "balanced", "unclear"
}
ALLOWED_CONFIDENCE = {"low", "medium", "high"}
ALLOWED_PRIORITY = {"low", "medium", "high"}
ALLOWED_MARKET_PRACTICE = {
    "standard", "aggressive", "customer_friendly",
    "vendor_friendly", "balanced", "unusual",
}


CLAUSE_SIGNAL_GROUPS = {
    "critical": [
        "termination",
        "default",
        "acceleration",
        "liability",
        "confidentiality",
        "data protection",
        "service level",
        "governing law",
        "indemnity",
        "security",
        "payment",
        "pricing",
        "maintenance",
        "repair",
        "covenants",
        "loan amount",
        "principal amount",
        "interest",

        "résiliation",
        "défaut",
        "responsabilité",
        "confidentialité",
        "protection des données",
        "niveau de service",
        "droit applicable",
        "paiement",
        "prix",
        "maintenance",
        "réparations",
        "montant du prêt",
        "capital",
        "intérêt",

        "فسخ",
        "إنهاء",
        "الإخلال",
        "المسؤولية",
        "السرية",
        "حماية البيانات",
        "مستوى الخدمة",
        "القانون الواجب التطبيق",
        "الدفع",
        "الأسعار",
        "الصيانة",
        "الإصلاحات",
        "التعهدات",
        "مبلغ القرض",
        "رأس المال",
        "الفائدة",
    ],
    "financial": [
        "payment",
        "pricing",
        "interest",
        "late payment",
        "bonus",
        "invoice",
        "paiement",
        "prix",
        "intérêt",
        "retard de paiement",
        "prime",
        "facture",
        "الدفع",
        "الأسعار",
        "الفائدة",
        "تأخر الدفع",
        "مكافأة",
        "فاتورة",
    ],
    "termination": [
        "termination",
        "default",
        "acceleration",
        "cure period",
        "notice period",
        "résiliation",
        "défaut",
        "délai de correction",
        "préavis",
        "فسخ",
        "إنهاء",
        "الإخلال",
        "مهلة تصحيح",
        "إشعار",
    ],
    "definitions": [
        "defined terms",
        "definition",
        "definitions",
        "means",
        "shall mean",
        "désigne",
        "signifie",
        "définition",
        "définitions",
        "يقصد به",
        "يعني",
        "تعريف",
        "التعريفات",
    ],
}


def get_clause_signal_terms(group: str) -> list[str]:
    return CLAUSE_SIGNAL_GROUPS.get(group, [])


LOW_RISK_CLAUSES = [
    "governing_law",
    "venue",
    "payment_schedule",
    "standard_confidentiality",
    "fixed_term",
    "ip_after_payment",
    "mutual_termination_notice",
    "administrative_amendment",
]

MEDIUM_RISK_CLAUSES = [
    "limited_liability",
    "broad_confidentiality",
    "vague_payment_trigger",
    "asymmetrical_termination",
]

HIGH_RISK_CLAUSES = [
    "unlimited_liability",
    "unilateral_amendment",
    "automatic_renewal_trap",
    "perpetual_non_compete",
    "broad_ip_assignment",
    "severe_penalties",
]

RISK_ESCALATORS = [
    "unlimited liability",
    "perpetual restriction",
    "unilateral amendment",
    "without cure period",
    "without notice termination",
    "without remedy",
    "sole discretion",
    "irreversible assignment",
    "irrevocable assignment",
    "perpetual non-compete",
    "unilateral termination",

    "responsabilité illimitée",
    "restriction perpétuelle",
    "modification unilatérale",
    "sans délai de correction",
    "résiliation sans préavis",
    "sans recours",
    "seule discrétion",
    "cession irréversible",
    "cession irrévocable",
    "non-concurrence perpétuelle",
    "résiliation unilatérale",

    "مسؤولية غير محدودة",
    "قيد دائم",
    "تعديل من جانب واحد",
    "دون مهلة تصحيح",
    "إنهاء دون إشعار",
    "دون تعويض",
    "تقديره المطلق",
    "تنازل غير قابل للإلغاء",
    "عدم منافسة دائم",
    "إنهاء من جانب واحد",
]

RISK_REDUCERS = [
    "notice period",
    "mutual termination",
    "cure period",
    "arbitration",
    "liability insurance",
    "liability cap",
    "compensation remedy",

    "préavis",
    "résiliation mutuelle",
    "délai de correction",
    "arbitrage",
    "assurance responsabilité",
    "plafond de responsabilité",
    "indemnisation",

    "إشعار",
    "إنهاء متبادل",
    "مهلة تصحيح",
    "تحكيم",
    "تأمين",
    "حد المسؤولية",
    "تعويض",
]


SPECULATIVE_PATTERNS = [
    "may not fully protect",
    "could lead to",
    "might create",
    "future employment opportunities",
    "wide range of potential liabilities",
    "salary adjustments",
    "market changes",
    "not cover all potential liabilities",
    "abrupt contract end",
    "automatic renewal",
    "additional protections",
    "more comprehensive",
    "broader coverage",
    "more types of claims",
    "additional liability",
    "higher coverage",
    "salary review",
    "salary reviews",
    "performance bonus",
    "performance bonuses",
    "minimum production threshold",
    "additional flexibility",
    "more flexibility",
    "enhance compensation",
    "competitive compensation",
    "competitive salary",
    "retain talent",
    "better financial outcomes",
    "more favorable terms",
    "tiered bonus",
    "review policy details",
    "align with company goals",
    "industry standards",
    "attract and retain",
    "comprehensive coverage",
    "comprehensive protection",
    "future acquisitions",
    "market conditions",
    "potential gaps",
    "business needs",
    "more favorable payment terms",
    "more favorable termination conditions",
    "effective decision-making",
    "limit future opportunities",
    "future opportunities",
    "higher maximum bonus",
    "extending the eligibility period",
    "longer-term performance metrics",
    "unexpected early termination",
    "without significant cause",
    "without much recourse",
    "higher guaranteed bonus",
    "capping the financial obligations",
    "tiered payment structure",
    "aggregate coverage limits",
    "cash flow impacts",
    "more flexible termination options",
    "potential lock-in",
    "realistic and achievable",
    "financial penalties",
    "increased risk for the employer",
    "higher premiums",
    "stricter terms",
    "above average for many industries",
    "performance metrics",
    "additional coverage",
    "scope of what is covered",
    "financial obligations for the company",
    "renewal options",
    "flexibility in termination",
    "changing circumstances",
    "longer production window",
    "maximize potential earnings",
    "broader timeframe",
    "specific risks associated",
    "market rates",
    "cash flow stability",
    "financial interests",
    "more favorable termination rights",
    "adequate coverage limits",
    "various potential claims",
    "specific coverage amounts",
    "higher bonus cap",
    "company growth",
    "enhance protection",
    "types of claims included",
    "robust in many industries",
    "adequate coverage",
    "more favorable payout",
    "higher aggregate limit",
    "competitive for executive roles",
    "operational stability",
    "potential misuse",
    "enhance coverage",
    "claims that could exceed",
    "lower limits",
    "financial safety net",
    "full protection",
    "stable financial expectation",
    "fair compensation",
    "excessive financial risk",
    "potential liabilities faced",
    "other potential liabilities",
    "additional types of coverage",
    "remove the cap",
    "enhance motivation",
    "capping the financial obligation",
    "cash flow risks",
    "impacts the employer's financial obligations",
    "lower minimum coverage",
    "financial burden on the employee",
    "employee's compensation package",
    "above average for standard employment agreements",
    "tiered coverage structure",
    "sudden job loss",
    "financial stability",
    "renewal automatique",
    "renouvellement automatique",
    "pénalités de retard",
    "late payment penalties",
    "pénalités pour retard de paiement",
    "mesures de sécurité appropriées",
    "préavis plus long",
    "droit français est le plus favorable",
    "transfert de propriété immédiat",
    "droits de rétention",
    "relation contractuelle est critique",
    "ne répondent pas aux attentes",
    "trouver un remplaçant",
    "déséquilibre de pouvoir",
    "laissant le client vulnérable",
    "leaving the client vulnerable",
    "ne pas couvrir tous les dommages",
    "not cover all damages",
    "entièrement protégé",
    "fully protected",
    "clause de renouvellement",
    "renewal clause",
    "continuité des relations commerciales",
    "business continuity",
    "retarder la fin du contrat",
    "delay contract termination",
    "risques potentiels",
    "potential risks",
    "protections adéquates",
    "adequate protections",
    "options de renouvellement",
    "renewal options",
    "conditions de renouvellement",
    "renewal terms",
    "prolonger la relation contractuelle",
    "extend the contractual relationship",
    "protéger les intérêts financiers",
    "protect financial interests",
    "même en cas de négligence",
    "even in case of negligence",
    "dommages potentiels",
    "potential damages",
    "besoins opérationnels",
    "operational needs",
    "option de renouvellement",
    "renewal option",
    "prolongation est souhaitée",
    "extension is desired",
    "مكان محايد",
    "neutral venue",
    "خيار التحكيم",
    "arbitration alternative",
    "مناسب لجميع الأطراف",
    "appropriate for all parties",
    "قد يسبب مشاكل",
    "may cause problems",
    "إذا لم يتم التخطيط",
    "if not properly planned",
    "operational disruption",
    "اضطراب تشغيلي",
]


RESTRICTED_RECOMMENDATION_ONLY_PATTERNS = [
    "responsabilité illimitée",
    "unlimited liability",
    "dommages indirects",
    "indirect damages",
    "conséquences juridiques",
    "legal consequences",
    "financial exposure",
    "protection adéquate",
    "adequate protection",
]


GENERIC_NEGOTIATION_PATTERNS = [
    "consider negotiating",
    "ensure that",
    "review the policy",
    "more favorable",
    "better protection",
]


GENERIC_AI_PATTERNS = [
    "ensure clarity",
    "ensure comprehensive",
    "consider negotiating",
    "evaluate the implications",
    "to avoid ambiguity",
    "to avoid disputes",
    "ensure adequate",
    "highlight the importance",
    "protect financial interests",
    "enhance protection",
    "justify a higher",
    "seek to enhance",
    "appears competitive",
    "generally favorable",
    "avoid ambiguity",
    "focus on defining",
    "to ensure fair",
    "to avoid excessive",
    "providing a stable",
    "to ensure full",
]


def safe_str(value: Any) -> str:
    if value is None:
        return ""

    if isinstance(value, str):
        return value.strip()

    return str(value).strip()


def safe_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value

    if isinstance(value, str):
        return value.strip().lower() in {
            "true",
            "yes",
            "1",
        }

    return False


def track_change(
    analysis: dict,
    field: str,
    old,
    new,
    source: str,
) -> None:
    if old == new:
        return

    analysis[field] = new

    analysis.setdefault(
        "_meta",
        {},
    )

    analysis["_meta"].setdefault(
        "changes",
        [],
    ).append({
        "field": field,
        "from": old,
        "to": new,
        "source": source,
    })


def mutate_analysis(
    analysis: dict,
    *,
    field: str,
    value,
    source: str,
) -> None:
    track_change(
        analysis,
        field=field,
        old=analysis.get(field),
        new=value,
        source=source,
    )


def localize_clause_reference(
    reference: str,
    language: str,
) -> str:

    if not reference:
        return ""

    reference = str(reference).strip()

    replacements = {
        "en": {
            "المادة": "Article",
            "البند": "Clause",
            "الفقرة": "Section",
        },
        "fr": {
            "المادة": "Article",
            "البند": "Clause",
            "الفقرة": "Section",
        },
        "ar": {
            "Article": "المادة",
            "Clause": "البند",
            "Section": "الفقرة",
        },
    }

    localized = reference

    for source_text, target_text in replacements.get(language, {}).items():
        localized = localized.replace(source_text, target_text)

    return localized


def clamp_enum(
    value: Any,
    allowed: set[str],
    default: str,
) -> str:
    value = safe_str(value).lower()

    return value if value in allowed else default


def fallback_clause_result(
    language: str = "en"
) -> dict:

    fallback_text = {
        "en": {
            "parse": "Could not parse AI response.",
            "missing": "Not specified",
            "review": (
                "Review this clause manually because "
                "the automated analysis failed."
            ),
        },

        "fr": {
            "parse": (
                "Impossible d’analyser correctement "
                "la réponse de l’IA."
            ),
            "missing": "Non spécifié",
            "review": (
                "Vérifiez cette clause manuellement "
                "car l’analyse automatique a échoué."
            ),
        },

        "ar": {
            "parse": (
                "تعذر تحليل رد الذكاء الاصطناعي "
                "بشكل صحيح."
            ),
            "missing": "غير محدد",
            "review": (
                "راجع هذا البند يدويًا لأن "
                "التحليل التلقائي فشل."
            ),
        },
    }

    t = fallback_text.get(
        language,
        fallback_text["en"]
    )

    return {
        "clause_title": "",
        "clause_reference": "",
        "quoted_text": "",
        "clause_type": "other",
        "risk_level": "low",
        "explanation_simple": t["parse"],
        "why_it_matters": t["missing"],
        "legal_insight": "",
        "favours": "unclear",
        "market_comparison": "",
        "red_flag": False,
        "red_flag_reason": "",
        "recommendation": t["review"],
        "confidence": "low",
        "market_practice": "standard",
        "safer_alternative": "",
        "fallback_wording": "",
        "negotiation_advice": t["review"],
        "negotiation_priority": "medium",
        "negotiable": True,
        "acceptable_compromise": "",
        "never_accept": "",
    }


def normalize_clause_result(
    ai_result: dict
) -> dict:

    return {
        "clause_title": safe_str(
            ai_result.get("clause_title")
        ),

        "clause_reference": localize_clause_reference(
            safe_str(
                ai_result.get("clause_reference")
            ),
            ai_result.get("language", "en"),
        ),

        "quoted_text": safe_str(
            ai_result.get("quoted_text")
        )[:600],

        "clause_type": clamp_enum(
            ai_result.get("clause_type"),
            ALLOWED_CLAUSE_TYPES,
            "other",
        ),

        "risk_level": clamp_enum(
            ai_result.get("risk_level"),
            ALLOWED_RISK_LEVELS,
            "low",
        ),

        "explanation_simple": safe_str(
            ai_result.get("explanation_simple")
        ),

        "why_it_matters": safe_str(
            ai_result.get("why_it_matters")
        ),

        "legal_insight": safe_str(
            ai_result.get("legal_insight")
        ),

        "favours": clamp_enum(
            ai_result.get("favours"),
            ALLOWED_FAVOURS,
            "unclear",
        ),

        "market_comparison": safe_str(
            ai_result.get("market_comparison")
        ),

        "red_flag": safe_bool(
            ai_result.get("red_flag")
        ),

        "red_flag_reason": safe_str(
            ai_result.get("red_flag_reason")
        ),

        "recommendation": safe_str(
            ai_result.get("recommendation")
        ),

        "confidence": clamp_enum(
            ai_result.get("confidence"),
            ALLOWED_CONFIDENCE,
            "low",
        ),

        "market_practice": clamp_enum(
            ai_result.get("market_practice"),
            ALLOWED_MARKET_PRACTICE,
            "standard",
        ),

        "safer_alternative": safe_str(
            ai_result.get("safer_alternative")
        ),

        "fallback_wording": safe_str(
            ai_result.get("fallback_wording")
        ),

        "negotiation_advice": safe_str(
            ai_result.get("negotiation_advice")
        ),

        "negotiation_priority": clamp_enum(
            ai_result.get("negotiation_priority"),
            ALLOWED_PRIORITY,
            "medium",
        ),

        "negotiable": (
            safe_bool(ai_result.get("negotiable"))
            if "negotiable" in ai_result
            else True
        ),

        "acceptable_compromise": safe_str(
            ai_result.get("acceptable_compromise")
        ),

        "never_accept": safe_str(
            ai_result.get("never_accept")
        ),
    }


def build_clause_prompt(
    clause: str,
    language: str,
    party_roles: dict | None = None,
) -> str:

    prompt_template = load_prompt(
        "clause_analysis_prompt.txt"
    )

    party_instruction = ""
    safe_party_roles = anonymize_party_roles_for_ai(party_roles)

    display_party_a = ""
    display_party_b = ""
    detected_family = "generic"

    if isinstance(party_roles, dict):
        display_party_a = str(party_roles.get("party_a") or "").strip()
        display_party_b = str(party_roles.get("party_b") or "").strip()
        detected_family = str(party_roles.get("family") or "generic").strip() or "generic"

    if safe_party_roles and safe_party_roles.get("party_a") and safe_party_roles.get("party_b"):
        party_instruction = f"""
MANDATORY PRIVACY AND PARTY TERMINOLOGY:
The contract text sent to you is anonymized. Never request, infer, restore,
or invent real names, emails, addresses, phone numbers, account numbers,
or personal identifiers.

Use ONLY these anonymized party labels:
- Party A = "{safe_party_roles['party_a']}"
- Party B = "{safe_party_roles['party_b']}"

Always refer to parties using anonymized placeholders or neutral legal roles
that are explicitly present in the anonymized clause text. Never invent or substitute party roles.
Use only:
- party_a
- party_b
- balanced
- unclear

For user-facing explanations, use the detected display roles above.
If a role is unclear, use neutral wording such as "the relevant party".

If the clause contains anonymized placeholders, preserve them exactly or map them only to Party A / Party B when the mapping is explicit.
preserve them exactly or map them only to the anonymized Party A / Party B
labels above. If mapping is unclear, keep the placeholder itself.

AUTHORITATIVE CONTRACT ROLE MAP:
The backend has already detected the contract role family as: {detected_family}.
These detected role labels are authoritative for all generated user-facing text:
- Party A display role = "{display_party_a or safe_party_roles['party_a']}"
- Party B display role = "{display_party_b or safe_party_roles['party_b']}"

Use these detected role labels consistently. Do not introduce Employer or
Employee unless the detected contract family is employment or those exact
roles appear in the clause text. For non-employment contracts, do not use
Employment & HR wording; use neutral commercial terminology such as
restrictive covenants, personnel, staff, or applicable representatives where
appropriate.

CANONICAL FAVOURS FIELD RULE:
For the JSON key "favours", return ONLY one of these four values:
- "party_a"
- "party_b"
- "balanced"
- "unclear"
Never return role words such as Employer, Employee, Client, Provider, Buyer,
Seller, Vendor, Supplier, Lender, Borrower, Lessor, Lessee, Licensor, or
Licensee in the "favours" field. The backend will render party_a / party_b
using the authoritative Party Registry.
"""

    safe_clause = anonymize_personal_data_for_ai(clause)

    return f"""
{prompt_template}
{party_instruction}

Output language: {language}

LANGUAGE CONSISTENCY RULES:
- All generated clause titles, explanations, insights, recommendations, risk narratives, and user-facing labels must be written in the requested output language.
- Do not keep source-language clause titles unless they are official article references, proper legal names, dates, amounts, or court names.
- If a clause title or legal domain appears in a different source language, translate it into the requested output language.
- Avoid generic party labels like "first party", "second party", "premier partie", "deuxième partie", "الطرف الأول", or "الطرف الثاني" when approved role labels are available.
- Do not use real party names, personal data, emails, addresses, account numbers, or identifiers.
- Do not hard-code Employer / Employee unless the detected contract family is a real employment contract.
- Use the approved anonymized or role-based labels supplied in MANDATORY PRIVACY AND PARTY TERMINOLOGY.
- Preserve dates, amounts, article references, and court names when they are not personal identifiers.
- Mixed-language explanatory output is forbidden.

Analyze this single clause only.

Clause:
{safe_clause}
""".strip()


def call_clause_ai(
    prompt: str
) -> dict:

    response = client.chat.completions.create(
        model="gpt-4o-mini",

        messages=[
            {
                "role": "system",

                "content": (
                    "You are a strict JSON "
                    "contract analysis engine. "
                    "Return only valid JSON "
                    "and never add markdown."
                ),
            },

            {
                "role": "user",
                "content": prompt,
            },
        ],

        temperature=0.1,

        response_format={
            "type": "json_object"
        },
    )

    content = (
        response
        .choices[0]
        .message
        .content
        or "{}"
    )

    return json.loads(content)


def verify_wording_fidelity_to_source(
    clause_text: str,
    fallback_wording: str,
    acceptable_compromise: str,
    language: str = "en",
) -> dict:
    """
    Checks whether fallback_wording/acceptable_compromise correctly
    preserve the ORIGINAL clause's own numbers where they are meant to
    be restated, rather than getting a number wrong. Covers two distinct
    failure modes with the same check:

      1. Cross-attribution: a clause with both a 60-day non-renewal
         notice AND a separate 90-day termination-for-convenience
         notice, where the generated fallback_wording incorrectly
         applies the 90-day figure to the non-renewal notice instead.
      2. Plain restatement error: a clause with a single, unambiguous
         30-day figure, where the generated text simply states a
         different number (e.g. 60 days) with no second source number
         to explain the mix-up -- a straightforward hallucination
         rather than a mix-up between two real values.

    Only meant to be called when
    negotiation_intelligence.should_check_wording_fidelity() confirms
    the source and generated text share a numeric unit worth checking --
    this keeps the added AI call scoped to clauses that actually need
    it, not every clause of every contract.

    ONE prompt template parameterized by `language`, not a separate
    prompt per language: output is requested directly in the target
    language via an explicit instruction, so EN/FR/AR share the exact
    same verification logic and only the requested output language
    differs -- matching the same pattern already used for the
    missing-clauses AI call in unified_report_from_pipeline.py.

    Fails safe: any AI-call error returns "no issue found" rather than
    raising, since this is a supplementary check that must never break
    the main clause analysis.
    """
    prompt = f"""ROLE: You verify that a generated legal drafting suggestion correctly reflects the ORIGINAL CLAUSE's numbers, its polarity on any capped/uncapped, exclusive/non-exclusive, limited/unlimited, or similar all-or-nothing legal dichotomy, and whether it correctly preserves any waived or reserved legal right or exclusivity restriction, catching five distinct problems:
1. Cross-attribution: confusing two different numbers that both appear in the same clause for different purposes (e.g. a notice period for non-renewal vs a separate notice period for termination for convenience).
2. Restatement error: simply getting a number wrong when restating an obligation from the original clause, even when the original clause only has one number for that obligation (e.g. the clause says "thirty (30) days" and the generated text says "sixty (60) days" with no other number involved at all).
3. Polarity inversion: flipping which side of a legal dichotomy applies, often through a subtle double negative that keeps the SAME keyword as the original but reverses its meaning (e.g. the original says liability "shall be uncapped" for gross negligence, and the generated text says "with no uncapped liability for gross negligence" -- this states the OPPOSITE of the original: liability IS effectively capped, even though the word "uncapped" is still present in the sentence).
4. Waived-right inversion: reversing whether a party has waived a legal right versus retaining or being offered it (e.g. the original says each Party "irrevocably waives any right to a jury trial", and the generated text says there is "the option... to request a jury trial" -- this states the OPPOSITE of the original: the right is NOT waived, even though the same underlying concept, "jury trial", is mentioned in both).
5. Exclusivity narrowing or broadening: silently dropping or adding an "exclusive" qualifier while still discussing the same underlying concept, without any explicit negation word (e.g. the original grants "exclusive jurisdiction... of the courts located in Wilmington, Delaware", and the generated text says disputes may be brought "in the courts of Delaware or other competent jurisdictions" -- this broadens what the source restricted to one exclusive venue, even though no word was negated and no number changed).

ORIGINAL CLAUSE:
{clause_text}

GENERATED FALLBACK WORDING:
{fallback_wording}

GENERATED ACCEPTABLE COMPROMISE:
{acceptable_compromise}

TASK: Determine whether the generated text above correctly reflects the original clause's numbers and its polarity on any such dichotomy, or whether it gets something wrong -- whether by cross-attributing a different obligation's number, getting a figure wrong, or inverting which side of a dichotomy applies (including via a double negative that reuses the original word but reverses its effect).

Return JSON with exactly these keys:
{{
  "fidelity_issue": true or false,
  "explanation": "one short sentence describing the error, empty string if fidelity_issue is false"
}}

RULES:
- Only flag fidelity_issue as true if a number OR a dichotomy's polarity (capped/uncapped, exclusive/non-exclusive, limited/unlimited, etc.) is DEMONSTRABLY wrong compared to what the original clause actually says for that same obligation.
- Do NOT flag a deliberately DIFFERENT number offered as a proposal or negotiation position -- that is the normal, expected purpose of a fallback/compromise suggestion, not a fidelity issue. Treat a field as PROPOSING (never a fidelity issue, regardless of the number) whenever it contains change-signalling OR hedged/optional language, in any of the three languages this may be written in, such as: "increase/reduce/extend/instead of/rather than/change to/may/might/could/would allow/an option to/commonly/typically/generally/usually" (English), "augmenter/réduire/prolonger/au lieu de/plutôt que/porter à/pourrait/pourrait inclure/une option/généralement/habituellement/couramment" (French), "زيادة/تخفيض/تمديد/بدلاً من/بدل/يمكن أن/قد/خياراً/إمكانية/عادة/عموماً/غالباً" (Arabic). Both fallback_wording and acceptable_compromise are, by their fundamental role, proposed negotiation positions rather than neutral restatements of the source -- only flag a field as a fidelity issue when it states a number as flat, unconditional, present fact about the obligation (e.g. "the period is/shall be/must be X"), with no hedging or change language of any kind.
- Ask yourself: does this field present the number as simply WHAT THE CLAUSE ALREADY SAYS (a restatement), or as A CHANGE being proposed? Only the first case can be a fidelity issue.
- Do NOT flag mentioning a DIFFERENT, specifically-named right or basis as contradicting a source that denies a DIFFERENT, specifically-named right or basis. Example: the source says "Party B shall not have a right to terminate for convenience" -- generated text stating "Party B may terminate for cause" is NOT a fidelity issue, since "for cause" and "for convenience" are distinct legal bases and the source never denies the "for cause" right at all. Only flag this pattern when the generated text uses the SAME named basis the source specifically denies.
- Output language: {language}. Write the explanation in {language}.
""".strip()

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a strict JSON legal drafting fidelity "
                        "checker. Return only valid JSON and never add "
                        "markdown."
                    ),
                },
                {
                    "role": "user",
                    "content": prompt,
                },
            ],
            temperature=0.0,
            response_format={
                "type": "json_object"
            },
        )

        content = response.choices[0].message.content or "{}"
        data = json.loads(content)

        fidelity_issue = bool(data.get("fidelity_issue"))
        explanation = str(data.get("explanation") or "")

        # General, concept-level grounding check: verify the AI's
        # fidelity_issue=True claim against the actual, deterministic
        # numeric comparison between source and generated text, rather
        # than pattern-matching the specific wording the AI used to
        # express its (potentially false) concern. If the explanation
        # references a number but no genuine numeric discrepancy exists
        # anywhere in either field (per the same reliable extraction
        # used elsewhere in this module), the claim is unsupported.
        # Confirmed real, new false-positive pattern: "presents the
        # non-compete duration as a flat fact of twelve (12) months,
        # which is incorrect as it should be a proposal" -- twelve
        # months matches the source's own twelve (12) months exactly;
        # there is no discrepancy of any kind to flag. This check
        # generalizes across any phrasing expressing this same
        # underlying (false) claim, rather than requiring a new pattern
        # per wording variant.
        if fidelity_issue and explanation and any(c.isdigit() for c in explanation):
            fallback_check_deltas = find_all_numeric_deltas_for_display(clause_text, fallback_wording)
            compromise_check_deltas = find_all_numeric_deltas_for_display(clause_text, acceptable_compromise)

            if not fallback_check_deltas and not compromise_check_deltas:
                fidelity_issue = False
                explanation = ""

        # Deterministic grounding check: the AI's own explanation must
        # not claim the generated text uses a specific named basis
        # ("for convenience"/"for cause") that isn't actually present in
        # fallback_wording. Confirmed real bug: the explanation claimed
        # "Provider may terminate for convenience" when the actual
        # fallback_wording said "Provider may terminate upon mutual
        # agreement" -- a fabricated quote about the AI's own input.
        # Replaces the explanation with a safe, generic, accurate
        # alternative rather than exposing a demonstrably wrong claim.
        if fidelity_issue and explanation:
            explanation_lower = explanation.lower()
            fallback_lower = str(fallback_wording or "").lower()

            for basis_term in ("for convenience", "for cause", "sans motif", "pour motif", "لغير سبب", "لسبب"):
                if basis_term not in explanation_lower:
                    continue

                # Check proximity of the basis term to "provider"
                # specifically, not just presence anywhere in the text
                # -- the source clause can legitimately mention the same
                # basis term for a DIFFERENT party (e.g. "Client may
                # terminate for convenience"), which should not ground
                # a claim specifically about Provider.
                term_grounded_near_provider = False
                search_start = 0
                while True:
                    idx = fallback_lower.find("provider", search_start)
                    if idx == -1:
                        break
                    window = fallback_lower[idx: idx + 80]
                    if basis_term in window:
                        term_grounded_near_provider = True
                        break
                    search_start = idx + 1

                if not term_grounded_near_provider:
                    _ungrounded_explanation_fallback = {
                        "en": "The generated wording appears to introduce or alter a right in a way that may not match the source clause; manual review recommended.",
                        "fr": "Le texte généré semble introduire ou modifier un droit d'une manière qui pourrait ne pas correspondre à la clause source ; une revue manuelle est recommandée.",
                        "ar": "يبدو أن الصياغة المُولّدة تُدخل أو تُعدّل حقاً بطريقة قد لا تتطابق مع البند المصدر؛ يُنصح بمراجعة يدوية.",
                    }
                    explanation = _ungrounded_explanation_fallback.get(
                        language, _ungrounded_explanation_fallback["en"]
                    )
                    break

        # Deterministic reformulation check: the AI's own explanation
        # can follow an ambiguous "incorrectly states X ... without Y"
        # structure that reads as though the number X itself were wrong,
        # even when X is objectively accurate and Y (an omitted
        # qualifier) is the actual issue. Confirmed real bug: explanation
        # said "incorrectly states the delivery period as five (5)
        # business days without the penalty clause" -- "five (5) business
        # days" is correct per the source; only "without penalty" was
        # omitted, but the sentence structure implies the number is the
        # error. Detects this pattern by checking whether the specific
        # number quoted in the explanation actually appears in the
        # source clause (i.e. is accurate), and if so, reframes the
        # explanation to lead clearly with the omission instead.
        if fidelity_issue and explanation:
            omission_marker_match = re.search(
                r"\b(without|sans|دون)\b",
                explanation,
                re.IGNORECASE,
            )

            if omission_marker_match:
                marker_start = omission_marker_match.start()
                marker_end = omission_marker_match.end()
                quoted_number_phrase = explanation[:marker_start].strip().rstrip(",.;:")

                remainder = explanation[marker_end:].strip()
                boundary_match = re.search(r"[,.;]", remainder)
                omitted_phrase = (
                    remainder[: boundary_match.start()] if boundary_match else remainder
                ).strip()

                source_numbers = extract_numbers_with_units(clause_text or "")
                quoted_numbers = extract_numbers_with_units(quoted_number_phrase)

                if quoted_numbers and omitted_phrase and set(quoted_numbers) & set(source_numbers):
                    _reframed_omission_explanation = {
                        "en": f"The generated text correctly states the relevant figure, but omits \"{omitted_phrase}\", which was present in the original clause.",
                        "fr": f"Le texte généré indique correctement le chiffre concerné, mais omet « {omitted_phrase} », qui figurait dans la clause d'origine.",
                        "ar": f"يذكر النص المُولّد الرقم المعني بشكل صحيح، لكنه يحذف \"{omitted_phrase}\" الموجودة في البند الأصلي.",
                    }
                    explanation = _reframed_omission_explanation.get(
                        language, _reframed_omission_explanation["en"]
                    )

        # Reformulation for a second common pattern: "incorrectly states
        # that X, which changes/alters the original Y" -- a more
        # conceptual delta (e.g. a liability cap FORMULA changing, not
        # just a simple number swap) than the "X instead of Y" pattern
        # handled below. Confirmed real case: "incorrectly states that
        # liability shall not exceed twice the total fees, which
        # changes the original cap of the total fees paid or payable."
        if fidelity_issue and explanation:
            states_that_match = re.search(
                r"incorrectly states that (.+?), which (?:changes|alters) the original (.+?)(?:\.|$)",
                explanation,
                re.IGNORECASE,
            )
            if not states_that_match:
                states_that_match = re.search(
                    r"incorrectly states that (.+?), whereas the original clause \w+ it at (.+?)(?:\.|$)",
                    explanation,
                    re.IGNORECASE,
                )
            if states_that_match:
                new_claim = states_that_match.group(1).strip()
                original_claim = states_that_match.group(2).strip()
                original_claim = re.sub(r"^(?:the|a|an)\s+", "", original_claim, flags=re.IGNORECASE)
                _states_that_reframed = {
                    "en": f"The generated fallback states that {new_claim}, which differs from the original (the {original_claim}). Manual review recommended to confirm that this change is intentional.",
                    "fr": f"Le texte généré indique que {new_claim}, ce qui diffère de l'original (le {original_claim}). Une revue manuelle est recommandée pour confirmer que ce changement est intentionnel.",
                    "ar": f"يذكر النص المُولّد أن {new_claim}، وهو ما يختلف عن الأصل ({original_claim}). يُنصح بمراجعة يدوية للتأكد من أن هذا التغيير مقصود.",
                }
                explanation = _states_that_reframed.get(
                    language, _states_that_reframed["en"]
                )

        # General reformulation for the most common fidelity pattern: a
        # pure numeric change presented as an error ("incorrectly states
        # X instead of Y"). fallback_wording and acceptable_compromise
        # are negotiation-proposal fields by design -- a number
        # genuinely differing from the source is not inherently a
        # mistake, so this reframes the note to a neutral "changes the
        # source term from Y to X, manual review recommended to confirm
        # this change is intentional" -- keeping the useful
        # difference-detection signal while removing the implication of
        # an established error. Reuses the AI's own already-correct
        # number pairing (extracted from its explanation) rather than
        # re-deriving which numbers correspond to which, avoiding a
        # fresh source of mismatched pairing errors.
        if fidelity_issue and explanation:
            connector_match = re.search(
                r"\s+(?:instead of|rather than|au lieu d[eu]|plutôt que|بدلاً من|بدل)\s+",
                explanation,
                re.IGNORECASE,
            )

            if connector_match:
                before_text = explanation[: connector_match.start()]
                after_text = explanation[connector_match.end():]
                after_text = re.sub(
                    r"^(?:the\s+original\s+|l['e]\s*|le\s+|la\s+)",
                    "",
                    after_text,
                    flags=re.IGNORECASE,
                )

                _number_with_context = re.compile(
                    r"\(?\d[\d.,]*%?\)?\s*(?:percent|days?|months?|years?|business\s+days?|"
                    r"jours?|mois|ans?|jours?\s+ouvrables?|"
                    r"يوماً?|أيام|شهراً?|أشهر|سنة|سنوات|أيام\s+عمل)?",
                    re.IGNORECASE,
                )

                before_matches = [
                    m for m in _number_with_context.finditer(before_text)
                    if any(c.isdigit() for c in m.group(0))
                ]
                after_matches = [
                    m for m in _number_with_context.finditer(after_text)
                    if any(c.isdigit() for c in m.group(0))
                ]

                new_value = before_matches[-1].group(0).strip() if before_matches else ""
                original_value = after_matches[0].group(0).strip() if after_matches else ""

                if new_value and original_value:
                    # Determine which field actually contains new_value,
                    # so the note correctly directs the reviewer to the
                    # right field rather than always saying "fallback".
                    # Checks the digit portion only (e.g. "60" rather
                    # than the full "(60) days" display string), since
                    # each field may phrase the surrounding words
                    # slightly differently while still containing the
                    # same underlying number.
                    new_value_digits = "".join(c for c in new_value if c.isdigit() or c == ".")
                    in_fallback = new_value_digits and new_value_digits in str(fallback_wording or "")
                    in_compromise = new_value_digits and new_value_digits in str(acceptable_compromise or "")

                    if in_compromise and not in_fallback:
                        field_label = {
                            "en": "acceptable compromise",
                            "fr": "compromis acceptable",
                            "ar": "التسوية المقبولة",
                        }
                    else:
                        field_label = {
                            "en": "fallback",
                            "fr": "texte",
                            "ar": "النص",
                        }

                    _neutral_delta_explanation = {
                        "en": f"The generated {field_label['en']} changes the source term from {original_value} to {new_value}. Manual review recommended to confirm that this change is intentional.",
                        "fr": f"Le {field_label['fr']} généré modifie le terme source de {original_value} à {new_value}. Une revue manuelle est recommandée pour confirmer que ce changement est intentionnel.",
                        "ar": f"يُغيّر {field_label['ar']} المُولّد الشرط الأصلي من {original_value} إلى {new_value}. يُنصح بمراجعة يدوية للتأكد من أن هذا التغيير مقصود.",
                    }
                    explanation = _neutral_delta_explanation.get(
                        language, _neutral_delta_explanation["en"]
                    )

        return {
            "fidelity_issue": fidelity_issue,
            "explanation": explanation,
        }
    except Exception:
        return {"fidelity_issue": False, "explanation": ""}


def apply_rule_based_risk(
    ai_result: dict,
    clause: str,
    language: str,
) -> dict:

    rule_result = analyze_risk(
        clause,
        language
    )

    rule_level = rule_result.get(
        "risk_level",
        "low"
    )

    if rule_level == "high":

        track_change(
            ai_result,
            field="risk_level",
            old=ai_result.get("risk_level"),
            new="high",
            source="apply_rule_based_risk",
        )

        ai_result["_meta"][
            "risk_modified_by"
        ].append(
            "apply_rule_based_risk"
        )

        track_change(
            ai_result,
            field="negotiation_priority",
            old=ai_result.get("negotiation_priority"),
            new="high",
            source="apply_rule_based_risk",
        )

        if not ai_result.get("red_flag"):
            mutate_analysis(
                ai_result,
                field="red_flag",
                value=True,
                source="apply_rule_based_risk",
            )

        if not ai_result.get("red_flag_reason"):

            mutate_analysis(
                ai_result,
                field="red_flag_reason",
                value=safe_str(
                    rule_result.get("trigger")
                ),
                source="apply_rule_based_risk",
            )

    elif (
        rule_level == "medium"
        and ai_result.get("risk_level") == "low"
    ):

        track_change(
            ai_result,
            field="risk_level",
            old=ai_result.get("risk_level"),
            new="medium",
            source="apply_rule_based_risk",
        )

        ai_result["_meta"][
            "risk_modified_by"
        ].append(
            "apply_rule_based_risk"
        )

        if (
            ai_result.get(
                "negotiation_priority"
            ) == "low"
        ):
            track_change(
                ai_result,
                field="negotiation_priority",
                old=ai_result.get("negotiation_priority"),
                new="medium",
                source="apply_rule_based_risk",
            )

    ai_result["trigger"] = rule_result.get(
        "trigger"
    )

    return ai_result


def apply_reasoning_quality_gate(
    analysis: dict,
    clause_text: str,
    language: str,
) -> dict:

    text = safe_str(clause_text).lower()

    detail_fields = [
        "recommendation",
        "negotiation_advice",
        "legal_insight",
        "safer_alternative",
    ]

    UNSUPPORTED_MARKET_PHRASES = [
        "may be considered high",
        "above market",
        "below market",
        "market standard",
        "standard for the industry",
        "standard practice",
        "industry standard",
        "common practice",
        "competitive",
        "too high",
        "too low",

        "peut être considéré comme élevé",
        "supérieur au marché",
        "normes du marché",
        "pratique courante",
        "pratique standard",
        "élevé",
        "faible",

        "ممارسة شائعة",
        "مرتفع",
        "plus compétitif",
        "أكثر تنافسية",
        "pratiques du marché",
        "market practice",
    ]

    dangerous_terms = [
        "dangerous",
        "hazardous",
        "illegal",
        "unlawful",
        "criminal",
        "fraud",
        "dangerous activity",

        "dangereux",
        "illégal",
        "fraude",

        "خطير",
        "خطيرة",
        "مخالفة",
        "غير قانوني",
        "احتيال",
    ]

    cleanup_fields = [
        "explanation_simple",
        "recommendation",
        "legal_insight",
        "negotiation_advice",
        "safer_alternative",
    ]

    for field in cleanup_fields:
        value = safe_str(
            analysis.get(field)
        )

        lowered_value = value.lower()

        for term in dangerous_terms:
            if (
                term in lowered_value
                and term not in text
            ):
                analysis[field] = ""
                break

    hallucination_guard = {
        "illegal activity": [
            "illegal",
            "unlawful",
            "criminal",
            "crime",
            "activité illégale",
            "illégal",
            "criminel",
            "نشاط غير قانوني",
            "غير قانوني",
            "جريمة",
        ],
        "fraud": [
            "fraud",
            "fraudulent",
            "misrepresentation",
            "fraude",
            "frauduleux",
            "احتيال",
            "تدليس",
        ],
        "abusive conduct": [
            "abusive",
            "abuse",
            "bad faith",
            "abusif",
            "abus",
            "سلوك تعسفي",
            "تعسف",
        ],
        "penalties": [
            "penalty",
            "fine",
            "liquidated damages",
            "late payment penalty",
            "pénalité",
            "amende",
            "dommages-intérêts forfaitaires",
            "غرامة",
            "جزاء",
            "تعويضات مقطوعة",
        ],
        "obligations": [
            "shall",
            "must",
            "is required to",
            "obligation",
            "obligé",
            "doit",
            "est tenu",
            "يلتزم",
            "يجب",
            "التزام",
        ],
    }

    for concept, evidence_terms in hallucination_guard.items():
        concept_present = any(
            term in text
            for term in evidence_terms
        )

        if concept_present:
            continue

        for field in detail_fields + [
            "explanation_simple",
            "why_it_matters",
        ]:
            value = safe_str(
                analysis.get(field)
            )

            if concept in value.lower():
                analysis[field] = ""

    generic_detail_phrases = [
        "avoid disputes",
        "future disputes",
        "ensure clarity",
        "consider negotiating",
        "market standards",
        "potential disputes",
        "may lead to",
        "could impact",
        "more favorable",
        "business growth",
        "operational flexibility",
        "sets the foundation",
        "while this clause is standard",
        "avoid ambiguity",
        "market conditions change",
        "cash flow is a concern",
        "work-life balance",

        "éviter les litiges",
        "éviter toute ambiguïté",
        "assurer la clarté",
        "envisager de négocier",
        "normes du marché",
        "risques potentiels",
        "conditions du marché",

        "تجنب النزاعات",
        "تجنب الغموض",
        "ضمان الوضوح",
        "معايير السوق",
        "مخاطر محتملة",
        "ظروف السوق",
    ]

    for field in detail_fields:
        value = safe_str(
            analysis.get(field)
        ).lower()

        if any(
            phrase in value
            for phrase in generic_detail_phrases
        ):
            analysis[field] = ""

    analysis["has_details"] = any(
        safe_str(
            analysis.get(field)
        )
        for field in detail_fields
    )

    if (
        not safe_str(analysis.get("explanation_simple"))
        and analysis.get("risk_level") in {"medium", "high"}
    ):
        combined = " ".join([
            safe_str(analysis.get("clause_title")),
            safe_str(analysis.get("title")),
            safe_str(analysis.get("clause_type")),
            safe_str(analysis.get("quoted_text")),
            safe_str(clause_text),
        ]).lower()

        if (
            "service level" in combined
            or "uptime" in combined
            or "niveau de service" in combined
            or "disponibilité" in combined
            or "مستوى الخدمة" in combined
            or "الجاهزية" in combined
            or "توفر الخدمة" in combined
        ):
            analysis["explanation_simple"] = (
                "The clause defines uptime or service availability obligations."
                if language == "en"
                else
                "La clause définit les engagements de disponibilité du service."
                if language == "fr"
                else
                "تحدد هذه المادة التزامات توفر الخدمة أو نسبة الجاهزية."
            )

        elif "fees" in combined or "payment" in combined or "paiement" in combined or "الدفع" in combined or "الرسوم" in combined:
            analysis["explanation_simple"] = (
                "The clause defines payment timing and financial obligations."
                if language == "en"
                else
                "Cette clause définit les délais de paiement et les obligations financières."
                if language == "fr"
                else
                "تحدد هذه المادة مواعيد الدفع والالتزامات المالية."
            )

        else:
            analysis["explanation_simple"] = ""

    for field in [
        "legal_insight",
        "recommendation",
    ]:
        value = str(
            analysis.get(field, "")
        ).lower()

        if any(
            p in value
            for p in UNSUPPORTED_MARKET_PHRASES
        ):
            analysis[field] = ""

    return analysis


def _canonical_role_key(value: str) -> str:
    normalized = safe_str(value).lower()
    normalized = normalized.replace("_", " ").replace("-", " ")
    normalized = " ".join(normalized.split())

    removable_prefixes = (
        "the ", "a ", "an ",
        "le ", "la ", "les ", "l'", "l’",
        "ال",
    )

    changed = True
    while changed:
        changed = False
        for prefix in removable_prefixes:
            if normalized.startswith(prefix) and len(normalized) > len(prefix):
                normalized = normalized[len(prefix):].strip()
                changed = True

    return normalized


def _is_employment_contract_family(
    party_roles: dict | None,
    clause_text: str = "",
) -> bool:
    if not isinstance(party_roles, dict):
        return False

    family_blob = " ".join([
        safe_str(party_roles.get("family")),
        safe_str(party_roles.get("contract_family")),
        safe_str(party_roles.get("contract_type")),
    ]).lower()

    employment_family_terms = {
        "employment", "employment agreement", "employment contract",
        "employee agreement", "employer employee",
        "contrat de travail", "contrat d'emploi", "emploi",
        "عقد عمل", "عقد توظيف", "توظيف",
    }

    if any(term in family_blob for term in employment_family_terms):
        return True

    role_a = _canonical_role_key(party_roles.get("party_a"))
    role_b = _canonical_role_key(party_roles.get("party_b"))

    employer_terms = {"employer", "employeur", "صاحب العمل"}
    employee_terms = {"employee", "salarié", "salarie", "employé", "employe", "الموظف", "عامل"}

    return (
        role_a in employer_terms and role_b in employee_terms
    ) or (
        role_b in employer_terms and role_a in employee_terms
    )


def _build_party_registry_maps(party_roles: dict | None) -> tuple[dict, dict]:
    party_a = safe_str((party_roles or {}).get("party_a"))
    party_b = safe_str((party_roles or {}).get("party_b"))

    role_to_party = {
        "provider": "party_a",
        "service provider": "party_a",
        "supplier": "party_a",
        "vendor": "party_a",
        "contractor": "party_a",
        "consultant": "party_a",
        "seller": "party_a",
        "licensor": "party_a",
        "lessor": "party_a",
        "landlord": "party_a",
        "lender": "party_a",
        "franchisor": "party_a",
        "distributor": "party_a",
        "reseller": "party_a",
        "manufacturer": "party_a",
        "insurer": "party_a",
        "principal": "party_a",
        "agent": "party_a",
        "controller": "party_a",

        "client": "party_b",
        "customer": "party_b",
        "buyer": "party_b",
        "licensee": "party_b",
        "lessee": "party_b",
        "tenant": "party_b",
        "borrower": "party_b",
        "franchisee": "party_b",
        "insured": "party_b",
        "recipient": "party_b",
        "processor": "party_b",
        "owner": "party_b",
        "operator": "party_b",
        "partner": "party_b",

        "prestataire": "party_a",
        "fournisseur": "party_a",
        "vendeur": "party_a",
        "entrepreneur": "party_a",
        "concédant": "party_a",
        "concedant": "party_a",
        "bailleur": "party_a",
        "prêteur": "party_a",
        "preteur": "party_a",
        "franchiseur": "party_a",
        "assureur": "party_a",
        "mandant": "party_a",

        "acheteur": "party_b",
        "licencié": "party_b",
        "licencie": "party_b",
        "locataire": "party_b",
        "emprunteur": "party_b",
        "franchisé": "party_b",
        "franchise": "party_b",
        "assuré": "party_b",
        "assure": "party_b",
        "destinataire": "party_b",

        "مقدم الخدمة": "party_a",
        "مزود الخدمة": "party_a",
        "المورد": "party_a",
        "المورّد": "party_a",
        "البائع": "party_a",
        "المقاول": "party_a",
        "المستشار": "party_a",
        "المرخص": "party_a",
        "المرخِّص": "party_a",
        "المؤجر": "party_a",
        "المقرض": "party_a",
        "مانح الامتياز": "party_a",
        "المؤمن": "party_a",

        "العميل": "party_b",
        "المشتري": "party_b",
        "المرخص له": "party_b",
        "المرخَّص له": "party_b",
        "المستأجر": "party_b",
        "المقترض": "party_b",
        "صاحب الامتياز": "party_b",
        "المؤمن له": "party_b",
        "المتلقي": "party_b",
        "معالج البيانات": "party_b",
    }

    if party_a:
        role_to_party[_canonical_role_key(party_a)] = "party_a"

    if party_b:
        role_to_party[_canonical_role_key(party_b)] = "party_b"

    party_to_display = {
        "party_a": party_a or {
            "en": "Party A",
            "fr": "Partie A",
            "ar": "الطرف أ",
        },
        "party_b": party_b or {
            "en": "Party B",
            "fr": "Partie B",
            "ar": "الطرف ب",
        },
    }

    return role_to_party, party_to_display


def _localized_generic_party(party: str, language: str) -> str:
    labels = {
        "party_a": {"en": "Party A", "fr": "Partie A", "ar": "الطرف أ"},
        "party_b": {"en": "Party B", "fr": "Partie B", "ar": "الطرف ب"},
    }
    return labels.get(party, labels["party_a"]).get(language, labels[party]["en"])


def _neutral_relevant_party(language: str) -> str:
    return {
        "en": "the relevant party",
        "fr": "la partie concernée",
        "ar": "الطرف المعني",
    }.get(language, "the relevant party")


def _neutral_relevant_party_bare(language: str) -> str:
    """
    Article-less variant, for use after a determiner like 'any' that
    does not grammatically combine with a leading 'the' (e.g. 'any
    [COMPANY]' should become 'any relevant party', not 'any the
    relevant party').
    """
    return {
        "en": "relevant party",
        "fr": "partie concernée",
        "ar": "طرف معني",
    }.get(language, "relevant party")


def _neutral_relevant_party_possessive(language: str) -> str:
    return {
        "en": "the relevant party's",
        "fr": "de la partie concernée",
        "ar": "الخاصة بالطرف المعني",
    }.get(language, "the relevant party's")


def _neutral_specified_location(language: str) -> str:
    return {
        "en": "the specified location",
        "fr": "le lieu concerné",
        "ar": "الموقع المحدد",
    }.get(language, "the specified location")


def _neutral_specified_date(language: str) -> str:
    return {
        "en": "the specified date",
        "fr": "la date concernée",
        "ar": "التاريخ المحدد",
    }.get(language, "the specified date")


def _neutral_specified_amount(language: str) -> str:
    return {
        "en": "the specified amount",
        "fr": "le montant concerné",
        "ar": "المبلغ المحدد",
    }.get(language, "the specified amount")


def _neutral_specified_contact(language: str) -> str:
    return {
        "en": "the specified contact details",
        "fr": "les coordonnées concernées",
        "ar": "بيانات الاتصال المحددة",
    }.get(language, "the specified contact details")


# Party-name/role tokens use _neutral_relevant_party (a person or
# organization reference). Each is checked in possessive form FIRST
# (longer match), then bare form, so "[ORGANIZATION]'s" is not left
# with a dangling "'s" after only the bare token gets replaced.
_PII_PLACEHOLDER_REPLACEMENTS = [
    "ORGANIZATION", "COMPANY", "PARTY_1", "PARTY_2", "PARTY_3",
    "PERSON", "CLIENT", "SERVICE_PROVIDER", "SUPPLIER", "VENDOR",
    "BUYER", "SELLER", "LENDER", "BORROWER", "LICENSOR", "LICENSEE",
    "LESSOR", "LESSEE", "SHAREHOLDER",
]


def _neutral_employer(language: str) -> str:
    return {
        "en": "the Employer",
        "fr": "l'Employeur",
        "ar": "صاحب العمل",
    }.get(language, "the Employer")


def _neutral_employer_possessive(language: str) -> str:
    return {
        "en": "the Employer's",
        "fr": "de l'Employeur",
        "ar": "الخاصة بصاحب العمل",
    }.get(language, "the Employer's")


def _neutral_employee(language: str) -> str:
    return {
        "en": "the Employee",
        "fr": "le Salarié",
        "ar": "الموظف",
    }.get(language, "the Employee")


def _neutral_employee_possessive(language: str) -> str:
    return {
        "en": "the Employee's",
        "fr": "du Salarié",
        "ar": "الخاصة بالموظف",
    }.get(language, "the Employee's")

# Non-party tokens need semantically different, category-appropriate
# replacement text rather than "the relevant party" (e.g. a redacted
# territorial scope should not read as though it names a party).
_PII_PLACEHOLDER_CATEGORY_REPLACEMENTS = {
    "LOCATION": _neutral_specified_location,
    "ADDRESS": _neutral_specified_location,
    "CITY": _neutral_specified_location,
    "COUNTRY": _neutral_specified_location,
    "DATE": _neutral_specified_date,
    "AMOUNT": _neutral_specified_amount,
    "MONEY": _neutral_specified_amount,
    "EMAIL": _neutral_specified_contact,
    "PHONE": _neutral_specified_contact,
    "PHONE_NUMBER": _neutral_specified_contact,
}


def clean_pii_placeholder_leakage(value, language: str):
    """
    Replaces any raw PII-redaction placeholder token (e.g.
    "[ORGANIZATION]", "[PARTY_1]") that leaked verbatim into
    AI-generated text with a readable, neutral equivalent. Recurses
    into dicts and lists. These tokens are meant to be substituted with
    a real display name or a neutral phrase before reaching the user;
    when the AI is given already-redacted clause text as its input, it
    has no way of knowing the bracket token should not be echoed
    verbatim, so this is applied as a final, universal cleanup pass
    rather than relying on every individual AI call site to handle it.
    """
    if isinstance(value, dict):
        return {key: clean_pii_placeholder_leakage(item, language) for key, item in value.items()}

    if isinstance(value, list):
        return [clean_pii_placeholder_leakage(item, language) for item in value]

    if not isinstance(value, str) or "[" not in value:
        return value

    neutral = _neutral_relevant_party(language)
    neutral_possessive = _neutral_relevant_party_possessive(language)

    # Matches a pre-existing definite article immediately before the
    # bracket token, in English or French, so it can be stripped before
    # substitution -- the replacement text already carries its own
    # article, so leaving the original one in place produces a
    # duplicated article (e.g. "the the specified location", "dans le
    # le lieu concerné").
    _article_prefix = r"\b(?:the|le|la|les|l['\u2019])\s*"

    # Matches a pre-existing indefinite determiner (any/some/each/every
    # in English, tout/toute/tous/toutes in French) immediately before
    # the bracket token. Unlike a duplicate definite article, this
    # determiner carries meaning (broad, unrestricted scope) that must
    # be preserved -- so rather than stripping it, the bare
    # (article-less) replacement variant is used instead, avoiding an
    # ungrammatical double-determiner (e.g. "any [COMPANY]" becoming
    # "any the relevant party" instead of the correct "any relevant
    # party").
    _determiner_prefix = r"\b(any|some|each|every|tout|toute|tous|toutes)(\s+)"

    output = value

    neutral_bare = _neutral_relevant_party_bare(language)
    neutral_bare_possessive = neutral_bare + "'s" if language != "fr" else "de " + neutral_bare
    for token in _PII_PLACEHOLDER_REPLACEMENTS:
        output = re.sub(
            _determiner_prefix + r"\[" + re.escape(token) + r"\]'s",
            r"\1\2" + neutral_bare_possessive,
            output,
            flags=re.IGNORECASE,
        )
        output = re.sub(
            _determiner_prefix + r"\[" + re.escape(token) + r"\]\u2019s",
            r"\1\2" + neutral_bare_possessive,
            output,
            flags=re.IGNORECASE,
        )
        output = re.sub(
            _determiner_prefix + r"\[" + re.escape(token) + r"\]",
            r"\1\2" + neutral_bare,
            output,
            flags=re.IGNORECASE,
        )

    for token in _PII_PLACEHOLDER_REPLACEMENTS:
        output = re.sub(_article_prefix + r"\[" + re.escape(token) + r"\]'s", neutral_possessive, output, flags=re.IGNORECASE)
        output = re.sub(_article_prefix + r"\[" + re.escape(token) + r"\]\u2019s", neutral_possessive, output, flags=re.IGNORECASE)
        output = re.sub(_article_prefix + r"\[" + re.escape(token) + r"\]", neutral, output, flags=re.IGNORECASE)
        output = output.replace(f"[{token}]'s", neutral_possessive)
        output = output.replace(f"[{token}]\u2019s", neutral_possessive)
        output = output.replace(f"[{token}]", neutral)

    employer_possessive = _neutral_employer_possessive(language)
    employer_bare = _neutral_employer(language)
    output = re.sub(_article_prefix + r"\[EMPLOYER\]'s", employer_possessive, output, flags=re.IGNORECASE)
    output = re.sub(_article_prefix + r"\[EMPLOYER\]\u2019s", employer_possessive, output, flags=re.IGNORECASE)
    output = re.sub(_article_prefix + r"\[EMPLOYER\]", employer_bare, output, flags=re.IGNORECASE)
    output = output.replace("[EMPLOYER]'s", employer_possessive)
    output = output.replace("[EMPLOYER]\u2019s", employer_possessive)
    output = output.replace("[EMPLOYER]", employer_bare)

    employee_possessive = _neutral_employee_possessive(language)
    employee_bare = _neutral_employee(language)
    output = re.sub(_article_prefix + r"\[EMPLOYEE\]'s", employee_possessive, output, flags=re.IGNORECASE)
    output = re.sub(_article_prefix + r"\[EMPLOYEE\]\u2019s", employee_possessive, output, flags=re.IGNORECASE)
    output = re.sub(_article_prefix + r"\[EMPLOYEE\]", employee_bare, output, flags=re.IGNORECASE)
    output = output.replace("[EMPLOYEE]'s", employee_possessive)
    output = output.replace("[EMPLOYEE]\u2019s", employee_possessive)
    output = output.replace("[EMPLOYEE]", employee_bare)

    for token, replacement_fn in _PII_PLACEHOLDER_CATEGORY_REPLACEMENTS.items():
        replacement = replacement_fn(language)
        output = re.sub(_article_prefix + r"\[" + re.escape(token) + r"\]'s", replacement, output, flags=re.IGNORECASE)
        output = re.sub(_article_prefix + r"\[" + re.escape(token) + r"\]\u2019s", replacement, output, flags=re.IGNORECASE)
        output = re.sub(_article_prefix + r"\[" + re.escape(token) + r"\]", replacement, output, flags=re.IGNORECASE)
        output = output.replace(f"[{token}]'s", replacement)
        output = output.replace(f"[{token}]\u2019s", replacement)
        output = output.replace(f"[{token}]", replacement)

    return output


def enforce_party_registry_on_clause_output(
    analysis: dict,
    party_roles: dict | None,
    language: str,
    clause_text: str = "",
) -> dict:
    if not isinstance(analysis, dict):
        return analysis

    language = normalize_language(language)
    party_roles = party_roles or {}

    role_to_party, _party_to_display = _build_party_registry_maps(party_roles)
    is_employment = _is_employment_contract_family(party_roles, clause_text)

    def normalize_favours(value: Any) -> str:
        raw = safe_str(value)
        key = _canonical_role_key(raw)

        static_values = {
            "balanced": "balanced",
            "unclear": "unclear",
            "équilibré": "balanced",
            "equilibre": "balanced",
            "équilibre": "balanced",
            "non clair": "unclear",
            "غير واضح": "unclear",
            "متوازن": "balanced",
        }

        if key in static_values:
            return static_values[key]

        if key in {"party a", "party 1", "contracting party a", "partie a", "partie 1", "الطرف أ", "الطرف الاول", "الطرف الأول"}:
            return "party_a"

        if key in {"party b", "party 2", "contracting party b", "partie b", "partie 2", "الطرف ب", "الطرف الثاني"}:
            return "party_b"

        if key in role_to_party:
            if (not is_employment) and key in {
                "employer", "employee", "employeur", "salarié", "salarie",
                "employé", "employe", "صاحب العمل", "الموظف",
            }:
                return "unclear"
            return role_to_party[key]

        return "unclear"

    # Only normalize "favours" when it already exists on this dict.
    # normalize_clause_result() always includes "favours" for a real
    # clause (defaulting to "unclear"), so this never changes clause-level
    # behavior. But this function is also called on the whole
    # document-level final_result (to run its recursive text cleanup via
    # clean_value() below), which never had a "favours" field to begin
    # with -- without this guard, a spurious top-level
    # "favours": "unclear" key gets injected into the overall report,
    # which makes no sense outside a single clause.
    if "favours" in analysis:
        analysis["favours"] = normalize_favours(
            analysis.get("favours", "unclear")
        )

    if is_employment:
        return analysis

    neutral = _neutral_relevant_party(language)
    neutral_possessive = _neutral_relevant_party_possessive(language)

    replacements = {
        "Employer's": neutral_possessive,
        "Employer’s": neutral_possessive,
        "Employers'": neutral_possessive,
        "Employee's": neutral_possessive,
        "Employee’s": neutral_possessive,
        "Employees'": neutral_possessive,
        "Employer": neutral,
        "Employee": "personnel",
        "Employees": "personnel",
        "Employeur": neutral,
        "Employeur's": neutral_possessive,
        "Salarié": "personnel",
        "Salariés": "personnel",
        "Employé": "personnel",
        "Employés": "personnel",
        "صاحب العمل": neutral,
        "الموظف": "الموظفين",
        "الموظفون": "الموظفين",
        "الموظفين": "الموظفين",
    }

    def clean_value(value):
        if isinstance(value, dict):
            return {key: clean_value(item) for key, item in value.items()}

        if isinstance(value, list):
            return [clean_value(item) for item in value]

        if not isinstance(value, str):
            return value

        output = value
        for old, new in replacements.items():
            output = output.replace(old, new)

        output = output.replace("the relevant party's remedies", "the relevant party's remedies")
        output = output.replace("la partie concernée's", "de la partie concernée")
        output = " ".join(output.split())
        return output

    return clean_value(analysis)


def render_canonical_favours_for_display(
    value: str,
    party_roles: dict | None,
    language: str,
) -> str:
    language = normalize_language(language)
    party_roles = party_roles or {}

    value_key = _canonical_role_key(value)

    if value_key in {"balanced", "équilibré", "equilibre", "متوازن"}:
        return {
            "en": "Balanced",
            "fr": "Équilibré",
            "ar": "متوازن",
        }.get(language, "Balanced")

    if value_key in {"unclear", "non clair", "غير واضح"}:
        return {
            "en": "Unclear",
            "fr": "Non clair",
            "ar": "غير واضح",
        }.get(language, "Unclear")

    if value_key == "party a":
        return safe_str(party_roles.get("party_a")) or _localized_generic_party("party_a", language)

    if value_key == "party b":
        return safe_str(party_roles.get("party_b")) or _localized_generic_party("party_b", language)

    return safe_str(value) or {
        "en": "Unclear",
        "fr": "Non clair",
        "ar": "غير واضح",
    }.get(language, "Unclear")


_LLM_PLACEHOLDER_LEAK_PATTERN = re.compile(r"\[[^\]]*[a-z ][^\]]*\]")

_KNOWN_PLACEHOLDER_TOKENS = {
    "tbd", "xxx", "xxxx", "n/a", "insert", "amount", "todo",
    "placeholder", "x amount", "specify", "tbc", "à préciser",
    "à compléter", "يحدد لاحقا", "يُحدَّد لاحقاً",
}


def _has_llm_placeholder_leak(value) -> bool:
    """
    Detects an unfilled instructional placeholder the LLM left in its own
    generated text -- e.g. "[insert amount]", "[X amount]", "[TBD]" --
    which must never reach the user as though it were real contract
    language. Deliberately distinguishes these from our own PII-redaction
    placeholders (e.g. "[PARTY_1]", "[LOCATION]", "[CLIENT]"), which are
    always uppercase with no spaces; an LLM-authored placeholder reliably
    contains a lowercase letter or a space, or matches a small set of
    known all-caps placeholder tokens ("TBD", "XXX"...) that our own
    redaction tags never use.
    """
    text = str(value or "")

    if not text:
        return False

    if _LLM_PLACEHOLDER_LEAK_PATTERN.search(text):
        return True

    for match in re.finditer(r"\[([^\]]*)\]", text):
        if match.group(1).strip().lower() in _KNOWN_PLACEHOLDER_TOKENS:
            return True

    return False


def merge_pipeline_reasoning_enrichment(
    ai_result: dict,
    reasoning: dict,
    clause_text: str = "",
    language: str = "en",
) -> dict:
    """
    Merge the additive fields produced by
    legal_reasoning_templates.get_reasoning_for_text() -- draft wording,
    sector overlays, and cross-clause negotiation intelligence -- into
    ai_result, without ever touching the pre-existing LLM-origin schema
    contract established by normalize_clause_result().

    Rules (all deliberate, to avoid breaking the pipeline):
    - ai_result["market_practice"] is NEVER written here. It is already
      clamped to ALLOWED_MARKET_PRACTICE (standard / aggressive /
      customer_friendly / vendor_friendly / balanced / unusual) from the
      LLM's own output by normalize_clause_result(), which runs earlier
      in analyze_clause(). market_intelligence.py's own "market_practice"
      vocabulary (e.g. "frequently_negotiated") is a different enum for a
      different purpose; bridging the two is a deliberate mapping decision
      to make separately, not something to do silently here.
    - draft_wording_template is only surfaced when it is both marked
      specific AND fully filled in (no leftover "{placeholder}" tokens).
      clause_templates.py currently returns raw, unfilled templates, so
      until real value-filling (render_clause_template with values
      extracted from the contract) is wired in, this means draft wording
      is shown only for the handful of templates that need no
      placeholders at all (e.g. severability) -- never a template with
      visible "{duration}"-style tokens.
    - A defense-in-depth guard additionally strips draft_wording_template
      whenever the clause is typed "dispute_resolution" but the drafted
      text still looks payment-flavored (mentions payer/payee/invoice/
      payment_terms/interest_rate), in case a future classification
      regression reintroduces the payment/governing_law mix-up this was
      built to catch.
    - acceptable_compromise and fallback_wording (part of
      normalize_clause_result()'s fixed schema) are filled ONLY when
      currently empty, so real LLM-produced content is never overwritten.
    - never_accept is always synced to negotiation_boundary when the
      latter is present (which negotiation_intelligence.py guarantees for
      every clause via its universal fallback). This intentionally
      replaces any LLM-produced never_accept text, in favor of the
      deterministic, consistently-worded, trilingual boundary text
      produced by the negotiation-intelligence stack.
    - Brand-new fields (sector_note, negotiation_market_practice,
      negotiation_boundary, negotiation_specific) are simply added as new
      dict keys. This is safe because normalize_clause_result() has
      already executed by the time this function runs -- ai_result is a
      plain, already-normalized dict at this point, and adding new keys
      cannot drop or corrupt any of its existing fields.
    """
    if not reasoning:
        return ai_result

    # Strip an unfilled instructional placeholder the LLM left in its own
    # generated text -- e.g. "with a minimum cap of [insert amount]." or
    # "[X amount]" -- observed leaking into fallback_wording and
    # acceptable_compromise on more than one occasion. These are never
    # real contract language and must not reach the user as though they
    # were. Deliberately distinguishes this from our own PII-redaction
    # placeholders ("[PARTY_1]", "[LOCATION]", "[CLIENT]"...), which are
    # always uppercase with no spaces; an LLM-authored placeholder
    # reliably contains a lowercase letter or a space (or matches a
    # handful of known all-caps placeholder tokens like "TBD"/"XXX"),
    # which our own redaction tags never do. Clearing the field here lets
    # the normal fill-if-empty logic below treat it exactly like a
    # genuinely empty LLM field, rather than shipping a broken sentence.
    for _field in ("fallback_wording", "acceptable_compromise", "never_accept"):
        if _has_llm_placeholder_leak(ai_result.get(_field)):
            ai_result[_field] = ""

    draft_wording = safe_str(reasoning.get("draft_wording_template"))

    has_unfilled_placeholders = (
        "{" in draft_wording
        and "}" in draft_wording
    )

    if (
        draft_wording
        and reasoning.get("draft_wording_is_specific") is True
        and not has_unfilled_placeholders
    ):
        ai_result["draft_wording_template"] = draft_wording
        ai_result["draft_wording_is_specific"] = True
        ai_result["draft_wording_disclaimer"] = reasoning.get(
            "draft_wording_disclaimer", ""
        )

    if reasoning.get("sector_note"):
        ai_result["sector_note"] = reasoning["sector_note"]

    if ai_result.get("clause_type") == "dispute_resolution":
        wrong_payment_terms = [
            "payer",
            "payee",
            "invoice",
            "payment_terms",
            "interest_rate",
        ]

        draft = safe_str(ai_result.get("draft_wording_template")).lower()

        if any(term in draft for term in wrong_payment_terms):
            ai_result.pop("draft_wording_template", None)
            ai_result.pop("draft_wording_is_specific", None)
            ai_result.pop("draft_wording_disclaimer", None)

    if reasoning.get("negotiation_market_practice"):
        ai_result["negotiation_market_practice"] = reasoning[
            "negotiation_market_practice"
        ]

    if reasoning.get("negotiation_specific") is not None:
        ai_result["negotiation_specific"] = reasoning["negotiation_specific"]

    # Cross-field negotiation consistency check.
    #
    # Root cause observed across multiple, unrelated clause types
    # (termination, SLA, restrictive covenants): an LLM can populate
    # "fallback_wording" and "acceptable_compromise" independently of each
    # other for the SAME clause, with no guarantee they describe the same
    # negotiation position -- e.g. fallback_wording proposing an
    # 18-month restriction while acceptable_compromise proposes 12 months
    # for the identical clause. Confirmed generic (not tied to one
    # clause_type), so the fix is generic too:
    #
    #   1. If the LLM filled BOTH fields itself, check them for numeric
    #      inconsistency (detect_negotiation_inconsistency, matching on
    #      shared units like months/days/years/percentage/count).
    #   2. If inconsistent AND negotiation_intelligence.py produced its
    #      own internally-consistent pair for this clause (currently:
    #      restrictive covenants, where both values are derived from the
    #      same recommended_duration_months() call), prefer that
    #      guaranteed-consistent pair over the LLM's contradictory one.
    #   3. If inconsistent but no consistent alternative is available for
    #      this clause_type, don't silently pick a side -- flag it via
    #      negotiation_consistency_warning so it surfaces for review
    #      instead of shipping contradictory guidance unflagged.
    llm_fallback_wording = safe_str(ai_result.get("fallback_wording"))
    llm_acceptable_compromise = safe_str(ai_result.get("acceptable_compromise"))
    our_fallback_wording = safe_str(reasoning.get("fallback_wording"))
    our_acceptable_compromise = safe_str(reasoning.get("acceptable_compromise"))

    # Clause types where an auto-fix library replacement could silently
    # rewrite substantive legal scope (which party is restricted, mutual
    # vs unilateral obligations, protected interest, competitor
    # universe, liability allocation, etc.) rather than just repairing a
    # technical inconsistency. Confirmed real, serious issue: a
    # unilateral "Provider shall not... to any of the five (5) named
    # direct competitors of Client" was silently auto-replaced with a
    # mutual "Neither party shall... with any named direct competitor
    # of that party" -- changing who is restricted, how many parties
    # are bound, and dropping the specific competitor count entirely.
    # For these clause types, the library text is offered for human
    # review rather than silently applied.
    _MATERIAL_AUTOFIX_DOMAINS = {
        "termination", "liability", "indemnity", "indemnification",
        "restrictive_covenants", "non_compete", "non_solicitation",
        "intellectual_property", "work_product", "exclusivity",
        "data_privacy_security", "data_protection", "confidentiality",
        "assignment", "change_of_control",
    }

    if llm_fallback_wording and llm_acceptable_compromise:
        if detect_negotiation_inconsistency(
            llm_fallback_wording,
            llm_acceptable_compromise,
        ):
            if (
                reasoning.get("negotiation_specific")
                and our_fallback_wording
                and our_acceptable_compromise
                and not detect_negotiation_inconsistency(
                    our_fallback_wording,
                    our_acceptable_compromise,
                )
            ):
                clause_type_for_gate = normalize_clause_type(
                    str(ai_result.get("clause_type") or "")
                )

                if clause_type_for_gate in _MATERIAL_AUTOFIX_DOMAINS:
                    # Suggest, don't silently apply: keep the LLM's
                    # original text as the displayed fallback, and
                    # expose the library alternative for human review
                    # instead of overwriting.
                    ai_result["negotiation_consistency_review_required"] = True
                    ai_result["suggested_fallback_wording"] = our_fallback_wording
                    ai_result["suggested_acceptable_compromise"] = our_acceptable_compromise
                    _review_note = {
                        "en": "The generated fallback wording appears internally inconsistent with the acceptable compromise. A library-based replacement is available for reviewer approval, but was not applied automatically since this clause type can involve material legal scope (party allocation, restricted conduct, or liability terms).",
                        "fr": "Le texte généré du fallback semble incohérent en interne avec le compromis acceptable. Un remplacement basé sur la bibliothèque est disponible pour approbation, mais n'a pas été appliqué automatiquement car ce type de clause peut impliquer une portée juridique matérielle (répartition des parties, comportement restreint ou conditions de responsabilité).",
                        "ar": "يبدو أن صياغة النص البديل المُولّدة غير متسقة داخلياً مع التسوية المقبولة. يتوفر بديل مبني على المكتبة لموافقة المراجع، لكنه لم يُطبَّق تلقائياً لأن هذا النوع من البنود قد يتضمن نطاقاً قانونياً جوهرياً (توزيع الأطراف، أو السلوك المقيَّد، أو شروط المسؤولية).",
                    }
                    ai_result["negotiation_consistency_note"] = _review_note.get(
                        language, _review_note["en"]
                    )
                else:
                    ai_result["fallback_wording_before_autofix"] = llm_fallback_wording
                    ai_result["acceptable_compromise_before_autofix"] = llm_acceptable_compromise
                    ai_result["fallback_wording"] = our_fallback_wording
                    ai_result["acceptable_compromise"] = our_acceptable_compromise
                    ai_result["negotiation_consistency_fixed"] = True
            else:
                ai_result["negotiation_consistency_warning"] = True
    elif our_acceptable_compromise and not llm_acceptable_compromise:
        ai_result["acceptable_compromise"] = our_acceptable_compromise

    if reasoning.get("negotiation_boundary"):
        ai_result["negotiation_boundary"] = reasoning["negotiation_boundary"]
        ai_result["never_accept"] = reasoning["negotiation_boundary"]

    if our_fallback_wording and not safe_str(ai_result.get("fallback_wording")):
        ai_result["fallback_wording"] = our_fallback_wording

    # Final universal safety net. The branches above only compare
    # fallback_wording/acceptable_compromise for inconsistency when BOTH
    # came from the LLM itself. But a MIXED case is also possible and was
    # observed in testing: the LLM left fallback_wording empty (filled
    # here from our own generator, e.g. "18 months") while independently
    # providing its own acceptable_compromise text (e.g. "12 months...
    # instead of 24 months") -- two different origins that never got
    # cross-checked against each other by the branches above, since
    # neither the "both LLM" nor the "both empty" path applies. This
    # final check runs on whatever ai_result ends up holding regardless
    # of where each field came from, and flags it if still inconsistent.
    # It never overwrites anything (we can't safely assume our own value
    # is "more correct" than the LLM's independently-provided one in this
    # mixed scenario) -- it only makes the mismatch visible for review,
    # the same way the LLM-origin "no consistent alternative" case does.
    if (
        "negotiation_consistency_fixed" not in ai_result
        and "negotiation_consistency_warning" not in ai_result
    ):
        final_fallback_wording = safe_str(ai_result.get("fallback_wording"))
        final_acceptable_compromise = safe_str(ai_result.get("acceptable_compromise"))

        if (
            final_fallback_wording
            and final_acceptable_compromise
            and detect_negotiation_inconsistency(
                final_fallback_wording,
                final_acceptable_compromise,
            )
        ):
            ai_result["negotiation_consistency_warning"] = True

    # Source-fidelity check: distinct from the internal-consistency check
    # above. Two generated fields can agree perfectly WITH EACH OTHER
    # (so the check above stays silent) while still being wrong relative
    # to the ORIGINAL clause -- e.g. cross-attributing a 90-day
    # termination-for-convenience notice to what should be a 60-day
    # non-renewal notice, both figures genuinely present in the source
    # but for different obligations. should_check_wording_fidelity()
    # only lets this (costlier) AI call through for clauses that
    # actually carry that specific risk (2+ distinct same-unit numbers
    # in the source, and generated text that references a number at
    # all), so this does not run on every clause of every contract.
    final_fallback_wording = safe_str(ai_result.get("fallback_wording"))
    final_acceptable_compromise = safe_str(ai_result.get("acceptable_compromise"))

    # ------------------------------------------------------------------
    # Structured fidelity_issues architecture: every check below
    # independently APPENDS a structured issue to this list, rather
    # than the previous first-wins model where one check's note could
    # silently discard another's finding. A HIGH-severity issue
    # (material_right_change, liability_cap_inversion,
    # exclusive_remedy_contradiction) is never lost because a
    # MEDIUM-severity numeric delta was also found in the same clause
    # -- both are preserved and reported.
    #
    # Each issue: {"kind", "field", "severity", "concept", "actor",
    # "note"}. "actor" is a best-effort role label (Provider/Client/
    # Party A/Party B/etc. detected near the flagged text) rather than
    # a full semantic-role parse -- an honest approximation, not a
    # claim of complete entity extraction.
    # ------------------------------------------------------------------
    fidelity_issues = []

    def _guess_actor(text: str) -> str:
        text_lower = str(text or "").lower()
        for role in ("provider", "client", "supplier", "buyer", "seller",
                     "licensor", "licensee", "employer", "employee",
                     "lessor", "lessee", "party a", "party b"):
            if role in text_lower:
                return role.title()
        return "unspecified"

    # Deterministic check specifically for acceptable_compromise
    # reintroducing a right the source explicitly denies -- runs
    # unconditionally since it's a fast string check, not an AI call.
    # Confirmed real gap: fallback_wording can correctly avoid a denied
    # basis while acceptable_compromise separately reintroduces it, and
    # the existing AI-based check never examines acceptable_compromise
    # for this specific pattern.
    denied_right_note = acceptable_compromise_introduces_denied_right(
        clause_text, final_acceptable_compromise
    )
    if denied_right_note:
        fidelity_issues.append({
            "kind": "material_right_change",
            "field": "acceptable_compromise",
            "severity": "high",
            "concept": "termination_right",
            "actor": _guess_actor(final_acceptable_compromise),
            "note": denied_right_note,
        })

    # Contextual-paraphrase counterpart to the check above: catches a
    # right granted BY REFERENCE (e.g. "with similar notice") rather
    # than by literal restatement of the denied basis. A SEPARATE,
    # additive issue for fallback_wording specifically -- never merged
    # with the acceptable_compromise issue above, since both can
    # legitimately co-occur in the same clause (confirmed real case:
    # fallback_wording paraphrases the same denied right that
    # acceptable_compromise states literally).
    inherited_right_note = fallback_wording_contains_inherited_denied_right(
        clause_text, final_fallback_wording
    )
    if inherited_right_note:
        fidelity_issues.append({
            "kind": "material_right_change",
            "field": "fallback_wording",
            "severity": "high",
            "concept": "termination_right",
            "actor": _guess_actor(final_fallback_wording),
            "note": inherited_right_note,
        })

    # Detects a source limitation on a party's termination right (e.g.
    # "only for uncured material breach") being removed entirely in
    # generated text (e.g. "for any reason"). Checked for both fields.
    # Confirmed real bug this fixes: this pattern previously fell
    # through to a mere numeric_source_delta classification (MEDIUM)
    # purely because both texts happened to share a number, when the
    # actual issue is a HIGH-severity material right expansion.
    for field_name, field_value in (
        ("fallback_wording", final_fallback_wording),
        ("acceptable_compromise", final_acceptable_compromise),
    ):
        if fallback_wording_removes_termination_limitation(clause_text, field_value):
            _limitation_removed_note = {
                "en": "The generated text removes the source's limitation of this party's termination right to a specific cause condition, granting an unrestricted right to terminate for any reason instead. Manual review recommended to confirm this material expansion is intentional.",
                "fr": "Le texte généré supprime la limitation prévue par la source du droit de résiliation de cette partie à un motif précis, accordant à la place un droit de résiliation non restreint pour quelque raison que ce soit. Une revue manuelle est recommandée pour confirmer que cette extension matérielle est intentionnelle.",
                "ar": "يُزيل النص المُولّد القيد الذي فرضه المصدر على حق هذا الطرف في الإنهاء وحصره في سبب محدد، ليمنح بدلاً من ذلك حقاً غير مقيد في الإنهاء لأي سبب. يُنصح بمراجعة يدوية للتأكد من أن هذا التوسع الجوهري مقصود.",
            }
            fidelity_issues.append({
                "kind": "material_right_change",
                "field": field_name,
                "severity": "high",
                "concept": "termination_right",
                "actor": _guess_actor(field_value),
                "note": _limitation_removed_note.get(language, _limitation_removed_note["en"]),
            })

    # Detects a renewal MECHANISM change (automatic renewal vs mutual-
    # consent renewal) -- a fundamentally different mechanism, not a
    # numeric detail, even though both texts commonly also contain
    # notice-period numbers. Checked for both fields, at HIGH severity
    # alongside the other material change detectors above, so this
    # semantic mechanism change is never silently classified as a mere
    # numeric_source_delta purely because a number also appears nearby.
    for field_name, field_value in (
        ("fallback_wording", final_fallback_wording),
        ("acceptable_compromise", final_acceptable_compromise),
    ):
        if fallback_wording_changes_renewal_mechanism(clause_text, field_value):
            _renewal_mechanism_note = {
                "en": "The generated text changes the renewal mechanism from automatic renewal to renewal requiring mutual consent of both parties -- a different mechanism, not merely a numeric detail. Manual review recommended to confirm this mechanism change is intentional.",
                "fr": "Le texte généré modifie le mécanisme de renouvellement, passant d'un renouvellement automatique à un renouvellement nécessitant le consentement mutuel des deux parties -- un mécanisme différent, pas un simple détail numérique. Une revue manuelle est recommandée pour confirmer que ce changement de mécanisme est intentionnel.",
                "ar": "يُغيّر النص المُولّد آلية التجديد من التجديد التلقائي إلى تجديد يتطلب موافقة الطرفين -- وهي آلية مختلفة، وليست مجرد تفصيل رقمي. يُنصح بمراجعة يدوية للتأكد من أن هذا التغيير في الآلية مقصود.",
            }
            fidelity_issues.append({
                "kind": "renewal_mechanism_change",
                "field": field_name,
                "severity": "high",
                "concept": "renewal_mechanism",
                "actor": _guess_actor(field_value),
                "note": _renewal_mechanism_note.get(language, _renewal_mechanism_note["en"]),
            })

    # Detects a right-polarity change: source expresses
    # MANDATORY_PARTICIPATION (a party bound to consent/vote in favor
    # with no discretion), but generated text introduces a
    # discretionary right (opportunity to negotiate, object, decline).
    for field_name, field_value in (
        ("fallback_wording", final_fallback_wording),
        ("acceptable_compromise", final_acceptable_compromise),
    ):
        if fallback_wording_changes_right_polarity(clause_text, field_value):
            _polarity_note = {
                "en": "The generated text introduces a discretionary right (e.g. an opportunity to negotiate or object) where the source expresses a mandatory obligation to consent, with no discretion. Manual review recommended to confirm this right-polarity change is intentional.",
                "fr": "Le texte généré introduit un droit discrétionnaire (par exemple une possibilité de négocier ou de s'opposer) alors que la source impose une obligation de consentement sans marge de discrétion. Une revue manuelle est recommandée pour confirmer que ce changement de polarité du droit est intentionnel.",
                "ar": "يُدخل النص المُولّد حقاً تقديرياً (مثل فرصة للتفاوض أو الاعتراض) بينما ينص المصدر على التزام إلزامي بالموافقة دون أي هامش تقديري. يُنصح بمراجعة يدوية للتأكد من أن هذا التغيير في طبيعة الحق مقصود.",
            }
            fidelity_issues.append({
                "kind": "right_polarity_change",
                "field": field_name,
                "severity": "high",
                "concept": "participation_right",
                "actor": _guess_actor(field_value),
                "note": _polarity_note.get(language, _polarity_note["en"]),
            })

    # Detects a procedural mechanism change: source expresses
    # NOTICE_NOT_REQUIRED (event-triggered automatic termination, no
    # notice concept at all), but generated text introduces a
    # notice-period requirement -- a different procedural mechanism,
    # not a numeric detail, since the source has no comparable notice
    # role to begin with.
    for field_name, field_value in (
        ("fallback_wording", final_fallback_wording),
        ("acceptable_compromise", final_acceptable_compromise),
    ):
        if compromise_introduces_notice_requirement(clause_text, field_value):
            _notice_introduced_note = {
                "en": "The generated text introduces a notice-period requirement where the source expresses an event-triggered automatic termination with no notice concept at all. Manual review recommended to confirm this procedural mechanism change is intentional.",
                "fr": "Le texte généré introduit une exigence de préavis alors que la source prévoit une résiliation automatique déclenchée par un événement, sans aucun concept de préavis. Une revue manuelle est recommandée pour confirmer que ce changement de mécanisme procédural est intentionnel.",
                "ar": "يُدخل النص المُولّد شرط مهلة إشعار بينما ينص المصدر على إنهاء تلقائي يُفعَّل بحدث معين دون أي مفهوم للإشعار على الإطلاق. يُنصح بمراجعة يدوية للتأكد من أن هذا التغيير في الآلية الإجرائية مقصود.",
            }
            fidelity_issues.append({
                "kind": "termination_mechanism_change",
                "field": field_name,
                "severity": "high",
                "concept": "termination_procedure",
                "actor": _guess_actor(field_value),
                "note": _notice_introduced_note.get(language, _notice_introduced_note["en"]),
            })

    # Deterministic material usage/reuse-right check, covering both
    # fields since either can introduce it. Confirmed real gap: source
    # comprehensively transfers Deliverables to Client with no
    # reservation, but generated text introduces a usage right for
    # Provider the source never mentions at all.
    for field_name, field_value in (
        ("fallback_wording", final_fallback_wording),
        ("acceptable_compromise", final_acceptable_compromise),
    ):
        if generated_text_introduces_unaddressed_usage_right(clause_text, field_value):
            _usage_right_note = {
                "en": "The source comprehensively transfers ownership with no reservation, but the generated text introduces a usage/reuse right for the transferring party that the source never mentions. Manual review recommended to confirm this is an intentional negotiation proposal.",
                "fr": "La source transfère la propriété de manière exhaustive sans réserve, mais le texte généré introduit un droit d'usage/réutilisation pour la partie cédante que la source ne mentionne jamais. Une revue manuelle est recommandée pour confirmer que cette proposition de négociation est intentionnelle.",
                "ar": "تنقل المصدر الملكية بشكل شامل دون أي تحفظ، لكن النص المُولّد يُدخل حق استخدام/إعادة استخدام للطرف الناقل لم يرد ذكره في المصدر إطلاقاً. يُنصح بمراجعة يدوية للتأكد من أن هذا اقتراح تفاوض مقصود.",
            }
            fidelity_issues.append({
                "kind": "material_usage_right_change",
                "field": field_name,
                "severity": "high",
                "concept": "usage_right",
                "actor": _guess_actor(field_value),
                "note": _usage_right_note.get(language, _usage_right_note["en"]),
            })
            break

    # Source-driven, per-category liability cap-state comparison,
    # covering both fields since either can contain the inversion.
    # Bidirectional (UNCAPPED<->CAPPED in either direction) and
    # category-scoped: an exclusion stated for one category (e.g.
    # fraud) is never incorrectly attributed to a different category
    # (e.g. confidentiality) discussed separately in the same clause.
    # Confirmed real bug this replaces: a source clause excluding
    # confidentiality AND indemnification from a liability cap (making
    # both uncapped) had a generated field state both categories
    # "shall not exceed"/"limit... to" a specific capped amount -- the
    # opposite of the source's exclusion for each.
    _cap_state_labels = {
        "EXCLUDED_FROM_GENERAL_CAP": {"en": "excluded from the source liability cap", "fr": "exclue du plafond de responsabilité prévu par la source", "ar": "مستثناة من حد المسؤولية المنصوص عليه في المصدر"},
        "GENERAL_CAP": {"en": "subject to the general liability cap", "fr": "soumise au plafond général de responsabilité", "ar": "خاضعة لحد المسؤولية العام"},
        "SPECIAL_CAP": {"en": "subject to a specifically capped exposure", "fr": "soumise à une exposition spécifiquement plafonnée", "ar": "خاضعة لمسؤولية محددة بحد أقصى معين"},
    }

    for field_name, field_value in (
        ("fallback_wording", final_fallback_wording),
        ("acceptable_compromise", final_acceptable_compromise),
    ):
        for state_issue in compare_liability_states(clause_text, field_value):
            source_label = _cap_state_labels.get(state_issue["source_state"], {}).get(language, state_issue["source_state"])
            generated_label = _cap_state_labels.get(state_issue["generated_state"], {}).get(language, state_issue["generated_state"])
            category_display = state_issue["category"].replace("_", " ").title()

            _liability_inversion_note = {
                "en": f"The generated {field_name.replace('_', ' ')} changes the liability treatment of {category_display} from {source_label} to {generated_label}. Manual review recommended to confirm that this material negotiation change is intentional.",
                "fr": f"Le {field_name.replace('_', ' ')} généré modifie le traitement de responsabilité applicable à {category_display}, en passant d'une catégorie {source_label} à une catégorie {generated_label}. Une revue humaine est recommandée afin de confirmer que cette modification matérielle de négociation est intentionnelle.",
                "ar": f"يغيّر {field_name.replace('_', ' ')} المُنشأ معاملة المسؤولية المتعلقة بـ{category_display}، من فئة {source_label} إلى فئة {generated_label}. يوصى بمراجعة بشرية للتأكد من أن هذا التغيير الجوهري في التفاوض مقصود.",
            }

            fidelity_issues.append({
                "kind": "liability_cap_inversion",
                "field": field_name,
                "severity": "high",
                "concept": "liability_treatment",
                "category": state_issue["category"],
                "source_state": state_issue["source_state"],
                "generated_state": state_issue["generated_state"],
                "actor": _guess_actor(field_value),
                "note": _liability_inversion_note.get(language, _liability_inversion_note["en"]),
            })

    # Deterministic material-obligation-change check (notice/evidentiary
    # burden/certification/consent prerequisites introduced but not
    # expressed in the source), covering both fields. Concept-scoped so
    # an obligation already present in the source (even if phrased
    # differently) is never flagged as newly introduced.
    _obligation_concept_labels = {
        "NOTICE_PREREQUISITE": {"en": "a written-notice prerequisite", "fr": "une exigence de notification écrite préalable", "ar": "شرط الإشعار الكتابي المسبق"},
        "EVIDENTIARY_BURDEN": {"en": "an evidentiary burden", "fr": "une charge de la preuve", "ar": "عبء إثبات"},
        "CERTIFICATION_DUTY": {"en": "a written-certification duty", "fr": "une obligation de certification écrite", "ar": "التزام بتقديم شهادة خطية"},
        "CONSENT_PREREQUISITE": {"en": "a prior-consent prerequisite", "fr": "une exigence de consentement préalable", "ar": "شرط الموافقة المسبقة"},
    }

    for field_name, field_value in (
        ("fallback_wording", final_fallback_wording),
        ("acceptable_compromise", final_acceptable_compromise),
    ):
        for obligation_issue in detect_material_obligation_changes(clause_text, field_value):
            concept_label = _obligation_concept_labels.get(obligation_issue["concept"], {}).get(language, obligation_issue["concept"])

            _obligation_note = {
                "en": f"The generated {field_name.replace('_', ' ')} introduces {concept_label} that the source clause does not expressly impose. Manual review recommended to confirm that this procedural negotiation change is intentional.",
                "fr": f"Le {field_name.replace('_', ' ')} généré introduit {concept_label} que la clause source n'impose pas expressément. Une revue manuelle est recommandée pour confirmer que cette modification procédurale de négociation est intentionnelle.",
                "ar": f"يُدخل {field_name.replace('_', ' ')} المُولّد {concept_label} لا ينص عليه البند المصدر صراحة. يُنصح بمراجعة يدوية للتأكد من أن هذا التغيير الإجرائي في التفاوض مقصود.",
            }

            fidelity_issues.append({
                "kind": "material_obligation_change",
                "field": field_name,
                "severity": obligation_issue["severity"],
                "concept": obligation_issue["concept"].lower(),
                "source_state": obligation_issue["source_state"],
                "generated_state": obligation_issue["generated_state"],
                "actor": _guess_actor(field_value),
                "note": _obligation_note.get(language, _obligation_note["en"]),
            })

    # Deterministic exclusive-remedy contradiction check, covering both
    # fields since either can contain the contradiction.
    for field_name, field_value in (
        ("fallback_wording", final_fallback_wording),
        ("acceptable_compromise", final_acceptable_compromise),
    ):
        if source_vs_fallback_exclusive_remedy_mismatch(clause_text, field_value):
            _exclusive_remedy_note = {
                "en": "The generated text allows additional or other remedies, which contradicts the source clause's sole/exclusive remedy provision. Manual review recommended.",
                "fr": "Le texte généré autorise des recours supplémentaires ou différents, ce qui contredit la disposition de recours exclusif de la clause source. Une revue manuelle est recommandée.",
                "ar": "يسمح النص المُولّد بسبل انتصاف إضافية أو أخرى، مما يتعارض مع نص البند المصدر الذي يحصر الحل في سبيل انتصاف وحيد. يُنصح بمراجعة يدوية.",
            }
            fidelity_issues.append({
                "kind": "exclusive_remedy_contradiction",
                "field": field_name,
                "severity": "high",
                "concept": "exclusive_remedy",
                "actor": _guess_actor(field_value),
                "note": _exclusive_remedy_note.get(language, _exclusive_remedy_note["en"]),
            })
            break

    # Deterministic multi-delta check: when fallback_wording contains
    # more than one genuine numeric change relative to the source (each
    # for a different, independent unit category), build a
    # comprehensive note listing all of them -- confirmed real gap
    # where a clause with two independent deltas (an interest rate AND
    # a separate payment-suspension threshold) only ever had one
    # surfaced, since a single AI explanation call mentions at most one
    # change per invocation.
    fallback_deltas = find_all_numeric_deltas_for_display(clause_text, final_fallback_wording)
    compromise_deltas = find_all_numeric_deltas_for_display(clause_text, final_acceptable_compromise)

    # Deduplicate identical deltas appearing in both fields (e.g. the
    # same rate change genuinely present in both fallback_wording and
    # acceptable_compromise) -- confirmed real bug where "1.5% -> 1%"
    # was listed twice in the same note, once per field, even though
    # it is a single underlying change repeated in two places rather
    # than two distinct source terms being modified.
    seen_deltas = set()
    all_deltas = []
    for delta in fallback_deltas + compromise_deltas:
        if delta not in seen_deltas:
            seen_deltas.add(delta)
            all_deltas.append(delta)

    if all_deltas:
        if fallback_deltas and not compromise_deltas:
            delta_field = "fallback_wording"
            field_label = {"en": "fallback", "fr": "texte", "ar": "النص"}
            verb_en = "changes"
        elif compromise_deltas and not fallback_deltas:
            delta_field = "acceptable_compromise"
            field_label = {"en": "acceptable compromise", "fr": "compromis acceptable", "ar": "التسوية المقبولة"}
            verb_en = "changes"
        else:
            delta_field = "fallback_wording and acceptable_compromise"
            field_label = {"en": "fallback and acceptable compromise", "fr": "texte et le compromis acceptable", "ar": "النص والتسوية المقبولة"}
            verb_en = "change"

        if len(all_deltas) == 1:
            _delta_note = {
                "en": f"The generated {field_label['en']} {verb_en} the source term from {all_deltas[0].split(' -> ')[0]} to {all_deltas[0].split(' -> ')[1]}. Manual review recommended to confirm that this change is intentional.",
                "fr": f"Le {field_label['fr']} généré modifie le terme source de {all_deltas[0].split(' -> ')[0]} à {all_deltas[0].split(' -> ')[1]}. Une revue manuelle est recommandée pour confirmer que ce changement est intentionnel.",
                "ar": f"يُغيّر {field_label['ar']} المُولّد الشرط الأصلي من {all_deltas[0].split(' -> ')[0]} إلى {all_deltas[0].split(' -> ')[1]}. يُنصح بمراجعة يدوية للتأكد من أن هذا التغيير مقصود.",
            }
        else:
            _delta_note = {
                "en": f"The generated {field_label['en']} {verb_en} multiple source terms: " + "; ".join(all_deltas) + ". Manual review recommended to confirm these changes are intentional.",
                "fr": f"Le {field_label['fr']} généré modifie plusieurs termes source : " + "; ".join(all_deltas) + ". Une revue manuelle est recommandée pour confirmer que ces changements sont intentionnels.",
                "ar": f"يُغيّر {field_label['ar']} المُولّد عدة شروط أصلية: " + "؛ ".join(all_deltas) + ". يُنصح بمراجعة يدوية للتأكد من أن هذه التغييرات مقصودة.",
            }

        fidelity_issues.append({
            "kind": "numeric_source_delta",
            "field": delta_field,
            "severity": "medium",
            "concept": "numeric_term",
            "actor": "unspecified",
            "note": _delta_note.get(language, _delta_note["en"]),
        })

    # AI-based residual check: only consulted when NO deterministic
    # check above found anything at all, since this call's judgment has
    # repeatedly proven less reliable than the deterministic checks
    # (multiple confirmed false positives/negatives this session). Its
    # finding is classified as MEDIUM (not HIGH), since the specific,
    # higher-confidence semantic patterns are already handled
    # deterministically above.
    if not fidelity_issues and should_check_wording_fidelity(
        clause_text,
        final_fallback_wording,
        final_acceptable_compromise,
    ):
        fidelity_result = verify_wording_fidelity_to_source(
            clause_text,
            final_fallback_wording,
            final_acceptable_compromise,
            language,
        )

        if fidelity_result.get("fidelity_issue"):
            fidelity_issues.append({
                "kind": "numeric_source_delta",
                "field": "fallback_wording",
                "severity": "medium",
                "concept": "unclassified_delta",
                "actor": "unspecified",
                "note": fidelity_result.get("explanation", ""),
            })

    # Sort HIGH before MEDIUM before LOW, so the highest-priority issue
    # is always first -- the specific ordering the master constraint
    # requires ("A HIGH issue must never disappear because a MEDIUM
    # numeric delta was also detected").
    _severity_rank = {"high": 0, "medium": 1, "low": 2}
    fidelity_issues.sort(key=lambda issue: _severity_rank.get(issue.get("severity"), 3))

    if fidelity_issues:
        ai_result["fidelity_issues"] = fidelity_issues
        ai_result["negotiation_fidelity_warning"] = True
        ai_result["negotiation_fidelity_note"] = fidelity_issues[0]["note"]

    return ai_result


def extract_reference_fallback(clause_text: str) -> str:
    """
    Deterministic fallback for clause_reference when the LLM's own
    response leaves it empty. clause_reference otherwise depends
    ENTIRELY on the LLM including it in its JSON output, with no
    fallback -- an LLM response that simply omits this one field
    silently turns into a blank "-" reference in the final report, even
    though the clause's own source text reliably starts with its number
    (e.g. "1.1 Executive shall serve...") in any of the three supported
    languages, since section numbering in this pipeline is always plain
    digits ("1.1", "3.1"...), never script-dependent -- confirmed
    working identically for English, French, and Arabic source clauses
    throughout this pipeline.
    """
    match = re.match(r"\s*(\d+(?:\.\d+)+)", str(clause_text or ""))
    return match.group(1) if match else ""


_CLAUSE_NUMBER_UNIT_PATTERN = re.compile(
    r"\(?\s*(\d[\d,]*(?:\.\d+)?)\s*\)?\s*"
    r"\b(days?|months?|years?|hours?|business\s+days?|"
    r"jours?|mois|ans?|heures?|"
    r"يوماً?|أيام|شهراً?|أشهر|سنة|سنوات|ساعة|ساعات|"
    r"%|percent|pour\s*cent|بالمئة|في\s*المئة)\b",
    re.IGNORECASE,
)

# Matches a leading clause-reference number (e.g. "10.3", "9.1") at the
# very start of clause_text, so it can be stripped before number
# extraction -- confirmed real bug: without this, "10.3 Any dispute..."
# had "10.3" itself mistaken for a substantive figure from the clause's
# own content, rather than being recognized as the section reference.
_LEADING_CLAUSE_REFERENCE_PATTERN = re.compile(r"^\s*\d+(?:\.\d+)+\s*")


def _extract_clause_specific_number_unit(clause_text: str) -> str:
    """
    Finds the first prominent number+unit pattern in the clause's own
    text (e.g. "60 days", "12 months", "5%"), used to ground a fallback
    acceptable_compromise sentence in this specific clause rather than a
    fully generic template. Returns "" if no such pattern is found.
    """
    text_without_reference = _LEADING_CLAUSE_REFERENCE_PATTERN.sub(
        "", str(clause_text or ""), count=1
    )
    match = _CLAUSE_NUMBER_UNIT_PATTERN.search(text_without_reference)
    if not match:
        return ""
    return f"{match.group(1)} {match.group(2)}".strip()


def analyze_clause(
    clause: str,
    language: str = "en",
    party_roles: dict | None = None,
) -> dict:

    if not clause or not clause.strip():

        return normalize_clause_result(
            fallback_clause_result(language)
        )

    safe_clause_for_ai = anonymize_personal_data_for_ai(clause)
    safe_party_roles_for_ai = anonymize_party_roles_for_ai(party_roles)

    prompt = build_clause_prompt(
        safe_clause_for_ai,
        language,
        party_roles,
    )

    try:
        ai_result = call_clause_ai(prompt)

    except Exception as e:

        ai_result = fallback_clause_result(
            language
        )

    ai_result["language"] = language

    normalized = normalize_clause_result(
        ai_result
    )

    if not normalized.get("clause_reference"):
        normalized["clause_reference"] = extract_reference_fallback(clause)

    normalized = normalize_ai_role_words(
        normalized,
        party_roles or {},
        language,
    )

    ai_result = normalized

    taxonomy_type = detect_clause_type_from_taxonomy(clause)

    if taxonomy_type != "other":
        current_type = ai_result.get("clause_type")

        if current_type == "other":
            ai_result["clause_type"] = taxonomy_type

        elif not has_clause_type_signal(clause, current_type):
            ai_result["clause_type"] = taxonomy_type
            ai_result["confidence"] = "medium"

        else:
            # The LLM's own guess has SOME signal support, but that
            # does not mean it is the BEST match -- a clause can
            # legitimately mention terms from an unrelated category in
            # passing (e.g. a warranty-disclaimer clause repeatedly
            # referencing "Confidential Information" as the subject
            # matter the disclaimer applies to, without being ABOUT
            # confidentiality itself). Compare the taxonomy's own score
            # for the LLM's guess against its score for its own best
            # match, and only override when the taxonomy's best match
            # wins by a clear margin, to avoid flip-flopping on
            # genuinely close calls.
            current_type_score = score_clause_type(clause, current_type).get("score", 0)
            taxonomy_type_score = score_clause_type(clause, taxonomy_type).get("score", 0)

            if (
                taxonomy_type_score >= current_type_score * 2
                and taxonomy_type_score - current_type_score >= 3
            ):
                ai_result["clause_type"] = taxonomy_type
                ai_result["confidence"] = "medium"

    taxonomy_description = get_clause_type_description(
        ai_result["clause_type"],
        language,
    )

    if taxonomy_description:
        ai_result["explanation_simple"] = taxonomy_description

    ai_result["_meta"] = {
        "risk_modified_by": [],
        "reasoning_modified_by": [],
        "cleanup_applied": [],
        "changes": [],
    }

    if not ai_result["clause_title"]:

        ai_result["clause_title"] = (
            extract_clause_title(clause)
        )

    ai_result["clause_title"] = normalize_final_clause_title(
        ai_result.get("clause_title", "")
    )

    ai_result["title"] = ai_result["clause_title"]

    ai_result = apply_rule_based_risk(
        ai_result,
        clause,
        language,
    )

    reasoning = get_reasoning_for_text(
        clause,
        language,
        title=ai_result.get("clause_title", ""),
        clause_type=ai_result.get("clause_type"),
    )

    if reasoning:
        if reasoning.get("legal_insight"):
            ai_result["legal_insight"] = reasoning.get("legal_insight")

        if reasoning.get("recommendation"):
            ai_result["recommendation"] = reasoning.get("recommendation")

        if reasoning.get("negotiation"):
            ai_result["negotiation_advice"] = reasoning.get("negotiation")

        if reasoning.get("market_comparison"):
            ai_result["market_comparison"] = reasoning.get("market_comparison")

        if reasoning.get("safer_alternative"):
            ai_result["safer_alternative"] = reasoning.get("safer_alternative")

        if reasoning.get("contextual_reasoning"):
            ai_result["has_contextual_reasoning"] = True

        ai_result = merge_pipeline_reasoning_enrichment(
            ai_result, reasoning, clause_text=clause, language=language,
        )

    if not ai_result.get(
        "explanation_simple"
    ):

        legal_insight = str(
            ai_result.get(
                "legal_insight",
                "",
            )
        ).strip()

        if legal_insight:
            ai_result[
                "explanation_simple"
            ] = legal_insight

    title_text = ai_result.get("clause_title", "").lower()

    # Root-cause fix: previously this checked the FULL clause body
    # (title + entire clause text), so any incidental mention of
    # "confidentiality" anywhere in the clause -- e.g. a liability
    # clause listing "breach of its confidentiality obligations" as one
    # of several carve-outs -- would force this clause's entire
    # reasoning (legal_insight, market_comparison, safer_alternative)
    # to be overwritten with confidentiality-specific content, even
    # though confidentiality was not the clause's actual subject.
    #
    # Confirmed real bug (second occurrence of the same root pattern):
    # a warranty-disclaimer clause had a MISLEADING title containing
    # "Confidentialité" even though ai_result["clause_type"] was
    # already correctly set to "warranty" by the taxonomy detector --
    # the title-based OR condition let this misleading title override
    # the already-confirmed, specific type, silently replacing the
    # correct warranty-specific reasoning with generic confidentiality
    # content. The already-confirmed clause_type is now always
    # authoritative when it is a specific, non-confidentiality type;
    # the title-based signal is only consulted as a fallback when
    # clause_type is weak/missing (other/general/empty) or already
    # confidentiality itself. This is a universal fix -- it does not
    # depend on contract domain or language, and applies the same way
    # whenever any clause title legitimately (or misleadingly)
    # concerns confidentiality.
    confirmed_clause_type = ai_result.get("clause_type")

    title_suggests_confidentiality = (
        "confidentiality" in title_text
        or "confidential information" in title_text
        or "confidentialité" in title_text
        or "information confidentielle" in title_text
        or "السرية" in title_text
        or "معلومات سرية" in title_text
    )

    is_confidentiality_clause = confirmed_clause_type == "confidentiality" or (
        title_suggests_confidentiality
        and confirmed_clause_type in (None, "", "other", "general")
    )

    if is_confidentiality_clause:
        conf_reasoning = get_reasoning_for_text(
            clause,
            language,
            title="Confidentiality",
        )

        if conf_reasoning.get("legal_insight"):
            ai_result["legal_insight"] = (
                conf_reasoning["legal_insight"]
            )

        if conf_reasoning.get("recommendation"):
            ai_result["recommendation"] = (
                conf_reasoning["recommendation"]
            )

        if conf_reasoning.get("negotiation"):
            ai_result["negotiation_advice"] = (
                conf_reasoning["negotiation"]
            )

        if conf_reasoning.get("market_comparison"):
            ai_result["market_comparison"] = conf_reasoning.get("market_comparison")

        if conf_reasoning.get("safer_alternative"):
            ai_result["safer_alternative"] = conf_reasoning.get("safer_alternative")

        ai_result["has_contextual_reasoning"] = True

        ai_result = merge_pipeline_reasoning_enrichment(
            ai_result, conf_reasoning, clause_text=clause, language=language,
        )

    ai_result = remove_speculative_analysis(
        ai_result
    )

    if is_truncated_clause(clause):
        ai_result["confidence"] = "low"
        ai_result["red_flag"] = False
        ai_result["red_flag_reason"] = ""

        if ai_result.get("risk_level") == "high":
            ai_result["risk_level"] = "medium"

    ai_result = normalize_ai_role_words(
        ai_result,
        party_roles or {},
        language,
    )

    ai_result = enforce_party_registry_on_clause_output(
        ai_result,
        party_roles or {},
        language,
        clause,
    )

    # Semantic object sanity check: catches a legal right's verb having
    # a bare PARTY as its direct object rather than an asset (e.g.
    # "licensing of the relevant party" instead of "licensing of the
    # relevant technology") -- a clearly malformed, nonsensical
    # construction regardless of contract domain. Checked before the
    # generic-fallback safety nets below, so a malformed field is
    # cleared here and then safely filled with honest generic text by
    # those nets, rather than displaying nonsensical content. Confirmed
    # real case: a generated fallback proposed "licensing of the
    # relevant party to direct competitors" -- parties are not
    # licensable objects.
    for _sanity_field in ("fallback_wording", "acceptable_compromise"):
        _sanity_result = validate_semantic_object_sanity(str(ai_result.get(_sanity_field) or ""))
        if _sanity_result:
            ai_result[_sanity_field] = ""

    # Universal safety net: "recommendation" must never be empty. Several
    # upstream mechanisms within apply_rule_based_risk() can clear this
    # field under different conditions (fragment-like text, purely
    # definitional clauses, low-risk generic text, etc.) -- rather than
    # tracking down and adjusting each one individually, this guarantees
    # the outcome directly, once, at the single point where the clause
    # analysis is finalized. Falls back to a short, genuinely useful
    # generic prompt rather than leaving the field blank.
    if not str(ai_result.get("recommendation") or "").strip():
        _recommendation_fallback = {
            "en": "Review this clause for consistency with the overall contract and your specific business context.",
            "fr": "Vérifier que cette clause est cohérente avec l'ensemble du contrat et votre contexte commercial spécifique.",
            "ar": "يُنصح بمراجعة هذا البند للتأكد من اتساقه مع العقد ككل ومع سياق عملك التجاري المحدد.",
        }
        ai_result["recommendation"] = _recommendation_fallback.get(
            language, _recommendation_fallback["en"]
        )

    # Same universal safety net, for "legal_insight". Confirmed real gap:
    # this field can also end up empty (the same upstream mechanisms
    # within apply_rule_based_risk() that can clear "recommendation" can
    # clear this field too), but no equivalent safety net previously
    # existed for it.
    if not str(ai_result.get("legal_insight") or "").strip():
        _legal_insight_fallback = {
            "en": "This clause may affect the parties' rights, obligations, or allocation of risk under the Agreement.",
            "fr": "Cette clause peut affecter les droits, obligations ou la répartition des risques des parties au titre du contrat.",
            "ar": "قد تؤثر هذه المادة على حقوق الأطراف أو التزاماتهم أو توزيع المخاطر بموجب الاتفاقية.",
        }
        ai_result["legal_insight"] = _legal_insight_fallback.get(
            language, _legal_insight_fallback["en"]
        )

    # Source-aware override for fallback_wording on remedies and
    # governing_law/dispute_resolution clause types specifically:
    # replaces the fully generic, clause-type-agnostic template with
    # content referencing the SPECIFIC mechanisms (injunctive relief,
    # bond waiver, remedy exclusivity) or SPECIFIC named law/forum
    # actually present in the clause, when extractable. Confirmed
    # real gap: "remedies" had no dedicated library entry at all,
    # falling to the fully generic template on every occurrence; a
    # governing-law clause naming "Delaware law" and "Wilmington,
    # Delaware" courts received "specify governing law and forum"
    # advice that never references either.
    _fully_generic_fallback_text = "A safer alternative is to clarify the scope, objective standards, notice requirements, exceptions, remedies, and proportional limits so the clause remains enforceable and balanced."
    _generic_dispute_fallback_text = "A safer alternative is to specify governing law, forum, dispute escalation steps, language, costs, interim relief, and enforcement mechanics in a clear and practical manner."
    current_fallback_for_override = str(ai_result.get("fallback_wording") or "").strip()
    resolved_type_for_override = normalize_clause_type(str(ai_result.get("clause_type") or ""))

    if current_fallback_for_override in (_fully_generic_fallback_text, ""):
        if resolved_type_for_override == "remedies":
            source_aware = generate_remedies_specific_content(clause, language)
            if source_aware:
                ai_result["fallback_wording"] = source_aware

    _generic_warranty_fallback_text = "A safer alternative is to state warranties precisely, define their duration, list exclusions and disclaimers clearly, and specify the exclusive remedies available if a warranty is breached."

    if current_fallback_for_override in (_generic_warranty_fallback_text, ""):
        if resolved_type_for_override == "warranty":
            source_aware_warranty = generate_warranty_specific_content(clause, language)
            if source_aware_warranty:
                ai_result["fallback_wording"] = source_aware_warranty

    if current_fallback_for_override in (_generic_dispute_fallback_text, ""):
        if resolved_type_for_override in ("governing_law", "dispute_resolution"):
            source_aware_law = generate_governing_law_specific_content(clause, language)
            if source_aware_law:
                ai_result["fallback_wording"] = source_aware_law

    # Mechanism-driven acceptable_compromise and negotiation_boundary,
    # consuming the SAME extracted mechanisms that already feed
    # fallback_wording above -- closes the confirmed gap where these
    # two fields had no connection to mechanism extraction at all,
    # relying only on numeric-role classification (compromise) or bare
    # clause_type lookup (boundary). Checked first, before the
    # numeric-role-based logic below, since mechanism-specific content
    # is more specific when both are available.
    _generic_compromise_text_for_mechanism_check = "A reasonable compromise typically narrows the scope, adds objective criteria or thresholds, and includes standard exceptions appropriate to this type of clause."
    current_compromise_for_mechanism_check = str(ai_result.get("acceptable_compromise") or "").strip()

    if current_compromise_for_mechanism_check in (_generic_compromise_text_for_mechanism_check, ""):
        mechanism_compromise = generate_mechanism_driven_acceptable_compromise(
            clause, resolved_type_for_override, language
        )
        if mechanism_compromise:
            ai_result["acceptable_compromise"] = mechanism_compromise

    current_boundary_for_mechanism_check = str(ai_result.get("negotiation_boundary") or "").strip()
    _generic_boundary_texts_for_mechanism_check = {
        "Avoid accepting terms that are open-ended, lack objective criteria, or are materially more one-sided than standard market practice for this type of clause.",
    }

    if not current_boundary_for_mechanism_check or current_boundary_for_mechanism_check in _generic_boundary_texts_for_mechanism_check:
        mechanism_boundary = generate_mechanism_driven_negotiation_boundary(
            clause, resolved_type_for_override, language
        )
        if mechanism_boundary:
            ai_result["negotiation_boundary"] = mechanism_boundary

    # Same universal safety net, for "acceptable_compromise". Confirmed
    # real gap via a 33-clause test contract: even after tightening the
    # prompt's specificity instructions for this field specifically,
    # 25/33 clauses still shared the exact same fully generic text --
    # LLM instruction-following alone isn't reliable enough here, so
    # this grounds the fallback in a real number+unit extracted from the
    # clause's own text (e.g. "60 days", "12 months") rather than a
    # sentence generic enough to apply to any clause. Falls back to the
    # honest generic text only when no such number can be found (e.g. a
    # definitional or structural clause with nothing to negotiate).
    _generic_acceptable_compromise_texts = {
        "en": "A reasonable compromise typically narrows the scope, adds objective criteria or thresholds, and includes standard exceptions appropriate to this type of clause.",
        "fr": "Un compromis raisonnable consiste généralement à restreindre la portée, à ajouter des critères ou seuils objectifs, et à inclure les exceptions usuelles adaptées à ce type de clause.",
        "ar": "يتمثل التسوية المعقولة عادة في تضييق النطاق، وإضافة معايير أو حدود موضوعية، وتضمين الاستثناءات المعتادة المناسبة لهذا النوع من البنود.",
    }
    current_compromise = str(ai_result.get("acceptable_compromise") or "").strip()

    if not current_compromise or current_compromise in _generic_acceptable_compromise_texts.values():
        extracted_number = _extract_clause_specific_number_unit(clause)

        if extracted_number:
            numeric_role = classify_numeric_term_role(clause)
            role_guidance = numeric_role_direction_guidance(numeric_role, language)

            if role_guidance:
                _grounded_compromise_fallback = {
                    "en": role_guidance,
                    "fr": role_guidance,
                    "ar": role_guidance,
                }
            else:
                # Role-specific reasons why the direction is
                # deliberately ambiguous, rather than a generic
                # "cannot be determined" -- e.g. a longer
                # incident-notification period is not automatically
                # favorable, since it trades off notification burden
                # against affected-party protection depending on
                # which side of the notification you represent.
                _ambiguous_reason_by_role = {
                    "INCIDENT_NOTIFICATION_PERIOD": {
                        "en": "the preferred period depends on whether the represented party is the notifying party (who benefits from more time to investigate) or the affected party (who benefits from faster notice)",
                        "fr": "la durée préférable dépend du fait que la partie représentée soit celle qui notifie (qui bénéficie de plus de temps pour enquêter) ou celle qui est affectée (qui bénéficie d'une notification plus rapide)",
                        "ar": "تعتمد المدة المفضلة على ما إذا كان الطرف المُمثَّل هو الطرف المُخطِر (الذي يستفيد من وقت أطول للتحقيق) أو الطرف المتضرر (الذي يستفيد من إشعار أسرع)",
                    },
                    "INITIAL_TERM": {
                        "en": "the preferred length depends on whether the represented party wants commitment and predictability (favoring a longer term) or flexibility to renegotiate or exit (favoring a shorter term)",
                        "fr": "la durée préférable dépend du fait que la partie représentée recherche l'engagement et la prévisibilité (favorisant une durée plus longue) ou la flexibilité pour renégocier ou sortir (favorisant une durée plus courte)",
                        "ar": "تعتمد المدة المفضلة على ما إذا كان الطرف المُمثَّل يرغب في الالتزام وإمكانية التنبؤ (وهو ما يخدمه مدة أطول) أو المرونة لإعادة التفاوض أو الخروج (وهو ما تخدمه مدة أقصر)",
                    },
                    "RENEWAL_TERM": {
                        "en": "the preferred length depends on whether the represented party wants a longer renewal cycle (fewer renegotiation points) or a shorter one (more frequent opportunities to revisit terms)",
                        "fr": "la durée préférable dépend du fait que la partie représentée souhaite un cycle de renouvellement plus long (moins de points de renégociation) ou plus court (des occasions plus fréquentes de revoir les conditions)",
                        "ar": "تعتمد المدة المفضلة على ما إذا كان الطرف المُمثَّل يرغب في دورة تجديد أطول (نقاط أقل لإعادة التفاوض) أو أقصر (فرص أكثر تكراراً لمراجعة الشروط)",
                    },
                }

                reason = _ambiguous_reason_by_role.get(numeric_role, {}).get(language)

                if reason:
                    _abstain_text = {
                        "en": f"Manual negotiation position required for this term: {reason}.",
                        "fr": f"Une position de négociation déterminée manuellement est requise pour ce terme : {reason}.",
                        "ar": f"يتطلب هذا الشرط تحديد موقف تفاوضي يدوياً: {reason}.",
                    }
                else:
                    _abstain_text = {
                        "en": "Manual negotiation position required for this term: its semantic role could not be determined automatically from the clause text.",
                        "fr": "Une position de négociation déterminée manuellement est requise pour ce terme : son rôle sémantique n'a pas pu être déterminé automatiquement à partir du texte de la clause.",
                        "ar": "يتطلب هذا الشرط تحديد موقف تفاوضي يدوياً: لم يتم تحديد دوره الدلالي تلقائياً من نص البند.",
                    }
                _grounded_compromise_fallback = _abstain_text

            ai_result["acceptable_compromise"] = _grounded_compromise_fallback.get(
                language, _grounded_compromise_fallback["en"]
            )
        elif not current_compromise:
            ai_result["acceptable_compromise"] = _generic_acceptable_compromise_texts.get(
                language, _generic_acceptable_compromise_texts["en"]
            )

    return ai_result


def remove_speculative_analysis(
    analysis: dict,
) -> dict:

    fields = [
        "legal_insight",
        "recommendation",
        "negotiation_advice",
        "safer_alternative",
    ]

    if analysis.get("risk_level") == "low":
        return analysis

    for field in fields:

        value = analysis.get(field, "")

        lowered = value.lower()

        if any(
            p in lowered
            for p in GENERIC_NEGOTIATION_PATTERNS
        ):

            if analysis.get("risk_level") == "low":

                analysis[field] = ""

                continue

        if any(
            p in lowered
            for p in GENERIC_AI_PATTERNS
        ):

            if analysis.get("risk_level") == "low":

                analysis[field] = ""

                continue

        for pattern in SPECULATIVE_PATTERNS:

            if pattern.lower() in lowered:

                analysis[field] = ""

                break

        if field in {
            "recommendation",
            "negotiation_advice",
            "safer_alternative",
        }:

            for pattern in RESTRICTED_RECOMMENDATION_ONLY_PATTERNS:

                if pattern.lower() in lowered:

                    analysis[field] = ""

                    break

    return analysis


def should_force_red_flag_false(
    clause_title: str,
    clause_text: str,
) -> bool:

    text = (
        f"{clause_title} {clause_text}"
    ).lower()

    safe_patterns = [

        "effective as of",
        "entered into by and between",
        "desires to enter into",
        "whereas",
        "now therefore",
        "mutual promises",
        "good and valuable consideration",
        "receipt and sufficiency",
        "for reference only",

        "conclu entre",
        "considérant que",
        "en foi de quoi",
        "à titre indicatif",
        "les titres sont fournis",

        "تم إبرام هذا العقد بين",
        "حيث إن",
        "بناء على ما سبق",
        "وعليه",
        "مقابل الوعود المتبادلة",
        "لأغراض مرجعية فقط",
    ]

    return any(
        pattern in text
        for pattern in safe_patterns
    )


def validate_clause_type(
    analysis: dict,
    clause_text: str,
    language: str = "en",
) -> dict:

    text = clause_text.lower()

    clause_type = analysis.get("clause_type")

    explicit_patterns = {

        "non_compete": [
            "non-compete",
            "non compete",
            "shall not compete",
            "may not compete",
            "cannot compete",
            "restriction on competition",
            "restrictive covenant",

            "non-concurrence",
            "clause de non-concurrence",

            "عدم المنافسة",
        ],

        "exclusivity": [
            "exclusive",
            "exclusivity",
            "sole provider",
            "exclusive rights",

            "exclusivité",
            "exclusif",

            "حصري",
            "حصرية",
        ],

        "penalty": [
            "penalty",
            "liquidated damages",
            "fine",

            "pénalité",
            "amende",

            "غرامة",
        ],
    }

    if clause_type not in explicit_patterns:
        return analysis

    matched = any(
        pattern in text
        for pattern in explicit_patterns[clause_type]
    )

    if not matched:

        analysis["clause_type"] = "other"

        analysis["red_flag"] = False

        analysis["red_flag_reason"] = ""

        analysis["risk_level"] = "low"

        analysis["confidence"] = "low"

        analysis["recommendation"] = ""

        analysis["negotiation_advice"] = ""

        analysis["safer_alternative"] = ""

        unsupported_messages = {
            "en": (
                "The clause does not explicitly contain "
                "a legally identifiable "
                f"{clause_type.replace('_', ' ')} provision."
            ),
            "fr": (
                "La clause ne contient pas explicitement "
                "une disposition juridiquement identifiable de type "
                f"{clause_type.replace('_', ' ')}."
            ),
            "ar": (
                "لا يتضمن هذا البند صراحةً حكماً قانونياً "
                f"يمكن تصنيفه على أنه {clause_type.replace('_', ' ')}."
            ),
        }

        analysis["legal_insight"] = unsupported_messages.get(
            language,
            unsupported_messages["en"],
        )

    return analysis


def validate_protective_clause(
    analysis: dict,
    clause_text: str,
) -> dict:

    text = clause_text.lower()

    protective_patterns = [
        "will maintain insurance",
        "liability insurance",
        "named insured",
        "coverage",
        "shall indemnify",
        "indemnification",

        "assurance responsabilité",
        "assuré",
        "indemniser",

        "تأمين",
        "تعويض",
    ]

    if any(p in text for p in protective_patterns):

        if analysis.get("red_flag"):
            analysis["red_flag"] = False
            analysis["red_flag_reason"] = ""

        protective_negative_patterns = [
            "financial strain",
            "claims exceed",
            "claims exceeding",
            "exceeding the coverage limit",
            "coverage limit",
            "leaving the employee exposed",
            "employee exposed",
                    "personally exposed",
            "personal liability",
        ]

        legal_insight = analysis.get(
            "legal_insight",
            ""
        )

        for pattern in protective_negative_patterns:

            if pattern in legal_insight.lower():

                analysis["legal_insight"] = ""

                break

    return analysis


def validate_standard_market_protection(
    analysis: dict,
    clause_text: str,
) -> dict:

    text = clause_text.lower()

    standard_protection_patterns = [
        "liability insurance",
        "indemnify",
        "expense reimbursement",
        "paid vacation",
        "benefit plans",
        "health insurance",

        "assurance",
        "indemnisation",
        "remboursement",

        "تأمين",
        "تعويض",
        "سداد المصاريف",
    ]

    if any(p in text for p in standard_protection_patterns):

        if analysis.get("risk_level") == "medium":
            analysis["risk_level"] = "low"

        analysis["negotiation_priority"] = "low"

    return analysis


def validate_explicit_permission_clause(
    analysis: dict,
    clause_text: str,
) -> dict:

    text = clause_text.lower()

    permission_patterns = [
        "permitted",
        "allowed",
        "authorized",
        "will not be deemed",
        "will not be considered",
        "so long as",
        "provided that",
        "will continue to be engaged",
        "engaged in other business activities",
        "other business activities",

        "autorisé",
        "permis",
        "ne sera pas considéré",
        "à condition que",

        "مسموح",
        "مرخص",
        "لا يعتبر",
        "بشرط أن",
    ]

    if any(p in text for p in permission_patterns):

        analysis["red_flag"] = False
        analysis["red_flag_reason"] = ""
        analysis["risk_level"] = "low"
        analysis["negotiation_priority"] = "low"
        analysis["legal_insight"] = ""

        permission_negative_patterns = [
            "divided attention",
            "loyalty",
            "outside business",
        ]

        legal_insight = analysis.get(
            "legal_insight",
            ""
        )

        for pattern in permission_negative_patterns:

            if pattern in legal_insight.lower():

                analysis["legal_insight"] = ""

                break

    return analysis


def validate_quoted_text(
    analysis: dict,
    clause_text: str,
) -> dict:

    quoted = (
        analysis.get("quoted_text", "")
        .strip()
    )

    if not quoted:
        return analysis

    clause_lower = clause_text.lower()

    quoted_lower = quoted.lower()

    if quoted_lower not in clause_lower:

        analysis["quoted_text"] = (
            clause_text[:300].strip()
        )

        if analysis.get("confidence") == "high":
            analysis["confidence"] = "medium"

    if len(quoted.split()) < 6:

        analysis["quoted_text"] = (
            clause_text[:300].strip()
        )

    return analysis


def is_truncated_clause(
    clause_text: str,
) -> bool:

    text = safe_str(clause_text)

    if not text:
        return False

    lowered = text.lower().strip()

    truncated_endings = [
        ",",
        ";",
        ":",
        "(",
        "[",
        "{",
        "and",
        "or",
        "including",
        "including but not limited to",
        "et",
        "ou",
        "notamment",
        "y compris",
        "و",
        "أو",
        "بما في ذلك",
    ]

    if any(
        lowered.endswith(ending)
        for ending in truncated_endings
    ):
        return True

    opening_pairs = [
        ("(", ")"),
        ("[", "]"),
        ("{", "}"),
        ("“", "”"),
        ('"', '"'),
    ]

    for opener, closer in opening_pairs:
        if opener == closer:
            if text.count(opener) % 2 != 0:
                return True
        elif text.count(opener) > text.count(closer):
            return True

    return False


def detect_clause_baseline(
    analysis: dict,
    clause_text: str,
) -> str:

    text = clause_text.lower()

    low_patterns = {
        "governing_law": [
            "governing law",
            "droit français",
            "droit applicable",
            "القانون الواجب التطبيق",
        ],
        "venue": [
            "venue",
            "jurisdiction",
            "tribunaux compétents",
            "tribunaux compétents de paris",
            "juridiction",
            "محكمة",
            "الاختصاص",
        ],
        "payment_schedule": [
            "payment schedule",
            "payment date",
            "invoice",
            "échéancier de paiement",
            "date de paiement",
            "facture",
            "جدول الدفع",
            "فاتورة",
        ],
        "standard_confidentiality": [
            "confidentiality",
            "confidential information",
            "confidentialité",
            "information confidentielle",
            "سرية",
            "معلومات سرية",
        ],
        "fixed_term": [
            "term of this agreement",
            "fixed term",
            "durée du contrat",
            "durée déterminée",
            "مدة العقد",
        ],
        "ip_after_payment": [
            "transfer of ownership upon full payment",
            "ownership transfers after full payment",
            "assignment after payment",
            "cession après paiement",
            "transfert de propriété après paiement",
            "الملكية بعد السداد",
        ],
        "mutual_termination_notice": [
            "mutual termination",
            "either party may terminate",
            "notice period",
            "préavis",
            "résiliation mutuelle",
            "إنهاء متبادل",
        ],
        "administrative_amendment": [
            "amended and restated",
            "restatement of existing",
            "restated agreement",
            "amendment and restatement",
            "amendment to the agreement",

            "modifié et reformulé",
            "modification de l’accord",
            "modification du contrat",

            "معدل ومعاد صياغته",
            "إعادة صياغة",
            "تعديل الاتفاقية",
            "تعديل العقد",
        ],
    }

    medium_patterns = {
        "limited_liability": [
            "limitation of liability",
            "liability cap",
            "responsabilité limitée",
            "plafond de responsabilité",
            "حد المسؤولية",
        ],
        "broad_confidentiality": [
            "all confidential information",
            "toute information confidentielle",
            "جميع المعلومات السرية",
        ],
        "vague_payment_trigger": [
            "subject to approval",
            "at discretion",
            "déclenchement du paiement",
            "à sa discrétion",
            "حسب تقديره",
        ],
        "asymmetrical_termination": [
            "company may terminate",
            "client may terminate",
            "la société peut résilier",
            "le client peut résilier",
            "يجوز للشركة إنهاء",
        ],
    }

    high_patterns = {
        "unlimited_liability": [
            "unlimited liability",
            "responsabilité illimitée",
            "مسؤولية غير محدودة",
        ],
        "unilateral_amendment": [
            "may amend at any time",
            "unilaterally amend",
            "modifier unilatéralement",
            "تعديل من جانب واحد",
        ],
        "automatic_renewal_trap": [
            "automatic renewal unless",
            "renouvellement automatique sauf",
            "تجديد تلقائي ما لم",
        ],
        "perpetual_non_compete": [
            "perpetual non-compete",
            "non-compete forever",
            "non-concurrence perpétuelle",
            "عدم منافسة دائم",
        ],
        "broad_ip_assignment": [
            "assign any and all rights",
            "all intellectual property",
            "cession de tous les droits",
            "التنازل عن جميع الحقوق",
        ],
        "severe_penalties": [
            "liquidated damages",
            "severe penalty",
            "pénalité sévère",
            "dommages-intérêts forfaitaires",
            "تعويضات مقطوعة",
        ],
    }

    for label, patterns in high_patterns.items():
        if any(p in text for p in patterns):
            return label

    for label, patterns in medium_patterns.items():
        if any(p in text for p in patterns):
            return label

    for label, patterns in low_patterns.items():
        if any(p in text for p in patterns):
            return label

    clause_type = analysis.get("clause_type", "other")

    if clause_type == "penalty":
        return "severe_penalties"

    if clause_type == "non_compete":
        return "perpetual_non_compete" if "perpetual" in text else "asymmetrical_termination"

    if clause_type == "intellectual_property":

        broad_ip_patterns = [
            "assign any and all rights",
            "all intellectual property",
            "irrevocable",
            "perpetual",
            "cession de tous les droits",
            "irrévocable",
            "perpétuel",
            "التنازل عن جميع الحقوق",
            "غير قابل للإلغاء",
            "دائم",
        ]

        if any(
            pattern in text
            for pattern in broad_ip_patterns
        ):
            return "broad_ip_assignment"

        return "ip_after_payment"

    if clause_type == "liability":
        return "limited_liability"

    if clause_type == "confidentiality":
        return "standard_confidentiality"

    if clause_type == "payment":
        return "payment_schedule"

    if clause_type == "termination":
        return "mutual_termination_notice"

    return "other"


def apply_conceptual_risk_calibration(
    analysis: dict,
    clause_text: str,
) -> dict:

    text = clause_text.lower()

    baseline = detect_clause_baseline(
        analysis,
        clause_text,
    )

    has_escalator = any(
        pattern in text
        for pattern in RISK_ESCALATORS
    )

    has_reducer = any(
        pattern in text
        for pattern in RISK_REDUCERS
    )

    analysis["risk_baseline"] = baseline
    analysis["risk_escalated"] = has_escalator
    analysis["risk_reduced"] = has_reducer

    if baseline == "limited_liability":

        standard_liability_patterns = [
            "limited to the total amount paid",
            "limited to amounts paid",
            "plafonnée au montant payé",
            "limitée au montant total payé",
            "حد المسؤولية",
        ]

        severe_liability_patterns = [
            "gross negligence excluded",
            "intentional misconduct excluded",
            "all damages excluded",
            "indirect damages only",
            "faute lourde exclue",
            "dol exclu",
        ]

        standard_cap = any(
            p in text
            for p in standard_liability_patterns
        )

        severe_cap = any(
            p in text
            for p in severe_liability_patterns
        )

        if standard_cap and not severe_cap:

            analysis["red_flag"] = False
            analysis["red_flag_reason"] = ""

            if analysis.get("risk_level") == "high":
                analysis["risk_level"] = "medium"

            if analysis.get("negotiation_priority") == "high":
                analysis["negotiation_priority"] = "medium"

    if baseline in LOW_RISK_CLAUSES:

        if not has_escalator:

            analysis["red_flag"] = False
            analysis["red_flag_reason"] = ""

            if analysis.get("risk_level") in {"high", "medium"}:
                analysis["risk_level"] = "low"

            analysis["negotiation_priority"] = "low"

        elif analysis.get("risk_level") == "high":

            analysis["risk_level"] = "medium"

            if analysis.get("negotiation_priority") == "high":
                analysis["negotiation_priority"] = "medium"

    elif baseline in MEDIUM_RISK_CLAUSES:

        if has_reducer and not has_escalator:

            if analysis.get("risk_level") == "high":
                analysis["risk_level"] = "medium"

            analysis["red_flag"] = False
            analysis["red_flag_reason"] = ""

        elif not has_escalator and analysis.get("risk_level") == "high":

            analysis["risk_level"] = "medium"

    elif baseline in HIGH_RISK_CLAUSES:

        if has_reducer and not has_escalator:

            if analysis.get("risk_level") == "high":
                analysis["risk_level"] = "medium"

        else:

            if analysis.get("risk_level") == "low":
                analysis["risk_level"] = "medium"

    if has_reducer and analysis.get("risk_level") == "high":

        analysis["risk_level"] = "medium"

        if analysis.get("negotiation_priority") == "high":
            analysis["negotiation_priority"] = "medium"

    return analysis


def normalize_importance_score(
    results: list[dict],
) -> int:

    risk_weights = {
        "low": 0,
        "medium": 8,
        "high": 20,
    }

    materiality_weights = {
        "low": 8,
        "medium": 16,
        "high": 24,
    }

    if not results:
        return 0

    total_risk_points = 0
    total_materiality_points = 0

    for item in results:

        risk_level = item.get("risk_level", "low")
        materiality_level = item.get(
            "materiality_level",
            "medium",
        )

        total_risk_points += risk_weights.get(
            risk_level,
            0,
        )

        total_materiality_points += materiality_weights.get(
            materiality_level,
            16,
        )

    if total_materiality_points <= 0:
        return 0

    return round(
        min(
            100,
            (
                total_risk_points
                / total_materiality_points
            ) * 100,
        )
    )


def calibrate_risk_level(
    analysis: dict,
    clause_text: str,
) -> dict:

    text = clause_text.lower()

    clause_type = analysis.get("clause_type")

    red_flag = analysis.get("red_flag")

    security_standard_patterns = [
        "iso 27001",
        "soc 2",
        "nist",
        "recognized security standard",
        "recognised security standard",
        "industry-standard security",
        "reasonable security measures",

        "iso 27001",
        "soc 2",
        "nist",
        "norme de sécurité reconnue",
        "standards de sécurité reconnus",
        "mesures de sécurité raisonnables",

        "معيار أمني معترف",
        "معايير أمنية معترف",
        "تدابير أمنية معقولة",
        "ضوابط أمنية معقولة",
    ]

    weak_security_patterns = [
        "no security measures",
        "without security measures",
        "sole discretion",
        "no audit rights",
        "no breach notification",

        "sans mesures de sécurité",
        "à sa seule discrétion",
        "aucun droit d'audit",
        "aucune notification de violation",

        "دون تدابير أمنية",
        "وفق تقديره المطلق",
        "لا يوجد حق تدقيق",
        "دون إخطار بالاختراق",
    ]

    if clause_type == "data_privacy_security":
        if any(p in text for p in weak_security_patterns):
            analysis["risk_level"] = "high"
            analysis["red_flag"] = True

            if not analysis.get("red_flag_reason"):
                analysis["red_flag_reason"] = (
                    "The clause may leave data or security obligations insufficiently controlled."
                )

        elif (
            analysis.get("risk_level") == "low"
            and any(p in text for p in security_standard_patterns)
        ):
            analysis["risk_level"] = "medium"

            if analysis.get("negotiation_priority") == "low":
                analysis["negotiation_priority"] = "medium"

    low_materiality_patterns = [

        "effective as of",
        "notice address",
        "contact information",
        "headings",
        "table of contents",
        "reference only",
        "entire agreement",

        "invoice number",
        "billing address",
        "payment date",

        "à titre indicatif",
        "adresse de notification",
        "intégralité de l'accord",

        "لأغراض مرجعية فقط",
        "عنوان الإشعار",
        "الاتفاق الكامل",
    ]

    informational_types = {
        "other",
    }

    if (
        not red_flag
        and clause_type in informational_types
    ):

        for pattern in low_materiality_patterns:

            if pattern in text:

                analysis["risk_level"] = "low"

                if analysis.get(
                    "negotiation_priority"
                ) == "medium":

                    analysis[
                        "negotiation_priority"
                    ] = "low"

                break

    calculation_patterns = [
        "counted toward",
        "calculated based on",
        "maximum bonus",
        "threshold",
        "limit applicable",

        "plafond",
        "calculé sur",
        "seuil",

        "حد أقصى",
        "يحسب على",
        "عتبة",
    ]

    explicit_high_risk_patterns = [
        "penalty",
        "liquidated damages",
        "fine",
        "exclusive",
        "exclusivity",
        "non-compete",
        "restriction",
        "restrictive covenant",
        "unlimited liability",
        "indemnify",
        "indemnification",

        "pénalité",
        "amende",
        "exclusivité",
        "non-concurrence",
        "responsabilité illimitée",
        "indemniser",

        "غرامة",
        "حصري",
        "عدم المنافسة",
        "مسؤولية غير محدودة",
        "تعويض",
    ]

    if any(p in text for p in calculation_patterns):

        explicit_high_risk = any(
            p in text
            for p in explicit_high_risk_patterns
        )

        if not explicit_high_risk:

            if analysis.get("red_flag"):

                analysis["red_flag"] = False
                analysis["red_flag_reason"] = ""

            if analysis.get("risk_level") == "medium":

                analysis["risk_level"] = "low"
                analysis["negotiation_priority"] = "low"

    payment_calculation_patterns = [
        "bonus",
        "commercial quantities",
        "production",
        "threshold",
        "maximum bonus",
        "performance-based",

        "prime",
        "seuil",
        "production",

        "مكافأة",
        "إنتاج",
        "حد أقصى",
    ]

    severe_payment_risk_patterns = [
        "penalty",
        "liquidated damages",
        "unlimited liability",
        "sole discretion",
        "unilateral",
        "must pay",
        "shall pay regardless",
        "impossible payment",

        "pénalité",
        "responsabilité illimitée",
        "seule discrétion",
        "unilatéral",

        "غرامة",
        "مسؤولية غير محدودة",
        "تقديره المطلق",
    ]

    if (
        analysis.get("clause_type") == "payment"
        and any(
            p in text
            for p in payment_calculation_patterns
        )
    ):

        severe_payment_risk = any(
            p in text
            for p in severe_payment_risk_patterns
        )

        if not severe_payment_risk:

            analysis["red_flag"] = False
            analysis["red_flag_reason"] = ""

            if analysis.get("risk_level") == "high":
                analysis["risk_level"] = "medium"

            if analysis.get("negotiation_priority") == "high":
                analysis["negotiation_priority"] = "medium"

    safe_jurisdiction_patterns = [
        "tribunaux compétents de paris",
        "droit français",
        "courts of paris",
        "french law",
        "المحاكم المختصة بمدينة الدار البيضاء",
        "قوانين المملكة المغربية",
        "courts of casablanca",
        "laws of morocco",
    ]

    if any(
        p in text
        for p in safe_jurisdiction_patterns
    ):

        analysis["red_flag"] = False
        analysis["red_flag_reason"] = ""

        if analysis.get("risk_level") == "medium":
            analysis["risk_level"] = "low"

        if analysis.get("negotiation_priority") == "medium":
            analysis["negotiation_priority"] = "low"

    ip_transfer_patterns = [
        "transfer of ownership upon full payment",
        "ownership transfers after full payment",
        "assignment after payment",
        "cession après paiement",
        "transfert de propriété après paiement",
        "transfer of property after payment",
        "الملكية بعد السداد",
    ]

    if any(
        p in text
        for p in ip_transfer_patterns
    ):

        analysis["red_flag"] = False
        analysis["red_flag_reason"] = ""

        if analysis.get("risk_level") == "high":
            analysis["risk_level"] = "medium"

        if analysis.get("negotiation_priority") == "high":
            analysis["negotiation_priority"] = "medium"

    if analysis.get("risk_level") == "high":

        high_risk_patterns = [

            "unlimited liability",
            "indemnify",
            "indemnification",
            "waiver of liability",

            "non-compete",
            "exclusive",
            "exclusivity",

            "liquidated damages",
            "penalty",
            "fine",

            "assign any and all rights",
            "irrevocable",

            "responsabilité illimitée",
            "non-concurrence",
            "exclusivité",
            "pénalité",
            "cession des droits",

            "مسؤولية غير محدودة",
            "عدم المنافسة",
            "حصري",
            "غرامة",
            "التنازل عن الحقوق",
        ]

        matched = any(
            pattern in text
            for pattern in high_risk_patterns
        )

        if not matched and not red_flag:

            analysis["risk_level"] = "medium"

    return analysis


def detect_clause_materiality(
    analysis: dict,
    clause_text: str,
) -> str:

    text = clause_text.lower()

    broad_confidentiality_patterns = [
        "trade secret",
        "trade secrets",
        "all confidential information",
        "perpetual confidentiality",
        "confidentiality obligations survive indefinitely",
        "indefinitely confidential",

        "secret commercial",
        "secrets commerciaux",
        "toute information confidentielle",
        "confidentialité perpétuelle",
        "obligations de confidentialité survivent indéfiniment",
        "confidentiel indéfiniment",

        "سر تجاري",
        "أسرار تجارية",
        "جميع المعلومات السرية",
        "سرية دائمة",
        "تظل التزامات السرية إلى أجل غير مسمى",
    ]

    standard_confidentiality_patterns = [
        "confidentiality",
        "confidential information",
        "confidentialité",
        "information confidentielle",
        "سرية",
        "معلومات سرية",
    ]

    if any(
        pattern in text
        for pattern in broad_confidentiality_patterns
    ):
        return "high"

    if any(
        pattern in text
        for pattern in standard_confidentiality_patterns
    ):
        return "medium"

    high_materiality_patterns = [
        "payment",
        "bonus",
        "termination",
        "liability",
        "intellectual property",
        "ownership",
        "non-compete",
        "exclusivity",
        "penalty",
        "liquidated damages",

        "paiement",
        "prime",
        "résiliation",
        "responsabilité",
        "propriété intellectuelle",
        "non-concurrence",
        "exclusivité",
        "pénalité",

        "دفع",
        "مكافأة",
        "إنهاء",
        "مسؤولية",
        "ملكية فكرية",
        "عدم المنافسة",
        "حصري",
        "غرامة",
    ]

    medium_materiality_patterns = [
        "governing law",
        "jurisdiction",
        "venue",
        "notice",
        "term",
        "fixed term",

        "droit applicable",
        "droit français",
        "juridiction",
        "tribunaux compétents",
        "préavis",
        "durée",

        "القانون الواجب التطبيق",
        "الاختصاص",
        "إشعار",
        "مدة",
    ]

    if any(
        pattern in text
        for pattern in high_materiality_patterns
    ):
        return "high"

    if any(
        pattern in text
        for pattern in medium_materiality_patterns
    ):
        return "medium"

    clause_type = analysis.get("clause_type", "other")

    if clause_type == "confidentiality":
        return "medium"

    if clause_type in {
        "payment",
        "termination",
        "intellectual_property",
        "liability",
        "penalty",
        "exclusivity",
        "non_compete",
    }:
        return "high"

    return "low"


def calculate_clause_importance(
    analysis: dict,
    clause_text: str,
) -> int:

    text = clause_text.lower()

    baseline = analysis.get(
        "risk_baseline",
        detect_clause_baseline(analysis, clause_text),
    )

    materiality_level = detect_clause_materiality(
        analysis,
        clause_text,
    )

    analysis["materiality_level"] = materiality_level

    materiality_points = {
        "low": 8,
        "medium": 16,
        "high": 24,
    }

    risk_points = {
        "low": 0,
        "medium": 18,
        "high": 45,
    }

    score = materiality_points.get(
        materiality_level,
        16,
    )

    score += risk_points.get(
        analysis.get("risk_level", "low"),
        0,
    )

    if (
        baseline in LOW_RISK_CLAUSES
        and not analysis.get("risk_escalated")
    ):
        score -= 20

    elif baseline in MEDIUM_RISK_CLAUSES:
        score += 5

    elif baseline in HIGH_RISK_CLAUSES:
        score += 20

    if analysis.get("risk_escalated"):
        score += 25

    if analysis.get("risk_reduced"):
        score -= 20

    if analysis.get("red_flag"):
        score += 25

    if (
        baseline == "limited_liability"
        and not analysis.get("risk_escalated")
        and analysis.get("favours") != "unclear"
    ):
        score -= 25

    standard_clause_patterns = [
        "tribunaux compétents de paris",
        "droit français",
        "standard confidentiality",
        "information confidentielle",
        "confidential information",
        "responsabilité limitée",
        "limitation of liability",
        "assurance responsabilité",
        "liability insurance",
    ]

    if any(
        pattern in text
        for pattern in standard_clause_patterns
    ):

        if not analysis.get("risk_escalated"):
            score -= 15

    safe_renewal_patterns = [
        "may opt out with notice",
        "cancel with notice",
        "résiliation avec préavis",
        "يمكن الإلغاء بإشعار",
    ]

    if (
        (
            "automatic renewal" in text
            or "renouvellement automatique" in text
        )
        and any(
            pattern in text
            for pattern in safe_renewal_patterns
        )
        and not analysis.get("risk_escalated")
    ):
        score -= 10

    if (
        "tribunaux compétents de paris" in text
        or "droit français" in text
    ):
        score = min(score, 20)

    score = max(15, min(score, 90))

    return score


def detect_balancing_protections(
    clauses: list[str],
) -> dict:

    text = "\n".join(clauses).lower()

    protections = {
        "arbitration": False,
        "cure_period": False,
        "severance": False,
        "insurance": False,
        "limitation_scope": False,
    }

    arbitration_patterns = [
        "arbitration",
        "arbitrage",
        "تحكيم",
    ]

    cure_patterns = [
        "cure within",
        "period to cure",
        "diligently pursue a cure",

        "délai de correction",

        "مهلة لتصحيح",
    ]

    severance_patterns = [
        "lump sum",
        "severance",
        "salary continuation",

        "indemnité",

        "تعويض",
    ]

    insurance_patterns = [
        "liability insurance",
        "insured",

        "assurance responsabilité",

        "تأمين",
    ]

    limitation_patterns = [
        "except as provided",
        "notwithstanding",
        "does not include",

        "sauf",
        "ne comprend pas",

        "لا يشمل",
    ]

    for p in arbitration_patterns:
        if p in text:
            protections["arbitration"] = True

    for p in cure_patterns:
        if p in text:
            protections["cure_period"] = True

    for p in severance_patterns:
        if p in text:
            protections["severance"] = True

    for p in insurance_patterns:
        if p in text:
            protections["insurance"] = True

    for p in limitation_patterns:
        if p in text:
            protections["limitation_scope"] = True

    return protections


def detect_protective_beneficiary(
    clause_text: str,
) -> bool:

    text = clause_text.lower()

    protective_patterns = [
        "company will maintain insurance",
        "will maintain officers and directors liability insurance",
        "company shall indemnify",
        "company will reimburse",
        "coverage for",
        "named insured",

        "la société indemnisera",
        "la société maintiendra",

        "تلتزم الشركة",
        "تقوم الشركة بالتعويض",
    ]

    return any(
        p in text
        for p in protective_patterns
    )


def extract_reasoning_evidence(
    clause_text: str,
    max_length: int = 160,
) -> str:

    text = str(clause_text or "").strip()

    if not text:
        return ""

    text = " ".join(text.split())

    text = remove_repeated_sample_policy_disclaimer(text)

    return text[:max_length]


def compute_analysis_metadata(
    analysis: dict,
    clause_text: str,
    title: str = "",
) -> dict:

    detail_fields = [
        "recommendation",
        "negotiation_advice",
        "legal_insight",
        "safer_alternative",
    ]

    combined_text = f"{title} {clause_text}".lower()

    has_details = any(
        safe_str(
            analysis.get(field)
        )
        for field in detail_fields
    )

    has_reasoning = any([
        safe_str(analysis.get("explanation_simple")),
        safe_str(analysis.get("why_it_matters")),
        safe_str(analysis.get("legal_insight")),
    ])

    has_negotiation = bool(
        safe_str(
            analysis.get("negotiation_advice")
        )
    )

    has_legal_signal = any(
        term in combined_text
        for term in get_clause_signal_terms("critical")
    )

    has_semantic_signal = any([
        has_legal_signal,
        analysis.get("risk_level") in {"medium", "high"},
        bool(analysis.get("red_flag")),
        bool(analysis.get("risk_escalated")),
    ])

    evidence_strength = "low"

    if analysis.get("risk_level") in {"medium", "high"}:
        evidence_strength = "medium"

    if analysis.get("red_flag") or analysis.get("risk_escalated"):
        evidence_strength = "high"

    analysis["has_details"] = any([
        has_details,
        has_reasoning,
        has_negotiation,
        has_semantic_signal,
    ])

    analysis["has_reasoning"] = has_reasoning
    analysis["has_negotiation"] = has_negotiation
    analysis["has_semantic_signal"] = has_semantic_signal
    analysis["has_legal_signal"] = has_legal_signal
    analysis["evidence_strength"] = evidence_strength

    return analysis


def attach_clause_object_metadata(
    analysis: dict,
    clause_obj: dict,
) -> dict:

    analysis.update({
        "clause_id": clause_obj.get("id"),
        "parent_id": clause_obj.get("parent_id"),
        "parent_clause_id": clause_obj.get("parent_clause_id"),
        "depth": clause_obj.get("depth"),
        "level": clause_obj.get("level"),
        "section_path": clause_obj.get("section_path", []),
        "children": clause_obj.get("children", []),
        "semantic_parent": clause_obj.get("semantic_parent"),
        "confidence_score": clause_obj.get("confidence"),
        "lineage": clause_obj.get("lineage", []),
    })

    # Prefer the structurally-computed clause number (already correctly
    # derived by the document-parsing engine, e.g. "1.1") over whatever
    # analyze_clause() ended up with -- LLM-provided, or a text-based
    # regex fallback that can only find a number if it happens to still
    # be embedded in the clause's own text string, which is not
    # guaranteed depending on which parsing path produced clause_obj.
    # This is the authoritative source whenever the upstream clause
    # object provides it, sidestepping every failure mode of trying to
    # re-derive the number after the fact. Only overrides when
    # clause_obj actually has a genuine, non-empty number; otherwise
    # leaves whatever analyze_clause() already set untouched (e.g. an
    # LLM-provided reference for a clause_obj shape that has no "number"
    # field at all).
    structural_number = clause_obj.get("number")

    if structural_number:
        analysis["clause_reference"] = localize_clause_reference(
            str(structural_number),
            analysis.get("language", "en"),
        )

    return analysis


def _analyze_contract_clauses_impl(
    clauses: list[str] | list[dict],
    language: str = "en",
    max_clauses: int = 60,
    party_roles: dict | None = None,
) -> list[dict]:

    critical_terms = get_clause_signal_terms("critical")

    if clauses and isinstance(clauses[0], dict):
        clause_objects = clauses
    else:
        full_text_for_objects = "\n\n".join([
            str(c)
            for c in clauses
        ])

        clause_objects = split_into_clause_objects(
            full_text_for_objects,
        )

    full_contract_text = " ".join([
        str(
            c.get("text", "")
            if isinstance(c, dict)
            else c
        )
        for c in clause_objects
    ]).lower()

    jurisdiction_profile = detect_jurisdiction(
        full_contract_text
    )

    if not isinstance(party_roles, dict):
        party_roles = get_display_roles(
            contract_type="",
            text=full_contract_text,
            language=language,
        )

    contract_domain_reasoning = (
        get_reasoning_for_text(
            full_contract_text,
            language,
        )
    )

    results = []

    for clause_obj in clause_objects[:max_clauses]:

        clause = str(
            clause_obj.get("text", "")
        )

        analysis = analyze_clause(
            clause,
            language,
            party_roles,
        )

        analysis = attach_clause_object_metadata(
            analysis,
            clause_obj,
        )

        analysis = validate_clause_type(
            analysis,
            clause,
            language,
        )

        analysis = validate_protective_clause(
            analysis,
            clause,
        )

        analysis = validate_standard_market_protection(
            analysis,
            clause,
        )

        analysis = validate_explicit_permission_clause(
            analysis,
            clause,
        )

        analysis = validate_quoted_text(
            analysis,
            clause,
        )

        analysis = calibrate_risk_level(
            analysis,
            clause,
        )

        analysis = apply_conceptual_risk_calibration(
            analysis,
            clause,
        )

        if analysis.get("risk_level") in {"medium", "high"}:
            semantic_negotiation = get_semantic_negotiation(
                analysis,
                language=language,
            )

            if semantic_negotiation:
                analysis["negotiation_advice"] = semantic_negotiation

        else:
            analysis["negotiation_advice"] = ""

        ADMINISTRATIVE_KEYWORDS = [
            "assignment",
            "acceptance",
            "commitment",
            "schedule",
            "exhibit",
            "appendix",
            "definition",
            "effective date",
            "reference",
            "designation",
            "form of",

            "cession",
            "acceptation",
            "engagement",
            "annexe",
            "définition",
            "date d’effet",

            "التنازل",
            "القبول",
            "الالتزام",
            "ملحق",
            "تعريف",
        ]

        if (
            analysis.get("risk_level") == "medium"
            and not analysis.get("red_flag")
        ):
            lowered = clause.lower()

            matches = sum(
                1 for keyword in ADMINISTRATIVE_KEYWORDS
                if keyword in lowered
            )

            if matches >= 2:
                analysis["risk_level"] = "low"
                analysis["negotiation_priority"] = "low"

        if should_force_red_flag_false(
            analysis.get(
                "clause_title",
                "",
            ),
            clause,
        ):

            analysis["red_flag"] = False
            analysis["red_flag_reason"] = ""

        if detect_protective_beneficiary(clause):

            analysis["favours"] = "employee"

            if analysis.get("risk_level") == "medium":
                analysis["risk_level"] = "low"

            analysis["negotiation_priority"] = "low"

        if (
            analysis.get("risk_level") == "medium"
            and not analysis.get("red_flag")
            and analysis.get("clause_type") == "other"
            and analysis.get("risk_baseline") in LOW_RISK_CLAUSES
        ):
            analysis["risk_level"] = "low"
            analysis["negotiation_priority"] = "low"

        title = (
            analysis.get("clause_title")
            or extract_clause_title(clause)
        )

        title = normalize_final_clause_title(title)

        analysis["clause_title"] = title
        analysis["title"] = title

        clause_text = clause

        analysis = compute_analysis_metadata(
            analysis,
            clause_text,
            title,
        )

        if (
            analysis.get("risk_level") == "low"
            and not analysis.get("has_legal_signal")
            and not analysis.get("has_semantic_signal")
        ):
            analysis["negotiation_priority"] = "low"

        medium_risk_keywords = [
            "terminate immediately",
            "confidentiality",
            "limitation of liability",
            "late payment penalty",
            "default",
            "acceleration",
            "exclusive",
            "non-exclusive",
            "interest rate",
            "liability cap",

            "résiliation immédiate",
            "confidentialité",
            "limitation de responsabilité",
            "défaut",
            "taux d'intérêt",

            "فسخ",
            "سرية",
            "المسؤولية",
            "الإخلال",
            "الفائدة",
        ]

        combined = " ".join([
            title,
            clause_text,
        ]).lower()

        if (
            "non-exclusive" in combined
            or "non exclusive" in combined
            or "غير حصري" in combined
            or "non exclusif" in combined
        ):
            if analysis.get("risk_level") == "high":
                analysis["risk_level"] = "medium"

        standard_payment_safe = any(
            term in combined
            for term in [
                "30 days",
                "within thirty days",
                "fixed monthly fee",
                "monthly fee",
                "payable within",
                "dans un délai de 30 jours",
                "montant fixe mensuel",
                "paiement mensuel",
                "دفع خلال",
                "ثلاثين يوم",
                "رسوم شهرية",
            ]
        )

        keyword_match = any(
            k in combined
            for k in medium_risk_keywords
        )

        risky_wording_terms = [
            "immediately",
            "without notice",
            "without cure",
            "sole discretion",
            "unilateral",
            "late payment penalty",
            "acceleration",
            "exclusive",
            "non-compete",
            "unlimited",
            "material breach",

            "immédiatement",
            "sans préavis",
            "sans délai de correction",
            "seule discrétion",
            "unilatéral",
            "pénalité",
            "défaut",
            "exclusif",

            "فوري",
            "دون إشعار",
            "دون مهلة",
            "تقديره المطلق",
            "من جانب واحد",
            "غرامة",
            "إخلال جوهري",
            "حصري",
        ]

        risky_wording_match = any(
            term in combined
            for term in risky_wording_terms
        )

        if (
            analysis.get("risk_level") == "low"
            and keyword_match
            and not standard_payment_safe
            and (
                analysis.get("risk_escalated")
                or analysis.get("red_flag")
                or risky_wording_match
            )
        ):
            analysis["risk_level"] = "medium"

        analysis["importance_score"] = (
            calculate_clause_importance(
                analysis,
                clause,
            )
        )

        definition_keywords = [
            "defined terms",
            "definition",
            "definitions",
            "means",
            "shall mean",

            "définition",
            "définitions",
            "désigne",
            "signifie",

            "التعريفات",
            "تعريف",
            "يقصد به",
            "يعني",
        ]

        lowered_clause = clause.lower()

        definition_matches = sum(
            1 for keyword in definition_keywords
            if keyword in lowered_clause
        )

        if (
            definition_matches >= 2
            and analysis.get("risk_level") == "low"
            and analysis.get("materiality_level") != "high"
        ):
            analysis["risk_level"] = "low"
            analysis["negotiation_priority"] = "low"
            analysis["recommendation"] = ""
            analysis["negotiation_advice"] = ""
            analysis["safer_alternative"] = ""

        normalized_clause = " ".join(
            clause.strip().split()
        )

        word_count = len(normalized_clause.split())

        critical_short_clause = any(
            term in normalized_clause.lower()
            for term in get_clause_signal_terms("critical")
        )

        fragment_like = (
            not critical_short_clause
            and (
                normalized_clause.endswith(",")
                or normalized_clause.endswith(";")
                or (
                    normalized_clause.isupper()
                    and word_count <= 8
                )
            )
        )

        if fragment_like:
            analysis["risk_level"] = "low"
            analysis["negotiation_priority"] = "low"

            analysis["recommendation"] = (
                "This text appears to be a heading or incomplete clause fragment."
            )

            analysis["negotiation_advice"] = ""
            analysis["legal_insight"] = ""
            analysis["market_comparison"] = ""
            analysis["safer_alternative"] = ""

        lowered_clause = clause.lower()

        definition_or_fragment = (
            " means " in lowered_clause
            or " shall mean " in lowered_clause
            or " désigne " in lowered_clause
            or " signifie " in lowered_clause
            or " يقصد به " in lowered_clause
            or " يعني " in lowered_clause
        )

        critical_definition_terms = [
            "breach",
            "default",
            "liability",
            "payment",
            "termination",
            "indemnity",
            "material breach",
            "acceleration",
            "confidentiality",
            "intellectual property",
            "data protection",
            "service level",

            "manquement",
            "défaut",
            "responsabilité",
            "paiement",
            "résiliation",
            "indemnisation",
            "confidentialité",
            "propriété intellectuelle",
            "protection des données",
            "niveau de service",

            "إخلال",
            "الإخلال",
            "المسؤولية",
            "الدفع",
            "فسخ",
            "إنهاء",
            "تعويض",
            "السرية",
            "الملكية الفكرية",
            "حماية البيانات",
            "مستوى الخدمة",
        ]

        is_critical_definition = any(
            term in lowered_clause
            for term in critical_definition_terms
        )

        if definition_or_fragment and not is_critical_definition:
            analysis["risk_level"] = "low"
            analysis["red_flag"] = False
            analysis["red_flag_reason"] = ""
            analysis["negotiation_priority"] = "low"

            analysis["explanation_simple"] = (
                "This clause is primarily administrative or definitional."
            )

            if language == "fr":
                analysis["explanation_simple"] = (
                    "Cette clause est principalement administrative ou définitionnelle."
                )

            elif language == "ar":
                analysis["explanation_simple"] = (
                    "هذا البند ذو طبيعة تعريفية أو إدارية بشكل أساسي."
                )

            analysis["recommendation"] = ""
            analysis["negotiation_advice"] = ""
            analysis["legal_insight"] = ""
            analysis["market_comparison"] = ""
            analysis["safer_alternative"] = ""

        quoted_text = str(
            analysis.get("quoted_text", "")
        ).strip()

        weak_context = (
            not analysis.get("has_legal_signal")
            and not analysis.get("risk_escalated")
            and len(quoted_text.split()) < 6
        )

        if weak_context:
            analysis["negotiation_advice"] = ""
            analysis["safer_alternative"] = ""

            if not analysis.get("legal_insight"):
                analysis["legal_insight"] = ""

        detail_fields = [
            "recommendation",
            "negotiation_advice",
            "legal_insight",
            "market_comparison",
            "safer_alternative",
        ]

        always_important_keywords = [
            # English
            "default",
            "termination",
            "liability",
            "confidentiality",
            "interest",
            "payment",
            "penalty",
            "indemnity",

            "maintenance",
            "repair",

            "governing law",
            "exclusive",
            "non-compete",

            # French
            "défaut",
            "résiliation",
            "responsabilité",
            "confidentialité",
            "paiement",
            "pénalité",
            "indemnisation",

            "maintenance",
            "réparation",
            "entretien",

            "droit applicable",
            "exclusif",

            # Arabic
            "فسخ",
            "إنهاء",
            "المسؤولية",
            "السرية",
            "الدفع",
            "غرامة",
            "تعويض",

            "صيانة",
            "إصلاحات",

            "القانون",
            "حصري",
        ]

        combined_text = " ".join([
            title,
            clause_text,
        ]).lower()

        important_keywords = [
            "termination",
            "default",
            "payment",
            "liability",
            "confidentiality",
            "intellectual property",

            "résiliation",
            "défaut",
            "paiement",
            "responsabilité",

            "فسخ",
            "الإخلال",
            "الدفع",
            "الملكية الفكرية",
        ]

        meaningful_content = any([
            analysis.get("quoted_text"),
            analysis.get("explanation_simple"),
            any(
                safe_str(analysis.get(field))
                for field in detail_fields
            ),
        ])

        if not meaningful_content:
            continue

        generic_detail_phrases = [
            "avoid disputes",
            "future disputes",
            "ensure clarity",
            "consider negotiating",
            "potential disputes",
            "may lead to",
            "could impact",
            "market standards",
            "more favorable",
            "business growth",
            "operational flexibility",
        ]

        generic_detail_phrases = [
            "while this clause is standard",
            "could lead to disputes",
            "potential disputes",
            "may limit",
            "could impact",
            "may face",
            "may create",
            "standard but",
            "avoid ambiguity",
            "ensure clarity",
            "consider negotiating",

            "peut limiter",
            "pourrait",
            "peut entraîner",
            "risques potentiels",
            "éviter toute ambiguïté",

            "قد",
            "يمكن أن",
            "قد يؤدي",
        ]

        detail_fields = [
            "recommendation",
            "negotiation_advice",
            "legal_insight",
            "safer_alternative",
        ]

        for field in detail_fields:
            value = str(
                analysis.get(field, "")
            ).lower()

            if any(
                phrase in value
                for phrase in generic_detail_phrases
            ):
                analysis[field] = ""

        # Keep all analyzed clauses, including low-risk clauses.
        # Low-risk clauses are useful for transparency in FR/EN/AR.

        important_clause_keywords = [
            "termination", "default", "acceleration", "liability",
            "confidentiality", "intellectual property", "data protection",
            "service level", "maintenance", "repair",

            "résiliation", "défaut", "responsabilité",
            "confidentialité", "propriété intellectuelle",
            "protection des données", "disponibilité", "entretien",

            "فسخ", "إنهاء", "الإخلال", "المسؤولية",
            "السرية", "الملكية الفكرية", "حماية البيانات",
            "مستوى الخدمة", "الصيانة", "الإصلاحات",
        ]

        combined_text = f"{title} {clause}".lower()

        domain_reasoning = contract_domain_reasoning

        domain_reasoning_allowed = (
            analysis.get("risk_level") in {"medium", "high"}
            or any(
                safe_str(analysis.get(field))
                for field in detail_fields
            )
            or any(
                k in combined_text
                for k in critical_terms
            )
        )

        if any(
            k in combined_text
            for k in important_clause_keywords
        ):
            if (
                "administrative"
                in analysis.get(
                    "explanation_simple",
                    ""
                ).lower()
            ):
                analysis["explanation_simple"] = (
                    "This clause contains operational or legal obligations."
                    if language == "en"
                    else
                    "Cette clause contient des obligations juridiques ou opérationnelles."
                    if language == "fr"
                    else
                    "تتضمن هذه المادة التزامات قانونية أو تشغيلية."
                )

        if (
            analysis.get("risk_level") in {"medium", "high"}
            and not analysis.get("legal_insight")
        ):
            analysis["legal_insight"] = (
                "This clause should be reviewed because it may affect legal, financial, or operational obligations."
                if language == "en"
                else
                "Cette clause doit être examinée car elle peut affecter des obligations juridiques, financières ou opérationnelles."
                if language == "fr"
                else
                "ينبغي مراجعة هذه المادة لأنها قد تؤثر على الالتزامات القانونية أو المالية أو التشغيلية."
            )

        medium_risk_terms = [
            "material breach", "default", "acceleration", "late payment",
            "termination", "confidentiality", "liability cap",
            "service level", "data protection",

            "manquement important", "défaut", "résiliation",
            "retard de paiement", "confidentialité",
            "plafond de responsabilité", "protection des données",

            "إخلال جوهري", "الإخلال", "فسخ", "إنهاء",
            "تأخر الدفع", "السرية", "حد المسؤولية",
            "حماية البيانات",
        ]

        if (
            analysis.get("risk_level") == "low"
            and any(
                term in combined_text
                for term in medium_risk_terms
            )
        ):
            analysis["risk_level"] = "medium"

        clause_type_text = f"{title} {clause}".lower()

        critical_terms = [
            "termination",
            "default",
            "acceleration",
            "liability",
            "confidentiality",
            "data protection",
            "service level",
            "governing law",
            "indemnity",
            "security",

            "résiliation",
            "défaut",
            "responsabilité",
            "confidentialité",
            "protection des données",
            "niveau de service",
            "droit applicable",

            "فسخ",
            "إنهاء",
            "الإخلال",
            "المسؤولية",
            "السرية",
            "حماية البيانات",
            "مستوى الخدمة",
            "القانون الواجب التطبيق",
            "payment",

            "pricing",

            "maintenance",

            "repair",

            "covenants",

            "paiement",

            "prix",

            "maintenance",

            "réparations",

            "الدفع",

            "الأسعار",

            "الصيانة",

            "الإصلاحات",

            "التعهدات",

        ]

        if any(
            t in clause_type_text
            for t in critical_terms
        ):

            maintenance_terms = [
                "maintenance",
                "repair",
                "صيانة",
                "إصلاح",
            ]

            excluded_contexts = [
                "service level",
                "sla",
                "uptime",
                "disponibilité",
                "payment",
                "pricing",
                "الدفع",
                "الأسعار",
                "مستوى الخدمة",
            ]

            disable_maintenance_override = (
                "service level" in clause_type_text
                or "uptime" in clause_type_text
                or "disponibilité" in clause_type_text
                or "مستوى الخدمة" in clause_type_text
            )

            if (
                not disable_maintenance_override
                and any(
                    term in clause_type_text
                    for term in maintenance_terms
                )
                and not any(
                    term in clause_type_text
                    for term in excluded_contexts
                )
            ):
                analysis["explanation_simple"] = (
                    "This clause allocates maintenance and repair "
                    "responsibilities between the parties."
                    if language == "en"
                    else
                    "Cette clause répartit les responsabilités de "
                    "maintenance et de réparation entre les parties."
                    if language == "fr"
                    else
                    "تحدد هذه المادة توزيع مسؤوليات الصيانة "
                    "والإصلاح بين الأطراف."
                )

            elif (
                "administrative"
                in analysis.get(
                    "explanation_simple",
                    ""
                ).lower()
                or
                "تعريفية"
                in analysis.get(
                    "explanation_simple",
                    ""
                )
            ):
                analysis["explanation_simple"] = (
                    "This clause defines operational responsibilities, "
                    "maintenance obligations, or commercial duties."
                    if language == "en"
                    else
                    "Cette clause définit des responsabilités "
                    "opérationnelles, des obligations de maintenance "
                    "ou des engagements commerciaux."
                    if language == "fr"
                    else
                    "تحدد هذه المادة التزامات تشغيلية أو مسؤوليات "
                    "صيانة أو التزامات تجارية."
                )

            if (
                not analysis.get("recommendation")
                and analysis.get("risk_level") in {"medium", "high"}
                and analysis.get("clause_type") not in {"other"}
            ):
                analysis["recommendation"] = ""
        high_risk_terms = [
            "unlimited liability",
            "acceleration",
            "immediate termination",
            "exclusive jurisdiction",
            "data breach",
            "security incident",
            "cross default",

            "responsabilité illimitée",
            "résiliation immédiate",
            "violation de données",

            "مسؤولية غير محدودة",
            "إنهاء فوري",
            "اختراق البيانات",
        ]

        if any(
            term in clause_type_text
            for term in high_risk_terms
        ):
            analysis["risk_level"] = "high"

        if (
            domain_reasoning_allowed
            and not analysis.get("legal_insight")
            and domain_reasoning.get("reasoning")
        ):
            analysis["legal_insight"] = (
                domain_reasoning["reasoning"]
            )

        meaningful_legal_signals = [
            "exclusive",
            "non-exclusive",
            "termination",
            "payment",
            "confidentiality",
            "liability",
            "distribution",
        ]


        analysis = compute_analysis_metadata(
            analysis,
            clause_text,
            title,
        )

        generic_recommendations = [
            "review allocation of obligations and risk exposure",
            "examiner attentivement la répartition des obligations",
            "ينبغي مراجعة توزيع الالتزامات والمخاطر",
        ]

        recommendation = (
            analysis.get("recommendation") or ""
        ).lower()

        if (
            any(g in recommendation for g in generic_recommendations)
            and analysis.get("risk_level") == "low"
        ):
            analysis["recommendation"] = ""

        analysis = apply_reasoning_quality_gate(
            analysis,
            clause_text,
            language,
        )

        analysis = compute_analysis_metadata(
            analysis,
            clause_text,
            title,
        )

        for field in [
            "legal_insight",
            "negotiation_advice",
            "recommendation",
        ]:
            if not analysis.get(field):
                analysis[field] = ""

        if (
            not analysis.get("explanation")
            and not analysis.get("explanation_simple")
            and analysis.get("risk_level") == "low"
        ):
            analysis["explanation_simple"] = (
                "This clause appears administrative or operational in nature."
                if language == "en"
                else
                "Cette clause semble principalement administrative ou opérationnelle."
                if language == "fr"
                else
                "تبدو هذه المادة ذات طبيعة إدارية أو تشغيلية."
            )
            analysis["explanation"] = analysis["explanation_simple"]

        if title in {"استعمال المحل", "Use of Premises", "Usage des locaux"}:
            analysis["risk_level"] = "low"
            analysis["red_flag"] = False
            analysis["red_flag_reason"] = ""
            analysis["negotiation_advice"] = ""

        analysis = build_risk_explanation(
            analysis,
            clause_text,
        )

        if not analysis.get("legal_insight"):

            if analysis.get("risk_level") == "medium":

                analysis["legal_insight"] = (
                    "This clause may create legal or operational exposure."
                    if language == "en"
                    else (
                        "Cette clause peut créer une exposition juridique ou opérationnelle."
                        if language == "fr"
                        else (
                            "قد تنشئ هذه المادة تعرضاً قانونياً أو تشغيلياً."
                        )
                    )
                )

            elif analysis.get("risk_level") == "low":

                _confidence_value = analysis.get("confidence")
                if _confidence_value and _confidence_value != "high":
                    # UNKNOWN-IS-NOT-SAFE: classification confidence
                    # was not high (the clause's own type required
                    # correction earlier in the pipeline), so a "low
                    # risk_level" here reflects the absence of a
                    # matched red-flag pattern for an uncertain
                    # classification -- not a confirmed absence of
                    # risk. Do not serialize the unqualified positive
                    # statement in this case.
                    analysis["legal_insight"] = (
                        "No specific risk pattern was matched for this clause, but classification confidence was not high -- a manual review is recommended rather than treating this as a confirmed absence of risk."
                        if language == "en"
                        else (
                            "Aucun motif de risque spécifique n'a été identifié pour cette clause, mais la confiance de classification n'était pas élevée -- une revue manuelle est recommandée plutôt que de considérer cela comme une absence de risque confirmée."
                            if language == "fr"
                            else (
                                "لم يتم رصد نمط مخاطر محدد لهذا البند، لكن مستوى الثقة في التصنيف لم يكن مرتفعاً -- يُنصح بمراجعة يدوية بدلاً من اعتبار ذلك غياباً مؤكداً للمخاطر."
                            )
                        )
                    )
                else:
                    analysis["legal_insight"] = (
                        "No significant legal imbalance detected."
                        if language == "en"
                        else (
                            "Aucun déséquilibre juridique significatif détecté."
                            if language == "fr"
                            else (
                                "لم يتم رصد اختلال قانوني جوهري."
                            )
                        )
                    )

        if not analysis.get("title"):
            analysis["title"] = "Untitled Clause"

        analysis = normalize_ai_role_words(
            analysis,
            party_roles or {},
            language,
        )

        result_item = {
            "title": title,
            "original_text": clause[:1000],
            "reasoning_evidence": extract_reasoning_evidence(
                clause_text
            ),
            **analysis,
        }

        result_item = normalize_ai_role_words(
            result_item,
            party_roles or {},
            language,
        )

        results.append(result_item)

    results = sorted(
        results,
        key=lambda x: x.get(
            "importance_score",
            0,
        ),
        reverse=True,
    )

    seen_quotes = set()
    deduped = []

    for item in results:

        quote = (
            item.get("quoted_text", "")
            .lower()
            .strip()
        )[:80]

        if quote and quote in seen_quotes:
            continue

        seen_quotes.add(quote)
        deduped.append(item)

    normalized_contract_score = normalize_importance_score(
        deduped
    )

    # Transparency metadata: previously, when a contract had more raw
    # clauses than max_clauses, the excess was silently dropped -- the
    # user had no way to know their report only covered a subset of the
    # contract. This attaches the true detected count and a truncation
    # flag to every item (mirroring how normalized_contract_score is
    # already attached per-item), so run() can surface it at the
    # document level and strip these internal-use keys before the
    # response is returned.
    total_clauses_detected = len(clause_objects)
    clauses_truncated = total_clauses_detected > max_clauses

    for item in deduped:
        item["normalized_contract_score"] = normalized_contract_score
        item["_total_clauses_detected"] = total_clauses_detected
        item["_clauses_truncated"] = clauses_truncated

    return deduped


def display_safe_clause_labels(value, language: str = "en"):
    language = normalize_language(language)

    labels = {
        "en": {
            "[CLIENT]": "Client",
            "[SERVICE_PROVIDER]": "Provider",
            "[ORGANIZATION]": "Organization",
            "[PERSON]": "Person",
            "[COMPANY]": "Company",
            "[BUYER]": "Buyer",
            "[SELLER]": "Seller",
            "[LENDER]": "Lender",
            "[BORROWER]": "Borrower",
            "[EMPLOYER]": "the relevant contractual party",
            "[EMPLOYEE]": "personnel",
        },
        "fr": {
            "[CLIENT]": "Client",
            "[SERVICE_PROVIDER]": "Prestataire",
            "[ORGANIZATION]": "Organisation",
            "[PERSON]": "Personne",
            "[COMPANY]": "Société",
            "[BUYER]": "Acheteur",
            "[SELLER]": "Vendeur",
            "[LENDER]": "Prêteur",
            "[BORROWER]": "Emprunteur",
            "[EMPLOYER]": "la partie contractuelle concernée",
            "[EMPLOYEE]": "le personnel",
        },
        "ar": {
            "[CLIENT]": "العميل",
            "[SERVICE_PROVIDER]": "مقدم الخدمة",
            "[ORGANIZATION]": "المنظمة",
            "[PERSON]": "الشخص",
            "[COMPANY]": "الشركة",
            "[BUYER]": "المشتري",
            "[SELLER]": "البائع",
            "[LENDER]": "المقرض",
            "[BORROWER]": "المقترض",
            "[EMPLOYER]": "الطرف التعاقدي المعني",
            "[EMPLOYEE]": "الموظفون المعنيون",
        },
    }

    mapping = labels.get(language, labels["en"])

    if isinstance(value, list):
        return [display_safe_clause_labels(item, language) for item in value]

    if isinstance(value, dict):
        return {
            key: display_safe_clause_labels(item, language)
            for key, item in value.items()
        }

    if not isinstance(value, str):
        return value

    output = value

    for old, new in mapping.items():
        output = output.replace(old, new)

    return output


class ClauseAnalysisPipeline:
    """
    Explicit orchestration wrapper for clause analysis.
    """

    def __init__(
        self,
        clauses: list[str],
        language: str = "en",
        max_clauses: int = 60,
        party_roles: dict | None = None,
    ) -> None:
        self.clauses = clauses
        self.language = language
        self.max_clauses = max_clauses
        self.party_roles = party_roles

    def run_detection(self) -> list[dict]:
        return _analyze_contract_clauses_impl(
            self.clauses,
            self.language,
            self.max_clauses,
            self.party_roles,
        )

    def run_validation(self, results: list[dict]) -> list[dict]:
        return results

    def run_risk(self, results: list[dict]) -> list[dict]:
        return results

    def run_calibration(self, results: list[dict]) -> list[dict]:
        return results

    def run_negotiation(self, results: list[dict]) -> list[dict]:
        return results

    def run_scoring(self, results: list[dict]) -> list[dict]:
        return results

    def run_cleanup(self, results: list[dict]) -> list[dict]:
        cleaned = results

        PREAMBLE_SIGNALS = [
            "by and between", "entered into", "made and entered into",
            "conclu entre", "conclue entre", "est conclu",
            "بين", "أبرم", "أُبرم",
        ]

        def _find_preamble_text(clauses):
            for item in clauses:
                combined = (
                    f"{item.get('clause_title', '')} {item.get('quoted_text', '')}"
                ).lower()
                if any(signal in combined for signal in PREAMBLE_SIGNALS):
                    return f"{item.get('clause_title', '')} {item.get('quoted_text', '')}"
            return ""

        combined_text = " ".join(
            str(item.get("clause_title", "")) + " " +
            str(item.get("explanation_simple", "")) + " " +
            str(item.get("quoted_text", ""))
            for item in cleaned
        )

        preamble_text = _find_preamble_text(cleaned)
        role_detection_text = preamble_text if preamble_text else combined_text

        roles = self.party_roles if isinstance(self.party_roles, dict) else get_display_roles(
            contract_type="",
            text=role_detection_text,
            language=self.language,
        )

        cleaned = safe_apply_display_roles(
            cleaned,
            roles,
            self.language,
        )

        cleaned = normalize_ai_role_words(
            cleaned,
            roles,
            self.language,
        )

        party_a = roles.get("party_a")
        party_b = roles.get("party_b")

        def _normalize_role(value: str | None) -> str:
            normalized = str(value or "").strip().lower()
            normalized = normalized.replace("_", " ").replace("-", " ")
            normalized = " ".join(normalized.split())

            for prefix in ("the ", "le ", "la ", "l'", "l’"):
                if normalized.startswith(prefix):
                    normalized = normalized[len(prefix):].strip()

            return normalized

        detected_role_map = {}

        if party_a:
            detected_role_map[_normalize_role(party_a)] = party_a

        if party_b:
            detected_role_map[_normalize_role(party_b)] = party_b

        static_labels = {
            "balanced": {
                "en": "Balanced",
                "fr": "Équilibré",
                "ar": "متوازن",
            }.get(self.language, "Balanced"),

            "unclear": {
                "en": "Unclear",
                "fr": "Non clair",
                "ar": "غير واضح",
            }.get(self.language, "Unclear"),
        }

        for item in cleaned:
            favours = str(item.get("favours", "")).strip()
            normalized_favours = _normalize_role(favours)

            if normalized_favours in static_labels:
                item["favours"] = static_labels[normalized_favours]

            elif normalized_favours in detected_role_map:
                item["favours"] = detected_role_map[normalized_favours]

        cleaned = normalize_ai_role_words(
            cleaned,
            roles,
            self.language,
        )

        cleaned = [
            enforce_party_registry_on_clause_output(
                item,
                roles or {},
                self.language,
                " ".join([
                    str(item.get("clause_title", "")),
                    str(item.get("quoted_text", "")),
                    str(item.get("original_text", "")),
                    str(item.get("clause_text", "")),
                    str(item.get("explanation_simple", "")),
                    str(item.get("why_it_matters", "")),
                    str(item.get("legal_insight", "")),
                    str(item.get("red_flag_reason", "")),
                    str(item.get("recommendation", "")),
                    str(item.get("negotiation_advice", "")),
                    str(item.get("market_comparison", "")),
                    str(item.get("safer_alternative", "")),
                ]),
            )
            for item in cleaned
            if isinstance(item, dict)
        ]
        for item in cleaned:
            item["favours"] = render_canonical_favours_for_display(
                item.get("favours", "unclear"),
                roles or {},
                self.language,
            )
        return cleaned

    def run(self) -> dict:
        results = self.run_detection()

        total_clauses_detected = (
            results[0].get("_total_clauses_detected", len(results))
            if results
            else 0
        )
        clauses_truncated = (
            results[0].get("_clauses_truncated", False)
            if results
            else False
        )

        results = self.run_validation(results)
        results = self.run_risk(results)
        results = self.run_calibration(results)
        results = self.run_negotiation(results)
        results = self.run_scoring(results)
        results = self.run_cleanup(results)

        for item in results:
            item.pop("_total_clauses_detected", None)
            item.pop("_clauses_truncated", None)

        # Second, final safety net for "recommendation" AND "legal_insight":
        # the first one (inside analyze_clause(), at the end of
        # run_detection()) is confirmed to fire correctly for every
        # clause, but one or more of the later pipeline stages above
        # (run_validation, run_risk, run_calibration, run_negotiation,
        # run_scoring, run_cleanup) can still clear either field again
        # for specific clause types. This guarantees the outcome one
        # final time, after every stage has had its chance to run.
        # Confirmed real gap: simply falling back to the fully generic
        # text here discarded a better, type-specific value -- and
        # confirmed via debug dump that checking for an EMPTY field
        # alone was too narrow: for some clause types, analyze_clause()'s
        # own first safety net already filled the field with the fully
        # generic text (rather than leaving it empty) before this second
        # safety net ever ran, so the "is it empty" check never
        # triggered and a better, type-specific value was never
        # attempted. This now also retries recomputation whenever the
        # current value exactly matches the known generic fallback text,
        # in addition to when it's empty. Both fields are handled in the
        # same pass, reusing a single get_reasoning_for_text() call per
        # clause rather than calling it twice.
        _recommendation_fallback = {
            "en": "Review this clause for consistency with the overall contract and your specific business context.",
            "fr": "Vérifier que cette clause est cohérente avec l'ensemble du contrat et votre contexte commercial spécifique.",
            "ar": "يُنصح بمراجعة هذا البند للتأكد من اتساقه مع العقد ككل ومع سياق عملك التجاري المحدد.",
        }
        _generic_recommendation_texts = set(_recommendation_fallback.values())

        _legal_insight_fallback = {
            "en": "This clause may affect the parties' rights, obligations, or allocation of risk under the Agreement.",
            "fr": "Cette clause peut affecter les droits, obligations ou la répartition des risques des parties au titre du contrat.",
            "ar": "قد تؤثر هذه المادة على حقوق الأطراف أو التزاماتهم أو توزيع المخاطر بموجب الاتفاقية.",
        }
        _generic_legal_insight_texts = set(_legal_insight_fallback.values())

        for item in results:
            if not isinstance(item, dict):
                continue

            current_recommendation = str(item.get("recommendation") or "").strip()
            current_legal_insight = str(item.get("legal_insight") or "").strip()

            needs_recommendation = (
                not current_recommendation or current_recommendation in _generic_recommendation_texts
            )
            needs_legal_insight = (
                not current_legal_insight or current_legal_insight in _generic_legal_insight_texts
            )

            if not needs_recommendation and not needs_legal_insight:
                continue

            restored_recommendation = ""
            restored_legal_insight = ""
            try:
                clause_text_for_recompute = (
                    item.get("clause_text")
                    or item.get("original_text")
                    or item.get("quoted_text")
                    or ""
                )
                restored = get_reasoning_for_text(
                    clause_text_for_recompute,
                    self.language,
                    title=item.get("clause_title", ""),
                    clause_type=item.get("clause_type"),
                )
                restored_recommendation = str(restored.get("recommendation") or "").strip()
                restored_legal_insight = str(restored.get("legal_insight") or "").strip()
            except Exception:
                restored_recommendation = ""
                restored_legal_insight = ""

            if needs_recommendation:
                if restored_recommendation and restored_recommendation not in _generic_recommendation_texts:
                    item["recommendation"] = restored_recommendation
                elif not current_recommendation:
                    item["recommendation"] = _recommendation_fallback.get(
                        self.language, _recommendation_fallback["en"]
                    )

            if needs_legal_insight:
                if restored_legal_insight and restored_legal_insight not in _generic_legal_insight_texts:
                    item["legal_insight"] = restored_legal_insight
                elif not current_legal_insight:
                    item["legal_insight"] = _legal_insight_fallback.get(
                        self.language, _legal_insight_fallback["en"]
                    )

        # Final cleanup: replace any raw PII-redaction placeholder token
        # (e.g. "[ORGANIZATION]") that leaked verbatim into AI-generated
        # text. Confirmed real bug: the AI was given already-redacted
        # clause text as input and echoed the bracket token it saw
        # (e.g. "at [ORGANIZATION]'s then-current list price") straight
        # into fallback_wording/legal_insight, which reads as broken to
        # an end user even though the underlying redaction was correct
        # for privacy purposes.
        results = [
            clean_pii_placeholder_leakage(item, self.language)
            if isinstance(item, dict) else item
            for item in results
        ]

        contract_timeline = extract_contract_timeline(
            results,
            language=self.language,
        )

        if ENABLE_DEPENDENCY_GRAPH:
            dependency_graph = build_clause_dependency_graph(
                results, self.language
            )
        else:
            dependency_graph = {
                "nodes": [],
                "edges": [],
            }

        if ENABLE_LEGAL_RELATION_GRAPH:
            legal_relation_graph = build_legal_relation_graph(results, self.language)
        else:
            legal_relation_graph = {
                "nodes": [],
                "edges": [],
            }

        try:
            clause_groups = build_clause_groups(
                results,
                self.language,
                party_roles=self.party_roles,
            )
        except TypeError:
            clause_groups = build_clause_groups(results, self.language)

        clause_groups = normalize_ai_role_words(
            clause_groups,
            self.party_roles or {},
            self.language,
        )

        contradictions = detect_contract_contradictions(results, self.language)

        executive_summary = build_executive_summary(
            results,
            dependency_graph,
            self.language,
            contract_text="\n\n".join(self.clauses),
        )
        try:
            executive_risk_narrative = build_executive_risk_narrative(
                executive_summary,
                self.language,
                dependency_graph,
            )
        except TypeError:
            executive_risk_narrative = build_executive_risk_narrative(
                executive_summary,
                self.language,
            )

        executive_risk_narrative = normalize_ai_role_words(
            executive_risk_narrative,
            self.party_roles or {},
            self.language,
        )

        final_result = {
            "clauses": {
                "results": results,
            },
            "contract_timeline": contract_timeline,
            "dependency_graph": dependency_graph,
            "legal_relation_graph": legal_relation_graph,
            "clause_groups": clause_groups,
            "executive_summary": executive_summary,
            "executive_risk_narrative": executive_risk_narrative,
            "contradictions": contradictions,
            "total_clauses_detected": total_clauses_detected,
            "clauses_analyzed": len(results),
            "clauses_truncated": clauses_truncated,
        }
        final_result = normalize_ai_role_words(
            final_result,
            self.party_roles or {},
            self.language,
        )

        final_result = enforce_party_registry_on_clause_output(
            final_result,
            self.party_roles or {},
            self.language,
            "",
        )

        final_result["executive_report"] = build_executive_report(
            final_result,
            self.language,
        )
       

        final_result = normalize_ai_role_words(
            final_result,
            self.party_roles or {},
            self.language,
        )
        


        return final_result


def analyze_contract_clauses(
    clauses: list[str],
    language: str = "en",
    max_clauses: int = 60,
    party_roles: dict | None = None,
) -> dict:
    return ClauseAnalysisPipeline(
        clauses=clauses,
        language=language,
        max_clauses=max_clauses,
        party_roles=party_roles,
    ).run()
