import logging

"""
unified_report_from_pipeline.py

CORRECTED architecture for Point 1 (Remove Redundancy).

Earlier draft mistake: generate_unified_report() sent the full contract
text to the AI a SECOND time (after ClauseAnalysisPipeline.run() had
already AI-analyzed every clause once). That's not deduplication — it's a
third redundant narrative-generation path alongside executive_summary /
executive_risk_narrative / executive_report, which are already computed
for free from clause_results inside contract_agent.py.

Correct architecture:
    - key_clauses, risks_identified, negotiation_priorities,
      suggested_wording, action_checklist, risk_score, contract_overview
      are AGGREGATED in pure Python from clause_results. Zero extra AI
      calls — this data already exists.
    - Only missing_clauses and confidence_notes need a NEW, SMALL AI call,
      because "a clause that isn't there" cannot be produced by analyzing
      clauses that ARE there. This is the one genuinely irreducible gap.
    - definitions_extractor / contract_family_detector / arbitration_analyzer
      still run once, rule-based, to inform BOTH the aggregation (family-
      aware missing-clause expectations) and the small AI call.

This replaces generate_unified_report() from the earlier
unified_summary_service.py draft. to_legacy_summary_data() /
to_legacy_simplified_string() are unchanged and still work on the output
of this function, since the top-level schema is identical.
"""

from app.utils.prompt_loader import load_prompt
from app.services.contract_agent.ai_client import call_json_ai
from app.services.contract_agent.definitions_extractor import (
    extract_definitions,
    build_definitions_block,
)
from app.services.contract_agent.contract_family_detector import (
    detect_contract_family,
    build_family_hint,
)
from app.services.contract_agent.arbitration_analyzer import (
    analyze_arbitration,
    build_arbitration_hint,
)

logger = logging.getLogger(__name__)

RISK_LEVEL_EXPOSURE = {
    "low": "low",
    "medium": "medium",
    "high": "high",
}

URGENCY_BY_PRIORITY = {
    "high": "immediate",
    "medium": "before_signing",
    "low": "monitor",
}

SUPPORTED_LANGUAGES = {"en", "fr", "ar"}

NEGOTIABILITY_VALUES = {
    "yes",
    "limited",
    "usually",
    "jurisdiction_dependent",
    "no",
}

EXPOSURE_DIMENSIONS = [
    "financial",
    "operational",
    "legal",
    "regulatory",
    "compliance",
    "privacy",
    "tax",
    "employment",
    "ip",
    "reputation",
    "cybersecurity",
]

FAMILY_OPTIONAL_FIELDS = {
    "NDA": {"payment_terms"},
    "Confidentiality": {"payment_terms"},
    "Power of Attorney": {"payment_terms"},
    "Corporate Resolution": {"payment_terms", "duration"},
    "IP Assignment": {"payment_terms"},
    "Settlement": set(),
    "General": set(),

    # International document families where payment terms are often absent
    # or not expected. This avoids false validation pressure.
    "Policy": {"payment_terms"},
    "Terms of Use": {"payment_terms"},
    "Privacy Policy": {"payment_terms"},
    "Bylaws": {"payment_terms"},
    "Minutes": {"payment_terms", "duration"},
    "Shareholder Resolution": {"payment_terms", "duration"},
    "Memorandum": {"payment_terms"},
    "Board Resolution": {"payment_terms", "duration"},
    "Corporate Policy": {"payment_terms"},
    "Data Processing Addendum": {"payment_terms"},
}

def normalize_family_name_for_optional_fields(value: str) -> str:
    return (
        str(value or "")
        .lower()
        .strip()
        .replace("-", "_")
        .replace("/", "_")
        .replace(" ", "_")
    )


NORMALIZED_FAMILY_OPTIONAL_FIELDS = {
    normalize_family_name_for_optional_fields(family): fields
    for family, fields in FAMILY_OPTIONAL_FIELDS.items()
}



def normalize_language(language: str) -> str:
    language = str(language or "en").lower().strip()
    return language if language in SUPPORTED_LANGUAGES else "en"


def safe_get_text(*values) -> str:
    return " ".join(str(v or "") for v in values).strip()


def infer_exposure_dimensions(clause: dict, risk_level: str) -> dict:
    text = safe_get_text(
        clause.get("clause_type"),
        clause.get("title"),
        clause.get("clause_title"),
        clause.get("legal_insight"),
        clause.get("explanation_simple"),
        clause.get("quoted_text"),
        clause.get("original_text"),
    ).lower()

    exposure = {dimension: "low" for dimension in EXPOSURE_DIMENSIONS}

    base = RISK_LEVEL_EXPOSURE.get(risk_level, "low")

    if risk_level in {"medium", "high"}:
        exposure["legal"] = base
        exposure["operational"] = base

    if any(k in text for k in ["payment", "fees", "price", "rent", "salary", "invoice", "paiement", "loyer", "فاتورة", "الدفع"]):
        exposure["financial"] = base

    if any(k in text for k in ["liability", "indemn", "damages", "responsabilité", "indemnisation", "مسؤولية", "تعويض"]):
        exposure["financial"] = base
        exposure["legal"] = base

    if any(k in text for k in ["data", "privacy", "security incident", "personal data", "données", "vie privée", "البيانات", "الخصوصية"]):
        exposure["privacy"] = base
        exposure["cybersecurity"] = base
        exposure["regulatory"] = base
        exposure["compliance"] = base

    if any(k in text for k in ["intellectual property", "copyright", "license", "licence", "propriété intellectuelle", "الملكية الفكرية"]):
        exposure["ip"] = base
        exposure["legal"] = base

    if any(k in text for k in ["tax", "withholding", "vat", "tva", "impôt", "ضريبة"]):
        exposure["tax"] = base
        exposure["financial"] = base

    if any(k in text for k in ["employment", "employee", "employer", "salary", "emploi", "salarié", "employeur", "موظف", "صاحب العمل"]):
        exposure["employment"] = base

    if any(k in text for k in ["public", "reputation", "brand", "media", "réputation", "سمعة"]):
        exposure["reputation"] = base

    return exposure


def infer_negotiability(clause: dict) -> str:
    text = safe_get_text(
        clause.get("clause_type"),
        clause.get("title"),
        clause.get("clause_title"),
        clause.get("legal_insight"),
        clause.get("quoted_text"),
        clause.get("original_text"),
    ).lower()

    if any(k in text for k in ["mandatory law", "public procurement", "consumer law", "sanctions", "anti-bribery", "gdpr", "droit impératif", "marché public", "قانون إلزامي", "العقوبات"]):
        return "limited"

    if any(k in text for k in ["governing law", "jurisdiction", "arbitration", "droit applicable", "juridiction", "تحكيم", "اختصاص"]):
        return "usually"

    if any(k in text for k in ["tax", "employment law", "labor law", "data protection", "consumer", "ضريبة", "حماية البيانات", "قانون العمل"]):
        return "jurisdiction_dependent"

    return "yes"


def infer_market_practice(clause: dict) -> str:
    market_comparison_text = str(clause.get("market_comparison") or "").lower()

    if "aggressive" in market_comparison_text:
        return "market_aggressive"

    if "unusual" in market_comparison_text or "uncommon" in market_comparison_text:
        return "market_uncommon"

    if "favorable" in market_comparison_text or "favours" in market_comparison_text:
        return "market_favorable"

    if "standard" in market_comparison_text:
        return "market_standard"

    if str(clause.get("favours", "")).lower() == "balanced":
        return "market_standard"

    return "market_unknown"


def infer_action_category(clause: dict) -> str:
    text = safe_get_text(
        clause.get("clause_type"),
        clause.get("title"),
        clause.get("clause_title"),
        clause.get("recommendation"),
    ).lower()

    if any(k in text for k in ["payment", "fee", "invoice", "rent", "paiement", "facture", "الدفع"]):
        return "commercial"

    if any(k in text for k in ["data", "privacy", "security", "données", "البيانات"]):
        return "data_compliance"

    if any(k in text for k in ["liability", "indemn", "insurance", "responsabilité", "تأمين", "مسؤولية"]):
        return "risk_allocation"

    if any(k in text for k in ["termination", "renewal", "notice", "résiliation", "إشعار", "فسخ"]):
        return "contract_lifecycle"

    if any(k in text for k in ["ip", "intellectual property", "license", "propriété intellectuelle", "الملكية الفكرية"]):
        return "ip_rights"

    return "legal_review"


def infer_action_owner(clause: dict) -> str:
    category = infer_action_category(clause)

    owners = {
        "commercial": "Commercial / Finance",
        "data_compliance": "Legal / Security / Privacy",
        "risk_allocation": "Legal / Risk",
        "contract_lifecycle": "Legal / Operations",
        "ip_rights": "Legal / Product",
        "legal_review": "Legal",
    }

    return owners.get(category, "Legal")


def infer_action_deadline(urgency: str) -> str:
    if urgency == "immediate":
        return "before_signature"
    if urgency == "before_signing":
        return "before_signature"
    return "post_signature_monitoring"




def _get_clause_list(pipeline_result: dict) -> list:
    """
    clause_results from contract_handler.py is the FULL pipeline dict
    (final_result), not a flat list. The actual per-clause analyses live
    at clause_results["clauses"]["results"].
    """
    clauses_block = pipeline_result.get("clauses", {})
    if isinstance(clauses_block, dict):
        return clauses_block.get("results", [])
    if isinstance(clauses_block, list):
        return clauses_block
    return []


def _clause_id(clause: dict, index: int) -> str:
    # Prefer the structural id already attached by attach_clause_object_metadata,
    # fall back to a positional id so every clause is addressable.
    return str(clause.get("clause_id") or f"kc_{index+1}")


def build_contract_overview(
    pipeline_result: dict,
    family_detection: dict,
    contract_text: str = "",
    party_roles: dict | None = None,
) -> dict:
    """
    Defensive, family-aware overview.

    Fields remain stable for legacy compatibility, but values may be
    "Not specified" where that field is not expected for the detected
    contract family.
    """
    exec_summary = pipeline_result.get("executive_summary", {}) or {}
    exec_report = pipeline_result.get("executive_report", {}) or {}
    overview = exec_report.get("contract_overview", {}) or {}

    family = family_detection.get("family", "General")
    optional_fields = FAMILY_OPTIONAL_FIELDS.get(family, set())

    if not optional_fields:
        optional_fields = NORMALIZED_FAMILY_OPTIONAL_FIELDS.get(
            normalize_family_name_for_optional_fields(family),
            set(),
        )

    payment_terms = exec_summary.get("payment_terms")
    duration = exec_summary.get("duration")

    if "payment_terms" in optional_fields and not payment_terms:
        payment_terms = "Not applicable / not specified"

    if "duration" in optional_fields and not duration:
        duration = "Not applicable / not specified"

    # analyze_arbitration() returns None (rather than an empty dict) when
    # no arbitration clause is found in the contract -- a perfectly
    # normal, common case for many contract types across the supported
    # sectors (real estate leases, employment agreements, NDAs, and many
    # sale/purchase agreements rely on court jurisdiction or specify
    # nothing at all, with no arbitration clause whatsoever). Without
    # this guard, any contract without arbitration language crashes the
    # whole report instead of just reporting "Not specified".
    arbitration_facts = analyze_arbitration(contract_text or "") or {}

    jurisdiction_detected = (
        exec_summary.get("jurisdiction_detected")
        or arbitration_facts.get("seat")
        or arbitration_facts.get("place")
        or arbitration_facts.get("country")
        or "Not specified"
    )

    # exec_summary (built by executive_summary.py's build_executive_summary())
    # never populates a "parties" field at all -- confirmed by reading
    # that module directly, it has no such key in its return value. This
    # made "parties" fall back to a bare, uninformative ["Not specified"]
    # on every single contract, regardless of family or content.
    # party_roles is already reliably computed once per document (in
    # contract_handler.py, via get_display_roles()) with sensible,
    # family-aware labels ("Employer"/"Employee" for an employment
    # contract, "Client"/"Service Provider" for a services contract,
    # etc.) and is already used consistently elsewhere in the same
    # report -- using it here too, as a fallback, gives a genuinely
    # informative parties list instead of a placeholder, and keeps this
    # field consistent with how the rest of the report already refers to
    # the parties. Falls back to the previous behavior if party_roles is
    # not provided or is itself empty (never fabricates a value the
    # rest of the pipeline could not determine).
    parties = exec_summary.get("parties")

    # Normalize to a list FIRST, before any placeholder checking. Some
    # upstream sources (LLM responses in particular) inconsistently
    # return a bare string instead of a list for this field -- without
    # this normalization, "for p in parties" would silently iterate over
    # individual CHARACTERS of the string rather than treating it as one
    # item, making the placeholder-only check below always evaluate to
    # False and silently defeating the fallback entirely. Confirmed as
    # the actual real-world case.
    if isinstance(parties, str):
        parties = [parties] if parties.strip() else []
    elif not isinstance(parties, list):
        parties = []

    # A non-empty list is truthy in Python regardless of its CONTENT --
    # ["Not specified"] passes "if not parties" just as easily as a real
    # party list does, since Python only checks emptiness, not whether
    # the content is itself placeholder text. Confirmed as an actual
    # real-world case: some upstream source populates "parties" with the
    # literal placeholder string itself (not None/missing), which
    # silently defeated the fallback below. Treating an
    # all-placeholder-text list the same as an empty one, in any of the
    # three supported languages, ensures the fallback actually fires.
    _placeholder_party_values = {
        "not specified", "non spécifié", "non specifie", "غير محدد",
    }

    parties_is_placeholder_only = bool(parties) and all(
        str(p).strip().lower() in _placeholder_party_values
        for p in parties
    )

    if (
        (not parties or parties_is_placeholder_only)
        and isinstance(party_roles, dict)
    ):
        role_parties = [
            str(party_roles[key])
            for key in ("party_a", "party_b")
            if party_roles.get(key)
        ]

        if role_parties:
            parties = role_parties

    return {
        "contract_type": family,
        "parties": parties or ["Not specified"],
        "duration": duration or "Not specified",
        "payment_terms": payment_terms or "Not specified",
        "jurisdiction_detected": jurisdiction_detected,
        "jurisdiction_note": exec_summary.get("jurisdiction_note", ""),
        "contract_complexity": exec_summary.get("contract_complexity", "medium"),
        "overall_balance": exec_summary.get("overall_balance", "Not specified"),
        "family_hint": build_family_hint(family_detection),
        "_clauses_analyzed": overview.get("clauses_analyzed"),
    }



def build_key_clauses(clauses: list) -> list:
    key_clauses = []

    for i, clause in enumerate(clauses):
        why = (
            clause.get("business_impact")
            or clause.get("commercial_impact")
            or clause.get("operational_impact")
            or clause.get("risk_reason")
            or clause.get("legal_insight")
            or clause.get("explanation_simple")
            or clause.get("why_it_matters")
            or ""
        )

        if not why:
            continue

        key_clauses.append({
            "id": _clause_id(clause, i),
            "clause_type": clause.get("clause_type", "other"),
            "title": clause.get("clause_title") or clause.get("title", ""),
            "why_it_matters": why,
            "risk_level": clause.get("risk_level", "low"),
        })

    return key_clauses



def build_risks_identified(clauses: list) -> list:
    risks = []

    for i, clause in enumerate(clauses):
        risk_level = clause.get("risk_level", "low")

        if risk_level == "low" and not clause.get("red_flag"):
            continue

        explanation = (
            clause.get("business_impact")
            or clause.get("commercial_impact")
            or clause.get("operational_impact")
            or clause.get("risk_reason")
            or clause.get("legal_insight")
            or clause.get("explanation_simple")
            or ""
        )

        if not explanation:
            continue

        market_practice = infer_market_practice(clause)
        exposure = infer_exposure_dimensions(clause, risk_level)

        risks.append({
            "id": f"risk_{_clause_id(clause, i)}",
            "clause_ref": _clause_id(clause, i),
            "risk_level": risk_level,
            "market_practice": market_practice,
            "market_practice_score": clause.get("market_practice_score"),
            "exposure": exposure,
            "explanation": explanation,
            "red_flag": bool(clause.get("red_flag")),
        })

    return risks



def build_negotiation_priorities(clauses: list) -> list:
    priorities = []

    for i, clause in enumerate(clauses):
        priority = clause.get("negotiation_priority", "low")
        advice = clause.get("negotiation_advice", "")

        if priority == "low" or not advice:
            continue

        negotiability = infer_negotiability(clause)

        priorities.append({
            "risk_ref": f"risk_{_clause_id(clause, i)}",
            "priority": priority,
            "negotiable": negotiability,
            "what_should_change": advice,
            "commercial_objective": clause.get("commercial_objective", ""),
            "acceptable_compromise": clause.get("acceptable_compromise", ""),
            "never_accept": clause.get("never_accept", ""),
        })

    return priorities



def build_suggested_wording(clauses: list) -> list:
    wording = []
    for i, clause in enumerate(clauses):
        alt = clause.get("safer_alternative", "")
        if not alt:
            continue
        wording.append({
            "risk_ref": f"risk_{_clause_id(clause, i)}",
            "preferred_wording": alt,
            "fallback_wording": "",     # not currently distinguished from preferred — see confidence_notes
            "negotiation_alternative": clause.get("negotiation_advice", ""),
        })
    return wording


def build_action_checklist(clauses: list) -> list:
    actions = []

    for clause in clauses:
        action = ""
        urgency = "monitor"

        if clause.get("red_flag") and clause.get("red_flag_reason"):
            action = clause["red_flag_reason"]
            urgency = "immediate"

        elif clause.get("negotiation_priority") in {"high", "medium"} and clause.get("recommendation"):
            action = clause["recommendation"]
            urgency = URGENCY_BY_PRIORITY.get(
                clause["negotiation_priority"],
                "monitor",
            )

        if not action:
            continue

        actions.append({
            "action": action,
            "urgency": urgency,
            "owner": infer_action_owner(clause),
            "deadline": infer_action_deadline(urgency),
            "category": infer_action_category(clause),
            "clause_ref": clause.get("clause_id", ""),
        })

    return actions


RISK_SCORE_POINTS = {
    "low": 0,
    "medium": 8,
    "high": 20,
}

MATERIALITY_SCORE_POINTS = {
    "low": 8,
    "medium": 16,
    "high": 24,
}


def build_risk_score_top_factors(
    clauses: list,
    language: str = "en",
    top_n: int = 4,
) -> list:
    if not clauses:
        return []

    total_materiality_points = sum(
        MATERIALITY_SCORE_POINTS.get(
            str(c.get("materiality_level", "medium")).lower(),
            16,
        )
        for c in clauses
    )

    if total_materiality_points <= 0:
        return []

    factors = []

    for clause in clauses:
        risk_level = str(clause.get("risk_level", "low")).lower()
        risk_points = RISK_SCORE_POINTS.get(risk_level, 0)

        if risk_points <= 0:
            continue

        contribution = round((risk_points / total_materiality_points) * 100)

        if contribution <= 0:
            continue

        title = (
            clause.get("display_title")
            or clause.get("localized_title")
            or clause.get("clause_title")
            or clause.get("title")
            or clause.get("clause_type")
            or {
                "en": "Untitled clause",
                "fr": "Clause sans titre",
                "ar": "بند بدون عنوان",
            }.get(language, "Untitled clause")
        )

        factors.append({
            "factor": title,
            "contribution": contribution,
            "risk_level": risk_level,
        })

    factors.sort(key=lambda item: item["contribution"], reverse=True)

    return factors[:top_n]



def build_risk_score(pipeline_result: dict, risks: list) -> dict:
    clauses = _get_clause_list(pipeline_result)

    scores = [
        c.get("normalized_contract_score")
        for c in clauses
        if c.get("normalized_contract_score") is not None
    ]

    value = scores[0] if scores else 0

    language = normalize_language(
        pipeline_result.get("language", "en")
    )

    high_titles = [
        (
            c.get("display_title")
            or c.get("localized_title")
            or c.get("clause_title")
            or c.get("title")
            or c.get("clause_type")
        )
        for c in clauses
        if str(c.get("risk_level", "")).lower() == "high"
    ]

    high_titles = [t for t in high_titles if t][:3]

    medium_count = sum(
        1
        for c in clauses
        if str(c.get("risk_level", "")).lower() == "medium"
    )

    low_count = sum(
        1
        for c in clauses
        if str(c.get("risk_level", "")).lower() == "low"
    )

    if language == "fr":
        if high_titles:
            explanation = (
                f"Le score est principalement influencé par "
                f"{len(high_titles)} clause(s) à risque élevé : "
                f"{', '.join(high_titles)}."
            )
            if medium_count:
                explanation += (
                    f" {medium_count} clause(s) à risque moyen "
                    f"contribuent également au score."
                )
        elif medium_count:
            explanation = (
                f"Le score est principalement influencé par "
                f"{medium_count} clause(s) à risque moyen."
            )
        else:
            explanation = "Aucun risque significatif n'a été détecté."
    elif language == "ar":
        if high_titles:
            explanation = (
                f"تعتمد النتيجة بشكل أساسي على "
                f"{len(high_titles)} بند عالي المخاطر: "
                f"{'، '.join(high_titles)}."
            )
            if medium_count:
                explanation += (
                    f" كما ساهم {medium_count} بند متوسط المخاطر "
                    f"في احتساب النتيجة."
                )
        elif medium_count:
            explanation = (
                f"تعتمد النتيجة بشكل أساسي على "
                f"{medium_count} بند متوسط المخاطر."
            )
        else:
            explanation = "لم يتم اكتشاف مخاطر جوهرية."
    else:
        if high_titles:
            explanation = (
                f"The score is mainly influenced by "
                f"{len(high_titles)} high-risk clause(s): "
                f"{', '.join(high_titles)}."
            )
            if medium_count:
                explanation += (
                    f" {medium_count} medium-risk clause(s) "
                    f"also contributed."
                )
        elif medium_count:
            explanation = (
                f"The score is mainly influenced by "
                f"{medium_count} medium-risk clause(s)."
            )
        else:
            explanation = "No material risks detected in analyzed clauses."

    top_factors = build_risk_score_top_factors(
        clauses,
        language=language,
        top_n=4,
    )

    return {
        "value": value,
        "explanation": explanation,
        "top_factors": top_factors,
        "improves_if": (
            "Resolving the high-risk clauses listed above would reduce the risk score."
            if high_titles else
            "No specific high-risk clause identified."
        ),
        "high_count": len(high_titles),
        "medium_count": medium_count,
        "low_count": low_count,
        "critical_clauses": high_titles,
        "confidence": "high" if clauses else "low",
        "coverage": round(len(clauses) / max(len(clauses), 1), 2),
        "missing_clause_penalty": 0,
    }




def build_unified_report_from_pipeline(
    pipeline_result: dict,
    contract_text: str,
    language: str = "en",
    party_roles: dict | None = None,
) -> dict:
    language = normalize_language(language)
    """
    Main entrypoint. Aggregates 90% of the 7-section report from
    clause_results with ZERO extra AI calls, then makes ONE small AI call
    for the only genuinely irreducible gap: missing_clauses + confidence_notes.
    """
    clauses = _get_clause_list(pipeline_result)
    family_detection = detect_contract_family(contract_text)

    key_clauses = build_key_clauses(clauses)
    risks = build_risks_identified(clauses)
    negotiation_priorities = build_negotiation_priorities(clauses)
    suggested_wording = build_suggested_wording(clauses)
    action_checklist = build_action_checklist(clauses)
    risk_score = build_risk_score(pipeline_result, risks)
    contract_overview = build_contract_overview(
        pipeline_result,
        family_detection,
        contract_text,
        party_roles,
    )

    executive_summary_text = (
        pipeline_result.get("executive_risk_narrative")
        or pipeline_result.get("executive_report", {}).get("executive_narrative", "")
        or ""
    )

    missing_clauses, confidence_notes, fallback_position = _generate_missing_clauses_and_notes(
        contract_text, family_detection, clauses, language,
    )

    return {
        "contract_family": family_detection.get("family", "General"),
        "contract_overview": contract_overview,
        "executive_summary": executive_summary_text,
        "key_clauses": key_clauses,
        "risks_identified": risks,
        "negotiation_priorities": negotiation_priorities,
        "suggested_wording": suggested_wording,
        "fallback_position": fallback_position,
        "action_checklist": action_checklist,
        "risk_score": risk_score,
        "missing_clauses": missing_clauses,
        "confidence_notes": confidence_notes,
    }


# ---------------------------------------------------------------------
# The ONE small AI call this architecture still needs.
# ---------------------------------------------------------------------

MISSING_CLAUSES_PROMPT = """
ROLE: You identify ONLY genuinely absent, family-relevant clauses in a
contract. You do not summarize, re-analyze, or comment on clauses that
are present — that has already been done.

The clause types ALREADY DETECTED in this contract are:
{detected_types}

The contract family is: {family}

TASK: Return JSON with exactly these keys:
{{
  "missing_clauses": [
    {{
      "clause_type": string,
      "why_missing": string,
      "risk_if_missing": string,
      "business_reason": string,
      "market_practice": "market_standard | market_favorable | market_uncommon | market_unknown",
      "priority": "high | medium | low",
      "recommended_wording": string,
      "jurisdiction_note": string
    }}
  ],
  "confidence_notes": [string],
  "fallback_position": string
}}

RULES:
- Only list a clause as missing if it is genuinely expected for a "{family}"
  contract AND its absence creates measurable legal, financial, regulatory,
  operational, IP, privacy, tax, employment, cybersecurity, or business risk.
- Never list optional or uncommon clauses as missing merely because they
  are useful in some contracts.
- business_reason must be specific to THIS contract family, never generic.
- risk_if_missing must explain what could realistically go wrong.
- market_practice must reflect international commercial practice, not one
  jurisdiction unless the contract expressly states that jurisdiction.
- recommended_wording must be concise and practical, not a full clause.
- jurisdiction_note must mention uncertainty where enforceability depends
  on local mandatory law.
- confidence_notes: list anything you are uncertain about, including missing
  schedules, annexes, incomplete arbitration mechanics, undefined terms, or
  incomplete context.
- fallback_position: ONE paragraph — if negotiation fails, what is the
  minimum acceptable position given what's present and absent.
- Never invent clauses that ARE present under a different name — check
  the detected list above first.
- PRIVACY-FIRST: Never reconstruct, infer, restore, request, or output real names, emails, addresses, phone numbers, identifiers, account numbers, or personal data.
- Preserve anonymized placeholders exactly as received, including [PERSON], [ORGANIZATION], [PARTY_1], [PARTY_2], [PARTY_3], [CLIENT], [SERVICE_PROVIDER], and equivalent placeholders.

{definitions_block}

{arbitration_hint}

Contract text:
{contract_text}
""".strip()



def _generate_missing_clauses_and_notes(
    contract_text: str, family_detection: dict, clauses: list, language: str,
) -> tuple[list, list, str]:
    detected_types = sorted({c.get("clause_type", "other") for c in clauses})
    definitions = extract_definitions(contract_text)
    arbitration_facts = analyze_arbitration(contract_text) or {}

    prompt = MISSING_CLAUSES_PROMPT.format(
        detected_types=", ".join(detected_types) or "none detected",
        family=family_detection.get("family", "General"),
        definitions_block=build_definitions_block(definitions),
        arbitration_hint=build_arbitration_hint(arbitration_facts),
        contract_text=contract_text[:14000],
    )
    prompt += (
        f"\n\nOutput language: {language}. Translate all generated text into {language}."
        "\nPrivacy-first: preserve anonymized placeholders exactly and never output personal data."
    )

    try:
        data = call_json_ai(prompt, temperature=0.0)
    except Exception as e:
        logger.exception("Missing clauses AI error: %s", e)
        return [], ["Could not generate missing-clause analysis."], ""

    missing = [
        m for m in data.get("missing_clauses", [])
        if isinstance(m, dict) and m.get("business_reason", "").strip()
    ]
    return missing, data.get("confidence_notes", []), data.get("fallback_position", "")