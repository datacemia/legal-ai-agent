from __future__ import annotations

from copy import deepcopy
from typing import Any

from app.services.contract_agent.contract_taxonomy import (
    get_clause_type_description,
)

from app.services.contract_agent.jurisdiction_profiles import (
    detect_jurisdiction,
    summarize_jurisdiction_detection,
)


SUPPORTED_LANGUAGES = {"en", "fr", "ar"}

RISK_NORMALIZATION = {
    "critical": "high",
    "very_high": "high",
    "high": "high",
    "medium": "medium",
    "moderate": "medium",
    "low": "low",
    "none": "low",
    "informational": "low",
}


def safe_str(value: Any) -> str:
    return str(value or "").strip()


def safe_list(value: Any) -> list:
    return value if isinstance(value, list) else []


def clause_title(clause: dict) -> str:
    return (
        safe_str(clause.get("clause_title"))
        or safe_str(clause.get("title"))
        or safe_str(clause.get("name"))
        or "Untitled clause"
    )


def normalize_risk_level(level: Any) -> str:
    return RISK_NORMALIZATION.get(
        safe_str(level).lower(),
        "low",
    )


def risk_rank(level: Any) -> int:
    return {
        "high": 3,
        "medium": 2,
        "low": 1,
    }.get(
        normalize_risk_level(level),
        0,
    )


def dependency_edges_count(
    dependency_graph: dict | None = None,
) -> int:
    graph = dependency_graph or {}

    edges = graph.get("edges")

    if isinstance(edges, list):
        return len(edges)

    try:
        return int(graph.get("edges_count", 0) or 0)
    except (TypeError, ValueError):
        return 0


def build_executive_summary(
    clauses: list[dict],
    dependency_graph: dict | None = None,
    language: str = "en",
    contract_text: str = "",
) -> dict:
    """
    International, privacy-first executive summary.

    - Works for any contract family and industry.
    - EN / FR / AR compatible.
    - Never reconstructs or infers personal data.
    - Does not mutate input clauses.
    - Uses the final dependency graph as the single dependency-count source.
    """

    language = language if language in SUPPORTED_LANGUAGES else "en"
    dependency_graph = dependency_graph or {}

    normalized = []

    for c in safe_list(clauses):
        if not isinstance(c, dict):
            continue

        item = deepcopy(c)
        item["_normalized_risk_level"] = normalize_risk_level(
            item.get("risk_level")
        )

        normalized.append(item)

    high = [
        c for c in normalized
        if c["_normalized_risk_level"] == "high"
    ]

    medium = [
        c for c in normalized
        if c["_normalized_risk_level"] == "medium"
    ]

    low = [
        c for c in normalized
        if c["_normalized_risk_level"] == "low"
    ]

    ranked = sorted(
        [
            c for c in normalized
            if c["_normalized_risk_level"] in {"high", "medium"}
        ],
        key=lambda c: (
            risk_rank(c["_normalized_risk_level"]),
            c.get("importance_score") or 0,
        ),
        reverse=True,
    )[:5]

    negotiation = sorted(
        [
            c for c in normalized
            if any(
                c.get(k)
                for k in (
                    "recommendation",
                    "negotiation_advice",
                    "safer_alternative",
                    "fallback_position",
                )
            )
        ],
        key=lambda c: (
            risk_rank(c["_normalized_risk_level"]),
            c.get("importance_score") or 0,
        ),
        reverse=True,
    )[:5]

    actions = []

    for c in negotiation:
        action = (
            safe_str(c.get("recommendation"))
            or safe_str(c.get("negotiation_advice"))
            or safe_str(c.get("safer_alternative"))
            or safe_str(c.get("fallback_position"))
        )

        if action:
            actions.append({
                "title": clause_title(c),
                "risk_level": c["_normalized_risk_level"],
                "action": action,
            })

    edges = safe_list(
        dependency_graph.get("edges")
    )

    final_edges_count = dependency_edges_count(
        dependency_graph
    )

    jurisdiction_detection = (
        detect_jurisdiction(contract_text, language)
        if contract_text
        else {}
    )

    jurisdiction_summary = (
        summarize_jurisdiction_detection(
            jurisdiction_detection,
            language,
        )
        if jurisdiction_detection
        else ""
    )

    return {
        "language": language,
        "privacy_first": True,
        "jurisdiction": jurisdiction_detection,
        "jurisdiction_summary": jurisdiction_summary,
        "risk_overview": {
            "high": len(high),
            "medium": len(medium),
            "low": len(low),
        },
        "top_risks": [
            {
                "title": clause_title(c),
                "risk_level": c["_normalized_risk_level"],
                "importance_score": c.get("importance_score"),
                "legal_insight": (
                    get_clause_type_description(
                        c.get("clause_type"),
                        language,
                    )
                    or (
                        get_clause_type_description(
                            "limitation_of_liability_exceptions",
                            language,
                        )
                        if clause_title(c).lower() == "limitation of liability exceptions"
                        else ""
                    )
                    or c.get("legal_insight")
                    or c.get("explanation_simple")
                ),
            }
            for c in ranked
        ],
        "negotiation_priorities": [
            {
                "title": clause_title(c),
                "risk_level": c["_normalized_risk_level"],
                "recommendation": c.get("recommendation"),
                "negotiation_advice": c.get("negotiation_advice"),
                "safer_alternative": c.get("safer_alternative"),
                "fallback_position": c.get("fallback_position"),
            }
            for c in negotiation
        ],
        "recommended_actions": actions,
        "dependency_summary": {
            "edges_count": final_edges_count,
            "key_dependencies": edges[:5],
        },
    }
