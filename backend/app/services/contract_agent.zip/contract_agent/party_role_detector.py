"""
party_role_detector.py

Privacy-first party role display helper.

Purpose:
- Provide optional display labels for anonymized party placeholders.
- Support EN / FR / AR.
- Support international contract families.
- Avoid breaking the core privacy objective:
  real party identities must not be reconstructed, inferred, or injected.

Important rule:
- apply_display_roles() performs replacements ONLY when roles are explicitly
  confirmed anonymized via roles["anonymized"] is True.
- get_display_roles() returns suggested roles for UI/helper usage, but they
  are not applied unless marked anonymized.
"""


import re


SUPPORTED_LANGUAGES = {"en", "fr", "ar"}


ROLE_LABELS = {
    "generic": {
        "en": ("Party A", "Party B"),
        "fr": ("Partie A", "Partie B"),
        "ar": ("الطرف أ", "الطرف ب"),
    },
    "employment": {
        "en": ("Employer", "Employee"),
        "fr": ("Employeur", "Salarié"),
        "ar": ("صاحب العمل", "الموظف"),
    },
    "services": {
        "en": ("Client", "Service Provider"),
        "fr": ("Client", "Prestataire"),
        "ar": ("العميل", "مقدم الخدمة"),
    },
    "sale": {
        "en": ("Buyer", "Seller"),
        "fr": ("Acheteur", "Vendeur"),
        "ar": ("المشتري", "البائع"),
    },
    "lease": {
        "en": ("Lessor", "Lessee"),
        "fr": ("Bailleur", "Locataire"),
        "ar": ("المؤجر", "المستأجر"),
    },
    "loan": {
        "en": ("Lender", "Borrower"),
        "fr": ("Prêteur", "Emprunteur"),
        "ar": ("المقرض", "المقترض"),
    },
    "license": {
        "en": ("Licensor", "Licensee"),
        "fr": ("Concédant", "Licencié"),
        "ar": ("المرخِّص", "المرخَّص له"),
    },
    "nda": {
        "en": ("Disclosing Party", "Receiving Party"),
        "fr": ("Partie divulgatrice", "Partie réceptrice"),
        "ar": ("الطرف المفصح", "الطرف المتلقي"),
    },
    "franchise": {
        "en": ("Franchisor", "Franchisee"),
        "fr": ("Franchiseur", "Franchisé"),
        "ar": ("مانح الامتياز", "صاحب الامتياز"),
    },
    "distribution": {
        "en": ("Supplier", "Distributor"),
        "fr": ("Fournisseur", "Distributeur"),
        "ar": ("المورّد", "الموزع"),
    },
    "insurance": {
        "en": ("Insurer", "Insured"),
        "fr": ("Assureur", "Assuré"),
        "ar": ("المؤمّن", "المؤمّن له"),
    },
    "construction": {
        "en": ("Owner", "Contractor"),
        "fr": ("Maître d’ouvrage", "Entrepreneur"),
        "ar": ("صاحب المشروع", "المقاول"),
    },
    "transport": {
        "en": ("Shipper", "Carrier"),
        "fr": ("Expéditeur", "Transporteur"),
        "ar": ("الشاحن", "الناقل"),
    },
    "data_processing": {
        "en": ("Controller", "Processor"),
        "fr": ("Responsable du traitement", "Sous-traitant"),
        "ar": ("المتحكم بالبيانات", "معالج البيانات"),
    },
    "shareholder": {
        "en": ("Company", "Shareholder"),
        "fr": ("Société", "Actionnaire"),
        "ar": ("الشركة", "المساهم"),
    },
    "agency": {
        "en": ("Principal", "Agent"),
        "fr": ("Mandant", "Mandataire"),
        "ar": ("الموكل", "الوكيل"),
    },
    "escrow": {
        "en": ("Depositor", "Escrow Agent"),
        "fr": ("Déposant", "Agent séquestre"),
        "ar": ("المودع", "وكيل الضمان"),
    },
}


ANONYMIZED_TOKENS = {
    "[PARTY_1]",
    "[PARTY_2]",
    "[PARTY_3]",
    "[PARTY_A]",
    "[PARTY_B]",
    "[CLIENT]",
    "[SERVICE_PROVIDER]",
    "[SUPPLIER]",
    "[VENDOR]",
    "[BUYER]",
    "[SELLER]",
    "[LESSOR]",
    "[LESSEE]",
    "[LANDLORD]",
    "[TENANT]",
    "[LENDER]",
    "[BORROWER]",
    "[LICENSOR]",
    "[LICENSEE]",
    "[EMPLOYER]",
    "[EMPLOYEE]",
    "[CONTROLLER]",
    "[PROCESSOR]",
    "[FRANCHISOR]",
    "[FRANCHISEE]",
    "[DISTRIBUTOR]",
    "[RESELLER]",
    "[INSURER]",
    "[INSURED]",
    "[OWNER]",
    "[CONTRACTOR]",
    "[PRINCIPAL]",
    "[AGENT]",
    "[ORGANIZATION]",
    "[PERSON]",
}


FR_ARTICLE_FIXES = {
    "de le": "du",
    "à le": "au",
    "De le": "Du",
    "À le": "Au",
}


def normalize_language(language: str = "en") -> str:
    language = str(language or "en").lower().strip()
    return language if language in SUPPORTED_LANGUAGES else "en"


def normalize_role_family_key(family: str = "") -> str:
    """Normalize role-family names from different modules into ROLE_LABELS keys."""
    value = str(family or "generic").lower().strip()
    value = value.replace("-", "_").replace(" ", "_").replace("/", "_")

    aliases = {
        "msa": "services",
        "master_services_agreement": "services",
        "master_service_agreement": "services",
        "service_agreement": "services",
        "services_agreement": "services",
        "saas": "services",
        "cloud": "services",
        "cybersecurity": "services",
        "consulting": "services",
        "outsourcing": "services",
        "managed_services": "services",
        "data_processing": "data_processing",
        "dpa": "data_processing",
        "sale_purchase": "sale",
        "sale___purchase": "sale",
        "sale_and_purchase": "sale",
        "procurement": "sale",
        "supply": "sale",
        "real_estate": "lease",
        "finance": "loan",
        "finance_lending": "loan",
        "lending": "loan",
        "licensing": "license",
        "distribution_reseller": "distribution",
        "reseller": "distribution",
        "transportation_logistics": "transport",
        "logistics": "transport",
        "shareholder": "shareholder",
        "investment_shareholder": "shareholder",
        "partnership_jv": "shareholder",
        "nda": "nda",
        "non_disclosure": "nda",
    }

    normalized = aliases.get(value, value)

    if normalized in ROLE_LABELS:
        return normalized

    return "generic"


def contains_anonymized_token(value) -> bool:
    text = str(value or "")
    return any(token in text for token in ANONYMIZED_TOKENS)


def roles_are_anonymized(roles: dict | None) -> bool:
    if not isinstance(roles, dict):
        return False

    if roles.get("anonymized") is True:
        return True

    return (
        contains_anonymized_token(roles.get("party_a"))
        or contains_anonymized_token(roles.get("party_b"))
    )


def strip_role_articles(label: str, language: str = "en") -> str:
    language = normalize_language(language)
    value = str(label or "").strip()

    if language == "fr":
        prefixes = [
            "le ", "la ", "l’", "l'",
            "Le ", "La ", "L’", "L'",
        ]

        for prefix in prefixes:
            if value.startswith(prefix):
                return value[len(prefix):].strip()

    if language == "en":
        prefixes = ["the ", "The "]

        for prefix in prefixes:
            if value.startswith(prefix):
                return value[len(prefix):].strip()

    return value


def _has_all(text: str, terms: list[str]) -> bool:
    return all(term in text for term in terms)


def _has_any(text: str, terms: list[str]) -> bool:
    return any(term in text for term in terms)


def detect_role_family(contract_type: str = "", text: str = "") -> str:
    """
    Detect likely contract family for display suggestions.

    This function does NOT authorize role replacement by itself.
    Replacement is still blocked unless roles["anonymized"] is True.
    """
    combined = f"{contract_type or ''} {text or ''}".lower()
    combined = re.sub(r"\[[a-z_0-9]+\]", " ", combined)

    # Explicit party role pairs first.
    explicit_pairs = [
        ("services", [
            ("service provider", "client"),
            ("provider", "client"),
            ("supplier", "customer"),
            ("prestataire", "client"),
            ("مقدم الخدمة", "العميل"),
        ]),
        ("sale", [
            ("buyer", "seller"),
            ("purchaser", "seller"),
            ("acheteur", "vendeur"),
            ("المشتري", "البائع"),
        ]),
        ("lease", [
            ("lessor", "lessee"),
            ("landlord", "tenant"),
            ("bailleur", "locataire"),
            ("المؤجر", "المستأجر"),
        ]),
        ("loan", [
            ("lender", "borrower"),
            ("prêteur", "emprunteur"),
            ("preteur", "emprunteur"),
            ("المقرض", "المقترض"),
        ]),
        ("license", [
            ("licensor", "licensee"),
            ("concédant", "licencié"),
            ("concedant", "licencie"),
            ("المرخِّص", "المرخَّص له"),
            ("المرخص", "المرخص له"),
        ]),
        ("nda", [
            ("disclosing party", "receiving party"),
            ("partie divulgatrice", "partie réceptrice"),
            ("الطرف المفصح", "الطرف المتلقي"),
        ]),
        ("franchise", [
            ("franchisor", "franchisee"),
            ("franchiseur", "franchisé"),
            ("مانح الامتياز", "صاحب الامتياز"),
        ]),
        ("distribution", [
            ("supplier", "distributor"),
            ("manufacturer", "distributor"),
            ("fournisseur", "distributeur"),
            ("المورّد", "الموزع"),
            ("المورد", "الموزع"),
        ]),
        ("insurance", [
            ("insurer", "insured"),
            ("assureur", "assuré"),
            ("المؤمن", "المؤمن له"),
        ]),
        ("construction", [
            ("owner", "contractor"),
            ("employer", "contractor"),
            ("maître d’ouvrage", "entrepreneur"),
            ("maitre d'ouvrage", "entrepreneur"),
            ("صاحب المشروع", "المقاول"),
        ]),
        ("transport", [
            ("shipper", "carrier"),
            ("expéditeur", "transporteur"),
            ("الشاحن", "الناقل"),
        ]),
        ("data_processing", [
            ("controller", "processor"),
            ("data controller", "data processor"),
            ("responsable du traitement", "sous-traitant"),
            ("المتحكم بالبيانات", "معالج البيانات"),
        ]),
        ("shareholder", [
            ("company", "shareholder"),
            ("société", "actionnaire"),
            ("الشركة", "المساهم"),
        ]),
        ("agency", [
            ("principal", "agent"),
            ("mandant", "mandataire"),
            ("الموكل", "الوكيل"),
        ]),
    ]

    for family, pairs in explicit_pairs:
        for a, b in pairs:
            pattern_a = r"(?<!\w)" + re.escape(a) + r"(?!\w)"
            pattern_b = r"(?<!\w)" + re.escape(b) + r"(?!\w)"
            if re.search(pattern_a, combined) and re.search(pattern_b, combined):
                return family

    # Employment only if the contract itself is employment-focused.
    employment_contract_signals = [
        "employment agreement",
        "employment contract",
        "employee agreement",
        "executive employment",
        "offer of employment",
        "contrat de travail",
        "contrat d'emploi",
        "عقد عمل",
        "اتفاقية عمل",
    ]

    if any(
        re.search(r"(?<!\w)" + re.escape(signal) + r"(?!\w)", combined)
        for signal in employment_contract_signals
    ):
        return "employment"

    family_signals = [
        ("data_processing", [
            "data processing agreement", "dpa", "data protection agreement",
            "accord de traitement des données", "traitement des données",
            "اتفاقية معالجة البيانات", "حماية البيانات",
        ]),
        ("franchise", [
            "franchise agreement", "franchise", "contrat de franchise",
            "امتياز تجاري", "الامتياز التجاري",
        ]),
        ("distribution", [
            "distribution agreement", "reseller agreement", "distributor",
            "contrat de distribution", "distributeur", "اتفاقية توزيع", "موزع",
        ]),
        ("insurance", [
            "insurance policy", "insurance agreement", "assurance", "police d'assurance",
            "وثيقة التأمين", "عقد تأمين",
        ]),
        ("construction", [
            "construction contract", "works contract", "engineering procurement construction",
            "contrat de construction", "marché de travaux", "عقد بناء", "عقد مقاولة",
        ]),
        ("transport", [
            "transport agreement", "carriage", "shipping", "logistics",
            "contrat de transport", "logistique", "عقد نقل", "الخدمات اللوجستية",
        ]),
        ("shareholder", [
            "shareholders agreement", "shareholder agreement", "equity",
            "outstanding shares", "preferred shares", "common shares",
            "capital shares", "shares of stock", "voting shares",
            "pacte d'actionnaires", "actionnaire",
            "اتفاقية المساهمين", "أسهم الشركة", "أسهم عادية", "أسهم ممتازة",
        ]),
        ("services", [
            "master services agreement", "service agreement", "consulting agreement",
            "services", "prestataire", "consulting", "consultant",
            "اتفاقية خدمات", "خدمات", "استشاري",
        ]),
        ("sale", [
            "sale agreement", "purchase agreement", "supply agreement",
            "sale", "purchase", "vente", "achat", "اتفاقية بيع", "شراء",
        ]),
        ("lease", [
            "lease agreement", "lease", "bail", "rent", "location",
            "عقد إيجار", "إيجار", "كراء",
        ]),
        ("loan", [
            "loan agreement", "credit agreement", "financing agreement",
            "loan", "prêt", "prêt", "financing", "credit", "قرض", "تمويل",
        ]),
        ("license", [
            "license agreement", "licence agreement", "software license",
            "license", "licence", "ترخيص", "رخصة",
        ]),
        ("nda", [
            "nda", "non-disclosure", "confidentiality agreement",
            "accord de confidentialité", "اتفاقية عدم إفصاح", "سرية",
        ]),
    ]

    for family, signals in family_signals:
        if any(
            re.search(r"(?<!\w)" + re.escape(signal) + r"(?!\w)", combined)
            for signal in signals
        ):
            return family

    return "generic"


def get_display_roles(
    contract_type: str = "",
    text: str = "",
    language: str = "en",
    anonymized: bool = False,
) -> dict:
    """
    Return display-role suggestions.

    By default anonymized=False to prevent accidental replacement.
    Set anonymized=True only when the caller confirms the text uses
    anonymized placeholders and role mapping is safe.
    """
    language = normalize_language(language)
    family = normalize_role_family_key(
        detect_role_family(contract_type, text)
    )
    party_a, party_b = ROLE_LABELS.get(
        family,
        ROLE_LABELS["generic"],
    )[language]

    return {
        "party_a": party_a,
        "party_b": party_b,
        "family": family,
        "anonymized": bool(anonymized),
    }


def get_anonymized_display_roles(
    contract_type: str = "",
    text: str = "",
    language: str = "en",
) -> dict:
    """
    Convenience helper for callers that already know the text is anonymized.
    """
    return get_display_roles(
        contract_type=contract_type,
        text=text,
        language=language,
        anonymized=True,
    )


def _build_replacements(roles: dict, language: str) -> dict[str, str]:
    language = normalize_language(language)

    a = str(roles.get("party_a") or ROLE_LABELS["generic"][language][0])
    b = str(roles.get("party_b") or ROLE_LABELS["generic"][language][1])

    return {
        "en": {
            "Contracting Party A": a,
            "Contracting Party B": b,
            "Party A": a,
            "Party B": b,
            "[PARTY_1]": a,
            "[PARTY_2]": b,
            "[PARTY_A]": a,
            "[PARTY_B]": b,
        },
        "fr": {
            "Partie contractante A": a,
            "Partie contractante B": b,
            "Partie A": a,
            "Partie B": b,
            "[PARTY_1]": a,
            "[PARTY_2]": b,
            "[PARTY_A]": a,
            "[PARTY_B]": b,
        },
        "ar": {
            "الطرف المتعاقد أ": a,
            "الطرف المتعاقد ب": b,
            "الطرف أ": a,
            "الطرف ب": b,
            "[PARTY_1]": a,
            "[PARTY_2]": b,
            "[PARTY_A]": a,
            "[PARTY_B]": b,
        },
    }[language]


def _fix_french_articles(value: str) -> str:
    output = value

    for old, new in FR_ARTICLE_FIXES.items():
        output = output.replace(old, new)

    return output



# ------------------------------------------------------------------
# Universal AI-generated role-word normalization
# ------------------------------------------------------------------
# This is intentionally separate from apply_display_roles().
#
# apply_display_roles():
# - replaces anonymized placeholders only when roles["anonymized"] is True.
# - preserves the privacy-first objective.
#
# normalize_ai_role_words():
# - corrects generic AI wording such as Employer / Employee when the detected
#   contract family is NOT employment.
# - works for any supported contract family and industry.
# - supports EN / FR / AR.
# - does not reconstruct, infer, or inject real party identities.


def _role_word_boundary_pattern(source: str):
    return re.compile(
        r"(?<![\w])" + re.escape(source) + r"(?![\w])",
        flags=re.IGNORECASE,
    )


def _match_case(target: str, matched: str) -> str:
    if not target:
        return target

    if matched.isupper():
        return target.upper()

    if matched[:1].isupper():
        return target[:1].upper() + target[1:]

    return target[:1].lower() + target[1:]


def _replace_role_word(text: str, source: str, target: str) -> str:
    if not source or not target:
        return text

    pattern = _role_word_boundary_pattern(source)

    def replace(match):
        return _match_case(target, match.group(0))

    return pattern.sub(replace, text)


def _normalize_generated_role_text_en(
    text: str,
    party_a: str,
    party_b: str,
) -> str:
    output = text

    # Possessive forms first, before base words.
    replacements = [
        ("Employer's", f"{party_a}'s"),
        ("Employers'", f"{party_a}'s"),
        ("Employee's", f"{party_b}'s"),
        ("Employees'", "personnel's"),
        ("Employer’s", f"{party_a}'s"),
        ("Employee’s", f"{party_b}'s"),
        ("Employees’", "personnel's"),

        # Party-role labels and common AI-generated role variants.
        ("Favours: Employer", "Favours: Unclear"),
        ("Favors: Employer", "Favors: Unclear"),
        ("Favours: Employee", "Favours: Unclear"),
        ("Favors: Employee", "Favors: Unclear"),
        ("Employer", "the relevant contractual party"),
        ("Employers", "the relevant contractual party"),
        ("Employee", "personnel"),

        # In non-employment contracts, plural employees usually means staff,
        # personnel, workforce, or applicable representatives — not Party B.
        ("Employees", "personnel"),
        ("Employment & HR", "Restrictive Covenants & Personnel"),
        
    ]

    for source, target in replacements:
        output = _replace_role_word(output, source, target)

    return output


def _normalize_generated_role_text_fr(
    text: str,
    party_a: str,
    party_b: str,
) -> str:
    output = text

    replacements = [
        ("de l’Employeur", f"de {party_a}"),
        ("de l'Employeur", f"de {party_a}"),
        ("à l’Employeur", f"à {party_a}"),
        ("à l'Employeur", f"à {party_a}"),
        ("l’Employeur", party_a),
        ("l'Employeur", party_a),
        ("Employeur", party_a),
        ("Employeurs", party_a),
        ("Employé", party_b),
        ("Employée", party_b),
        ("Salarié", party_b),
        ("Salariée", party_b),
        ("Employés", "personnel"),
        ("Employées", "personnel"),
        ("Salariés", "personnel"),
        ("Salariées", "personnel"),
    ]

    for source, target in replacements:
        output = _replace_role_word(output, source, target)

    return _fix_french_articles(output)


def _normalize_generated_role_text_ar(
    text: str,
    party_a: str,
    party_b: str,
) -> str:
    output = text

    replacements = [
        ("صاحب العمل", party_a),
        ("أصحاب العمل", party_a),
        ("الموظف", party_b),
        ("الموظفة", party_b),
        ("الموظفون", "الأفراد المعنيون"),
        ("الموظفين", "الأفراد المعنيين"),
        ("الموظفات", "الأفراد المعنيين"),
        ("العامل", party_b),
        ("العاملين", "الأفراد المعنيين"),
    ]

    for source, target in replacements:
        output = output.replace(source, target)

    return output



def normalize_anonymized_placeholders_to_roles(text: str, roles: dict, language: str = "en") -> str:
    language = normalize_language(language)
    family = normalize_role_family_key(roles.get("family") if isinstance(roles, dict) else "generic")

    if not isinstance(roles, dict):
        return text

    party_a = str(roles.get("party_a") or ROLE_LABELS["generic"][language][0])
    party_b = str(roles.get("party_b") or ROLE_LABELS["generic"][language][1])

    replacements = {
        "[PARTY_1]": party_a,
        "[PARTY_A]": party_a,
        "[CLIENT]": party_a,
        "[CUSTOMER]": party_a,
        "[BUYER]": party_a,
        "[LESSOR]": party_a,
        "[LANDLORD]": party_a,
        "[LENDER]": party_a,
        "[LICENSOR]": party_a,
        "[CONTROLLER]": party_a,
        "[EMPLOYER]": party_a if family == "employment" else party_a,
        "[PARTY_2]": party_b,
        "[PARTY_B]": party_b,
        "[SERVICE_PROVIDER]": party_b,
        "[PROVIDER]": party_b,
        "[SUPPLIER]": party_b,
        "[VENDOR]": party_b,
        "[SELLER]": party_b,
        "[LESSEE]": party_b,
        "[TENANT]": party_b,
        "[BORROWER]": party_b,
        "[LICENSEE]": party_b,
        "[PROCESSOR]": party_b,
        "[EMPLOYEE]": party_b if family == "employment" else party_b,
    }

    output = text
    for source, target in sorted(replacements.items(), key=lambda item: len(item[0]), reverse=True):
        output = output.replace(source, target)

    return output

def normalize_ai_role_words(value, roles: dict, language: str = "en"):
    """
    Recursively normalize AI-generated role labels for any contract family.

    International standard:
    - works for any supported contract family / industry;
    - supports EN / FR / AR;
    - keeps Employer / Employee only for real employment contracts;
    - maps generic role wording to ROLE_LABELS[family][language];
    - preserves privacy-first architecture;
    - does not reconstruct, infer, or expose personal data.

    Important:
    This function is NOT a party identity resolver. It only corrects generic
    role words generated by the AI so a services, sale, lease, finance,
    licensing, NDA, insurance, construction, or other contract is not displayed
    as if it were an employment contract.
    """
    language = normalize_language(language)

    if isinstance(value, list):
        return [
            normalize_ai_role_words(item, roles, language)
            for item in value
        ]

    if isinstance(value, dict):
        protected_keys = {
            "original_text",
            "original_clause",
            "quoted_text",
            "excerpt",
            "clause_text",
            "text",
            "source_text",
            "raw_text",
        }

        return {
            key: (
                item
                if str(key).lower() in protected_keys
                else normalize_ai_role_words(item, roles, language)
            )
            for key, item in value.items()
        }

    if not isinstance(value, str):
        return value

    if not isinstance(roles, dict):
        return value

    family = normalize_role_family_key(
        roles.get("family")
        or roles.get("contract_family")
        or "generic"
    )

    # Real employment contracts should keep employment terminology.
    if family == "employment":
        return value
    # For non-employment contracts, never allow hallucinated Employer/Employee
# labels to survive. This is universal across EN / FR / AR and all domains.
    if family != "employment":
        neutral = {
            "en": "the relevant party",
            "fr": "la partie concernée",
            "ar": "الطرف المعني",
        }.get(language, "the relevant party")

        neutral_possessive = {
            "en": "the relevant party's",
            "fr": "de la partie concernée",
            "ar": "الخاصة بالطرف المعني",
        }.get(language, "the relevant party's")

        replacements = {
            "Employer's": neutral_possessive,
            "Employer’s": neutral_possessive,
            "Employers'": neutral_possessive,
            "Employer": neutral,
            "Employee's": neutral_possessive,
            "Employee’s": neutral_possessive,
            "Employees'": neutral_possessive,
            "Employee": "personnel",
            "Employees": "personnel",
            "Employeur": neutral,
            "Salarié": "personnel",
            "Salariés": "personnel",
            "Employé": "personnel",
            "Employés": "personnel",
            "صاحب العمل": neutral,
            "الموظف": "الموظفين",
            "الموظفون": "الموظفين",
        }

        for old, new in sorted(
            replacements.items(),
            key=lambda item: len(item[0]),
            reverse=True,
        ):
            value = value.replace(old, new)

    party_a = str(
        roles.get("party_a")
        or ROLE_LABELS["generic"][language][0]
    )

    party_b = str(
        roles.get("party_b")
        or ROLE_LABELS["generic"][language][1]
    )

    value = normalize_anonymized_placeholders_to_roles(
        value,
        roles,
        language,
    )

    if language == "fr":
        return _normalize_generated_role_text_fr(
            value,
            party_a,
            party_b,
        )

    if language == "ar":
        return _normalize_generated_role_text_ar(
            value,
            party_a,
            party_b,
        )
    
    return _normalize_generated_role_text_en(
        value,
        party_a,
        party_b,
    )

def apply_display_roles(value, roles: dict, language: str = "en"):
    """
    Apply display roles only when roles are confirmed anonymized.

    This preserves privacy-first architecture and prevents a services contract
    from being incorrectly rewritten as employment, sale, etc.
    """
    language = normalize_language(language)

    if not roles_are_anonymized(roles):
        return value

    if isinstance(value, list):
        return [
            apply_display_roles(item, roles, language)
            for item in value
        ]

    if isinstance(value, dict):
        return {
            key: apply_display_roles(item, roles, language)
            for key, item in value.items()
        }

    if not isinstance(value, str):
        return value

    output = value
    replacements = _build_replacements(roles, language)
    

    for old, new in sorted(
        replacements.items(),
        key=lambda item: len(item[0]),
        reverse=True,
    ):
        output = output.replace(old, new)

    if language == "fr":
        output = _fix_french_articles(output)

    return output
